# معماری NAVID

## لایه ها (Clean Architecture + MVVM)
UI (Compose) -> ViewModel -> UseCase (domain) -> Repository (interface) -> Room/DataStore/Provider

بسته بندی کد (ir.navid.app):
- core: ابزار مشترک (تاریخ شمسی، پول، Result، لاگ)
- data: Room، DAO، Repositoryها، DataStore، بکاپ
- domain: مدل ها، UseCaseها، قوانین مالی و ساختمان (کد خالص و قابل تست)
- ai: ConversationManager، IntentDetector، Orchestrator، ToolRegistry، Providerها، Memory
- feature.home / assistant / building / finance / tools / settings: صفحه ها و ViewModelها
- work: WorkManager و AlarmManager

## جریان هوش مصنوعی
UI -> ConversationManager -> IntentDetector -> AIOrchestrator -> ToolEngine -> UseCase -> Repository

قواعد:
- مدل هیچ دسترسی مستقیم به دیتابیس ندارد؛ فقط از ابزارهای ثبت شده در ToolRegistry استفاده می کند.
- خروجی مدل برای اجرا باید JSON ساختاریافته باشد. ToolEngine ورودی را با Schema اعتبارسنجی می کند؛ ناقص یا نامعتبر یعنی پرسیدن سؤال تکمیلی، نه حدس زدن.
- عملیات حساس (تراکنش مالی، حذف، تغییر مهم، رویداد تقویم) اول به صورت PendingAction با وضعیت PENDING ذخیره می شود و فقط با تأیید کاربر اجرا می شود.
- محاسبات مالی در کد؛ مدل فقط متن توضیحی می نویسد و اعداد را از نتیجه ابزار می گیرد.
- سه حالت: مکالمه، اجرایی، تحلیلی (تشخیص خودکار + تغییر دستی).

### ابزارها (نسخه اول)
createTransaction، getTransactions، getFinancialSummary، createProject، addConstructionReport، createReminder، createCalendarEvent، searchDocuments، analyzeDocument، generateReport، searchWeb

نمونه قرارداد ابزار:
```
tool: createTransaction
input: { amount: Long>0, currency: "IRT", date: "YYYY-MM-DD", kind: EXPENSE|INCOME|TRANSFER,
         categoryId?, fromAccountId, toAccountId?, projectId?, note? }
output: { pendingActionId, preview }   // ثبت نهایی فقط پس از تأیید
```

## Provider مدل
interface LlmProvider { id; isAvailable(); generate(request): Flow<Token> }
- LocalProvider (llama.cpp از طریق JNI/NDK، فرمت GGUF) — پیش فرض
- OpenAIProvider، AnthropicProvider — فقط با فعال سازی کاربر، کلید کاربر در Android Keystore، نمایش هزینه و نوع داده ارسالی قبل از استفاده، حذف یا ناشناس سازی اطلاعات حساس قبل از ارسال.
- تاریخچه و حافظه مستقل از Provider هستند.

## حافظه
جدول memories با دسته (شخصی، اهداف، کسب و کار، ساختمان، مالی، سوابق کاری، مکالمات، یادداشت ها)، منبع، تاریخ و hash برای تشخیص تکراری. اطلاعات عادی خودکار؛ مالی و حساس با تأیید. مکالمه جدا از داده عملیاتی.

## تعویض مدل
ModelRegistry: مدل فعال، حجم، checksum، وضعیت دانلود، حذف، بازگشت به مدل قبلی. مدل در بکاپ نیست.

## پس زمینه
WorkManager برای کارهای قابل تعویق (بکاپ، گزارش، دانلود مدل)؛ AlarmManager (exact) فقط برای یادآوری های دقیق. راهنمای محدودیت باتری One UI در راه اندازی اولیه.

## امنیت
- Room با SQLCipher؛ کلید در Android Keystore
- بکاپ رمزگذاری شده در Google Drive (appDataFolder) فقط Wi-Fi و شارژ، روزی یک بار
- مجوز تماس و پیامک درخواست نمی شود
- فایل ها فقط با Photo Picker و Storage Access Framework

## کدام قابلیت کجا کار می کند
| قابلیت | محلی | اینترنت | سرویس خارجی |
|---|---|---|---|
| مالی، ساختمان، حافظه، تقویم، یادآوری، ابزارها، Euromen | بله | - | - |
| مدل محلی | بله (پس از دانلود) | دانلود اولیه | - |
| تحلیل اسناد (استخراج متن، جست وجو) | بله | - | - |
| OCR و تحلیل تصویر و نقشه | محدود (نیاز به آزمایش) | - | اختیاری |
| جست وجوی وب | - | بله | موتور جست وجو (قابل تعویض) |
| ChatGPT / Claude | - | بله | کلید کاربر |
| بکاپ | - | بله | Google Drive |

## انتخاب مدل محلی (هنوز انجام نشده)
کاندیدها (بدون ادعای کیفیت): Qwen2.5 (1.5B و 3B)، Gemma (1B تا 2B)، Llama 3.2 (1B و 3B). مجوز هر نسخه جداگانه بررسی شود. روش: مجموعه تست فارسی (عمومی، مالی، ساختمانی، دستور اجرایی) و اندازه گیری روی خود S20 FE: توکن بر ثانیه، رم، دما، باتری، کیفیت JSON. انتخاب فقط بر پایه نتیجه واقعی.

## لایه تحلیل فرمان (NLU) — نسخه 0.5.0
جریان: متن کاربر -> نرمال سازی -> استخراج مبلغ / تاریخ / حساب ها با کد -> قواعد نوع پیام -> (فقط در صورت نیاز) مدل برای انتخاب بین گزینه ها -> اعتبارسنج -> کارت تأیید -> ابزار اجرایی.
- ParsedCommand: intents، candidates، amounts (با پرچم)، date، accounts، missing، warnings.
- مدل فقط {"intent","text"} برمی گرداند. خروجی با MiniJson خوانده و با ModelOutputValidator سنجیده می شود.
- هنوز به مدل محلی و ثبت واقعی وصل نشده است (نسخه های بعد).
