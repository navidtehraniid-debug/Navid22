# طرح دیتابیس (Room + SQLCipher)

قواعد کلی:
- شناسه ها UUID متنی (مناسب بکاپ و انتقال)
- مبلغ ها Long و ارز ذخیره شده کنار آن؛ پایه IRT (تومان)، نمایش ریال فقط تبدیل نمایشی (ضرب در 10)
- تاریخ: epoch میلی ثانیه UTC + local_date میلادی (ISO). تبدیل به شمسی فقط در UI
- حذف نرم با deleted_at؛ سطل بازیافت 30 روزه؛ حذف دائمی با تأیید
- هر تغییر مهم در audit_log

## مالی
- ledgers(id, name[PERSONAL|BUILDING|INVESTMENT|EUROMEN])
- accounts(id, ledger_id, name, type[ASSET|LIABILITY|EQUITY|INCOME|EXPENSE], subtype[BANK|CASH|PROJECT|INVESTMENT|OTHER], currency, opening_balance, archived, deleted_at)
- categories(id, name, parent_id, kind[INCOME|EXPENSE])
- transactions(id, ledger_id, occurred_at, local_date, kind[INCOME|EXPENSE|TRANSFER|DEBT|RECEIVABLE|INVESTMENT], data_class[ACTUAL|ESTIMATED|FORECAST], status[DRAFT|CONFIRMED|VOID], category_id, project_id, phase_id, contractor_id, description, source[MANUAL|CHAT|VOICE|DOCUMENT|IMPORT], source_ref, created_at, updated_at, deleted_at)
- transaction_lines(id, transaction_id, account_id, debit, credit) — شرط: هر خط فقط یکی از debit یا credit؛ جمع بدهکار = جمع بستانکار در هر تراکنش
- budgets(id, project_id, category_id, planned_amount)
قاعده: TRANSFER دو خط بین حساب ها است و هرگز هزینه نیست؛ هزینه واقعی فقط یک بار روی حساب هزینه ثبت می شود.

## ساختمان
- projects(id, name, address, land_area, built_area, floors, structure_type, land_info, initial_budget, status)
- phases(id, project_id, name, sort_order, planned_start, planned_end, actual_start, actual_end, status, progress_pct, notes)
- phase_dependencies(phase_id, depends_on_phase_id)
- contractors(id, name, trade, phone, notes)
- contracts(id, project_id, contractor_id, title, amount, signed_at, document_id, notes)
- site_reports(id, project_id, phase_id, report_date, text, source[TEXT|VOICE], linked_transaction_id)
- مراحل پیش فرض: تخریب، گودبرداری، سازه نگهبان، فونداسیون، اسکلت، سقف، دیوارچینی، تأسیسات، نما، نازک کاری، آسانسور، مشاعات، تأییدیه ها، پایان کار

## Euromen (سبک)
- euromen_orders(id, title, status, ordered_at, due_at, notes)  — فیلدهای دقیق «سفارش خرج کار» باید با شما نهایی شود
- euromen_costs(id, order_id, transaction_id, description)

## حافظه و مکالمه
- memories(id, category, content, source, source_ref, dedupe_hash, created_at, updated_at, deleted_at)
- conversations(id, title, created_at)
- messages(id, conversation_id, role, mode, content, tool_calls_json, created_at)
- pending_actions(id, tool_name, args_json, status[PENDING|CONFIRMED|REJECTED|EXPIRED], created_at, resolved_at)

## اسناد
- documents(id, name, mime, stored_path, sha256, size, status, added_at, deleted_at)
- document_pages(id, document_id, page_no, text, extract_status)
- FTS5 روی memories، document_pages، site_reports، notes

## تقویم و یادآوری
- reminders(id, title, notes, due_at, level[URGENT|IMPORTANT|NORMAL], exact, repeat_rule, status)
- events(id, title, start_at, end_at, location, device_calendar_event_id, status)
- notes(id, title, body, created_at, updated_at, deleted_at)

## سیستمی
- model_registry(id, name, file_path, size, sha256, license, status, is_active)
- backup_log(id, at, status, size, drive_file_id)
- audit_log(id, at, actor[USER|AI|SYSTEM], action, entity, entity_id, before_json, after_json)
- تنظیمات ساده در DataStore

## انحراف از طرح در نسخه 0.2.0 (پیاده سازی فعلی)
- فقط جدول های accounts، transactions، transaction_lines ساخته شده اند.
- ledger ستون enum است (جدول ledgers نیست)؛ categories همان حساب های EXPENSE و INCOME هستند.
- ستون های project_id، phase_id، contractor_id، category_id هنوز وجود ندارند و در مرحله ساختمان با migration اضافه می شوند.
- دیتابیس رمزگذاری نشده است.

## نسخه 0.4.0 (دیتابیس نسخه 2)
- جدول جدید memories(id, category, title, content, source, dedupeHash, createdAt, updatedAt, deletedAt) با ایندکس روی category و dedupeHash.
- یادداشت ها همان memories با دسته NOTES هستند (جدول notes جدا ساخته نشد).
- جست وجو با LIKE؛ FTS5 بعداً.
- Migration 1 به 2 فقط جدول و ایندکس اضافه می کند و به داده های مالی دست نمی زند. هیچ مسیر «پاک کردن و ساخت دوباره» (destructive) تعریف نشده است.

## نسخه 0.7.0 و 0.8.0 (دیتابیس نسخه 4)
- reminders(id, title, notes, dueAt, localDate, hour, minute, level, exact, status, source, createdAt, updatedAt, deletedAt)
- projects(id, name, address, landArea, builtArea, floors, structureType, initialBudget, status, createdAt, updatedAt, deletedAt)
- phases(id, projectId, name, sortOrder, plannedStart, plannedEnd, actualStart, actualEnd, status, progressPct, notes)
- site_reports(id, projectId, phaseId, reportDate, text, source, createdAt, deletedAt)
- transactions.projectId (ستون جدید، اختیاری)
- هنوز نیست: contractors، contracts، phase_dependencies، budgets، documents.

## دیتابیس دانش (navid_knowledge.db، نسخه 1، از 0.9.0)
- lib_documents(id, title, publisher, authors, year, edition, docType, sourceGroup, topic, phaseKeys, status, statusNote, origin, originUrl, fileName, relPath, mime, sha256, sizeBytes, pageCount, ingestStatus, userNotes, projectId, uploadedAt, updatedAt, deletedAt) با ایندکس روی sha256
- فایل ها: files/library/<شناسه سند>/original.<پسوند>
- جدول های صفحه، تکه، ایندکس FTS4، مترادف، فهرست مطالب، منابع وب، چک لیست و دانشنامه در مراحل بعد اضافه می شوند (با Migration).

## دیتابیس دانش نسخه 2 (از 0.10.0)
- lib_documents: ستون های جدید ingestInfo، printedOffset، clauseReversed، pagesWithText، chunkCount، ingestedAt (همه اختیاری)
- lib_pages(docId, pageNo, text, printedPage, quality, method)  کلید ترکیبی (docId, pageNo)
- lib_chunks(id, docId, pageFrom, pageTo, chapter, clause, heading, text, tokenCount)  ایندکس روی docId
- lib_chunks_fts: جدول مجازی FTS4(text_search، tokenize=unicode61)، ساخته شده در onOpen، با docid برابر lib_chunks.id (دستی، خارج از Room)
