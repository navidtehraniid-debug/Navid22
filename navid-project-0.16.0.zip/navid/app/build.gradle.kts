plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

val withLocalModel = providers.gradleProperty("localModel").orNull == "true"
val withOcr = providers.gradleProperty("ocr").orNull == "true"

android {
    namespace = "ir.navid.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.navid.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 18
        versionName = "0.16.0"
    }

    // کلید ثابت برای APK آزمایشی: بدون آن هر Build در GitHub با کلید تصادفی جدید امضا می شود
    // و اندروید اجازه آپدیت روی نسخه قبلی را نمی دهد. فقط برای debug؛ کلید نسخه نهایی جدا و محرمانه خواهد بود.
    signingConfigs {
        create("navidDebug") {
            storeFile = rootProject.file("keystore/navid-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("navidDebug")
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    sourceSets {
        if (withLocalModel) {
            getByName("main").java.srcDir("src/localmodel/java")
        }
        if (withOcr) {
            getByName("main").java.srcDir("src/ocr/java")
        }
    }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.pdfbox.android)
    if (withLocalModel) {
        implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")
    }
    if (withOcr) {
        implementation("cz.adaptech.tesseract4android:tesseract4android:4.8.0")
    }

    testImplementation(libs.junit)
}
