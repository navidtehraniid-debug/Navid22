package ir.navid.app.ai.nlu

import ir.navid.app.core.JalaliDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelOutputValidatorTest {
    private val today = JalaliDate(1405, 8, 10)
    private val accounts = listOf("صندوق نقد", "حساب بانکی")
    private fun parse(t: String) = CommandParser.parse(t, today, accounts)

    @Test
    fun tenTimesWrongModelAmountIsOnlyAWarning() {
        val p = parse("چهارصد هزار تومان بنزین زدم")
        val r = ModelOutputValidator.validate("""{"intent":"expense","amount":4000000,"date":null,"text":"بنزین"}""", p)
        assertEquals(Intent.EXPENSE, r.intent)
        assertTrue("AMOUNT_MISMATCH" in r.warnings)
        assertFalse(r.needsUserChoice)
        assertEquals(400_000L, p.safeAmount)
    }

    @Test
    fun fabricatedAmountAndDateAreDetected() {
        val p = parse("حقوقم واریز شد")
        val r = ModelOutputValidator.validate("""{"intent":"income","amount":5000000,"date":"امروز","text":"x"}""", p)
        assertTrue("FABRICATED_AMOUNT" in r.warnings)
        assertTrue("FABRICATED_DATE" in r.warnings)
        assertNull(p.safeAmount)
    }

    @Test
    fun amountAsStringAndNullAsStringAreNormalizedWithWarnings() {
        val p = parse("15 میلیون تومان دستمزد پرداخت کردم")
        val r = ModelOutputValidator.validate("""{"intent":"expense","amount":"15000000","date":"null","text":"دستمزد"}""", p)
        assertTrue("AMOUNT_AS_STRING" in r.warnings)
        assertTrue("NULL_AS_STRING_DATE" in r.warnings)
        assertFalse("AMOUNT_MISMATCH" in r.warnings)
        assertEquals(Intent.EXPENSE, r.intent)
    }

    @Test
    fun invalidJsonNeedsUserChoice() {
        val r = ModelOutputValidator.validate("متاسفم نمیتونم", parse("سلام"))
        assertNull(r.intent)
        assertTrue(r.needsUserChoice)
        assertTrue("INVALID_JSON" in r.warnings)
    }

    @Test
    fun unknownIntentNeedsUserChoice() {
        val r = ModelOutputValidator.validate("""{"intent":"foo","text":"x"}""", parse("سلام"))
        assertNull(r.intent)
        assertTrue(r.needsUserChoice)
        assertTrue("INVALID_INTENT" in r.warnings)
    }

    @Test
    fun modelMustChooseAmongCandidates() {
        val p = parse("حقوق گرفتم و 3 میلیون هم خرج کردم")
        val bad = ModelOutputValidator.validate("""{"intent":"question","text":"x"}""", p)
        assertNull(bad.intent)
        assertTrue(bad.needsUserChoice)
        assertTrue("INTENT_OUTSIDE_CANDIDATES" in bad.warnings)
        val good = ModelOutputValidator.validate("""{"intent":"income","text":"x"}""", p)
        assertEquals(Intent.INCOME, good.intent)
        assertFalse(good.needsUserChoice)
    }

    @Test
    fun promptListsOnlyCandidatesAndEndsWithSentence() {
        val prompt = ModelPrompt.build("حقوقم واریز شد", listOf(Intent.INCOME, Intent.EXPENSE))
        assertTrue(prompt.contains("income, expense"))
        assertTrue(prompt.trimEnd().endsWith("جمله: حقوقم واریز شد"))
        assertFalse(prompt.contains("\u200C"))
        assertTrue(ModelPrompt.build("x", emptyList()).contains("site_report"))
    }
}
