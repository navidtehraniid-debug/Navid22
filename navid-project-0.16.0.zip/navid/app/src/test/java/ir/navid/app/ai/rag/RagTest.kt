package ir.navid.app.ai.rag

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RagTest {
    private val sources = listOf(
        RagSource("S1", "مبحث چهارم • بند 4-5-2-8-2", "در ورودی اصلی اتاق های اقامت باید دارای حداقل 0/8 متر پهنای مفید و 2/05 متر ارتفاع مفید باشد."),
        RagSource("S2", "مبحث چهارم • بند 4-1-3-4", "ساختمان های ثبت شده تابع ضوابط سازمان میراث فرهنگی هستند.")
    )

    @Test
    fun supportedSentenceWithMatchingNumbers() {
        val a = AnswerValidator.validate("پهنای مفید در ورودی اتاق اقامت حداقل 0.8 متر است [S1].", sources)
        assertTrue(a.sentences.single().supported)
        assertEquals(listOf("S1"), a.usedSourceIds)
        assertFalse(a.hasProblems)
    }

    @Test
    fun persianDigitsAndSlashDecimalsAreAccepted() {
        val a = AnswerValidator.validate("ارتفاع مفید ۲/۰۵ متر است [S1]", sources)
        assertTrue(a.sentences.single().supported)
    }

    @Test
    fun inventedNumberIsFlagged() {
        val a = AnswerValidator.validate("پهنای مفید حداقل 0.9 متر است [S1].", sources)
        val s = a.sentences.single()
        assertFalse(s.supported)
        assertTrue(s.problem!!.contains("0.9"))
        assertTrue(a.hasProblems)
    }

    @Test
    fun missingOrInvalidCitationIsFlagged() {
        val a = AnswerValidator.validate("ورودی باید عریض باشد. دوم [S9].", sources)
        assertEquals("بدون ارجاع به منبع", a.sentences[0].problem)
        assertEquals("ارجاع نامعتبر", a.sentences[1].problem)
    }

    @Test
    fun numberMustBeInTheCitedSourceNotJustAnySource() {
        val a = AnswerValidator.validate("پهنای مفید 0.8 متر است [S2].", sources)
        assertFalse(a.sentences.single().supported)
    }

    @Test
    fun noAnswerSentenceIsRecognized() {
        val a = AnswerValidator.validate(RagPrompt.NO_ANSWER, sources)
        assertTrue(a.noAnswer)
        assertFalse(a.hasProblems)
    }

    @Test
    fun listMarkersAreNotTreatedAsNumbers() {
        val a = AnswerValidator.validate("1. پهنای مفید 0.8 متر است [S1]", sources)
        assertTrue(a.sentences.single().supported)
    }

    @Test
    fun promptContainsRulesQuestionAndSources() {
        val req = RagPrompt.build("پهنای ورودی چقدر است؟", sources)
        assertTrue(req.system.contains("[S1]"))
        assertTrue(req.system.contains(RagPrompt.NO_ANSWER))
        assertTrue(req.user.startsWith("پرسش: پهنای ورودی چقدر است؟"))
        assertTrue(req.user.contains("[S2] مبحث چهارم • بند 4-1-3-4"))
        assertEquals(0.0, req.temperature, 0.0)
        assertNull(null)
    }
}
