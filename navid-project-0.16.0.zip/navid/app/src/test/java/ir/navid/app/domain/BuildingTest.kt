package ir.navid.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BuildingTest {
    @Test
    fun fourteenDefaultPhasesFromDemolitionToCompletion() {
        val p = BuildingPhases.defaults
        assertEquals(14, p.size)
        assertEquals("تخریب", p.first())
        assertEquals("پایان کار", p.last())
        assertEquals(p.size, p.toSet().size)
    }

    @Test
    fun phaseRulesKeepStatusAndProgressConsistent() {
        assertEquals(Pair(PhaseStatus.DONE, 100), PhaseRules.normalize(PhaseStatus.DONE, 20))
        assertEquals(Pair(PhaseStatus.NOT_STARTED, 0), PhaseRules.normalize(PhaseStatus.NOT_STARTED, 70))
        assertEquals(Pair(PhaseStatus.IN_PROGRESS, 1), PhaseRules.normalize(PhaseStatus.IN_PROGRESS, 0))
        assertEquals(Pair(PhaseStatus.IN_PROGRESS, 99), PhaseRules.normalize(PhaseStatus.IN_PROGRESS, 150))
        assertEquals(Pair(PhaseStatus.IN_PROGRESS, 40), PhaseRules.normalize(PhaseStatus.IN_PROGRESS, 40))
    }

    @Test
    fun projectProgressIsSimpleAverageOfPhases() {
        assertEquals(0, ProjectMath.progress(emptyList()))
        assertEquals(50, ProjectMath.progress(listOf(100, 0)))
        assertEquals(67, ProjectMath.progress(listOf(100, 100, 0)))
        assertEquals(100, ProjectMath.progress(listOf(100, 100)))
    }

    @Test
    fun budgetMath() {
        assertEquals(70L, ProjectMath.remaining(100, 30))
        assertEquals(-30L, ProjectMath.remaining(100, 130))
        assertNull(ProjectMath.usedPercent(0, 500))
        assertEquals(25, ProjectMath.usedPercent(1000, 250))
        assertEquals(33, ProjectMath.usedPercent(3, 1))
        assertEquals(130, ProjectMath.usedPercent(100, 130))
    }
}
