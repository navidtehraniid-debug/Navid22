package ir.navid.app.core

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant

class ReminderTimeTest {
    @Test
    fun tehranIsUtcPlusThreeThirtyAllYear() {
        // 1405/08/11 = 2026-11-02، ساعت 10:00 تهران = 06:30 UTC
        assertEquals(
            Instant.parse("2026-11-02T06:30:00Z").toEpochMilli(),
            ReminderTime.dueAtMillis(JalaliDate(1405, 8, 11), 10, 0)
        )
        // 1405/01/01 = 2026-03-21، ساعت 07:30 تهران = 04:00 UTC (بدون ساعت تابستانی)
        assertEquals(
            Instant.parse("2026-03-21T04:00:00Z").toEpochMilli(),
            ReminderTime.dueAtMillis(JalaliDate(1405, 1, 1), 7, 30)
        )
    }
}
