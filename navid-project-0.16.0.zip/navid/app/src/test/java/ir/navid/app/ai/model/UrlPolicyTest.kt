package ir.navid.app.ai.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlPolicyTest {
    @Test
    fun loopbackHostsAreLocal() {
        assertTrue(UrlPolicy.isLoopback("http://127.0.0.1:8080"))
        assertTrue(UrlPolicy.isLoopback("http://localhost:8080/v1"))
        assertTrue(UrlPolicy.isLoopback("  http://LOCALHOST:11434 "))
    }

    @Test
    fun networkHostsAreNotLocal() {
        assertFalse(UrlPolicy.isLoopback("http://192.168.1.5:8080"))
        assertFalse(UrlPolicy.isLoopback("https://api.example.com"))
        assertFalse(UrlPolicy.isLoopback("http://127.0.0.1.evil.com"))
        assertFalse(UrlPolicy.isLoopback("not a url"))
    }

    @Test
    fun openAiHeadersOmitAuthWhenKeyIsBlank() {
        val c = ExternalConfig(ApiFormat.OPENAI, "http://127.0.0.1:8080", "local", "")
        assertFalse(ExternalApiProtocol.headers(c).containsKey("Authorization"))
        assertEquals("http://127.0.0.1:8080/v1/chat/completions", ExternalApiProtocol.endpoint(c))
    }
}
