package ir.navid.app.knowledge.text

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** آزمون بازسازی از روی موقعیت نویسه های واقعی صفحه های 10 و 14 تا 21 مبحث چهارم (استخراج با pdfplumber). */
class GlyphPipelineTest {
    private class Page(val height: Float, val glyphs: List<Glyph>)

    private fun resource(name: String): String {
        val s = javaClass.classLoader!!.getResourceAsStream(name)
        requireNotNull(s) { "$name پیدا نشد" }
        return s.bufferedReader(Charsets.UTF_8).readText()
    }

    private fun loadPages(): Map<Int, Page> {
        val pages = LinkedHashMap<Int, Page>()
        var cur = -1
        var height = 792f
        var glyphs = ArrayList<Glyph>()
        fun close() {
            if (cur >= 0) pages[cur] = Page(height, glyphs)
        }
        for (ln in resource("glyphs_mabhas4_p10_14_21.txt").split("\n")) {
            if (ln.isEmpty()) continue
            val f = ln.split("\t")
            if (f[0] == "#PAGE") {
                close()
                cur = f[1].toInt()
                height = f[2].toFloat()
                glyphs = ArrayList()
            } else {
                glyphs.add(Glyph(f[0], f[1].toFloat(), f[2].toFloat(), f[3].toFloat(), f[4].toFloat()))
            }
        }
        close()
        return pages
    }

    private val pages = loadPages()

    private fun cleanLines(p: Page): List<String> =
        GlyphLineBuilder.build(p.glyphs).map { PdfTextCleaner.cleanRaw(it.text).trim() }.filter { it.isNotEmpty() }

    private fun golden(): Map<Int, List<String>> {
        val out = LinkedHashMap<Int, MutableList<String>>()
        var cur = -1
        for (ln in resource("glyph_golden_p10_p20.txt").split("\n")) {
            if (ln.isEmpty()) continue
            if (ln.startsWith("#PAGE ")) {
                cur = ln.removePrefix("#PAGE ").trim().toInt()
                out[cur] = ArrayList()
            } else {
                out[cur]!!.add(ln)
            }
        }
        return out
    }

    @Test
    fun linesMatchTheReferenceForBodyAndTocPages() {
        val g = golden()
        for (pn in listOf(10, 20)) assertEquals("صفحه $pn", g.getValue(pn), cleanLines(pages.getValue(pn)))
    }

    @Test
    fun wordsDigitsAndBracketsAreInLogicalOrder() {
        assertTrue(cleanLines(pages.getValue(20)).any { it.startsWith("4-1-3-4 ساختمان های ثبت شده توسط سازمان میراث فرهنگی") })
        val toc = cleanLines(pages.getValue(10))
        assertTrue(toc.any { it.startsWith("4-2 تعاریف") && it.endsWith("11") })
        assertTrue(toc.any { it.endsWith("41") }) // رقم های شماره صفحه فهرست چپ به راست می مانند (41، نه 14)
    }

    @Test
    fun toLogicalRestoresLeftToRightRuns() {
        assertEquals("سال 1396", GlyphLineBuilder.toLogical("سال 6931".toList()))
        assertEquals("ab 12", GlyphLineBuilder.toLogical("ba 21".toList()))
        assertEquals("0/8 متر", GlyphLineBuilder.toLogical("8/0 متر".toList()))
        assertEquals("4-1-3-4", GlyphLineBuilder.toLogical("4-1-3-4".toList()))
    }

    private fun pipeline(): TextPipeline.Result {
        val inputs = ArrayList<LineTextPipeline.PageInput>()
        repeat(13) { inputs.add(LineTextPipeline.PageInput(emptyList(), 792f)) }
        for (pn in 14..21) {
            val p = pages.getValue(pn)
            inputs.add(LineTextPipeline.PageInput(GlyphLineBuilder.build(p.glyphs), p.height))
        }
        return LineTextPipeline.process(inputs)
    }

    private val result = pipeline()

    @Test
    fun clauseOrientationNeedsNoFixForPositionBasedText() {
        assertFalse(result.orientation.reversed)
        assertTrue(result.orientation.rawTotal >= 10)
        assertEquals(result.orientation.rawTotal, result.orientation.rawOk)
    }

    @Test
    fun printedOffsetHeadersAndChapter() {
        assertEquals(13, result.printedOffset)
        assertEquals(2, result.headerCount)
        assertEquals("فصل اول - کلیات", result.chapters[19])
        assertFalse(result.pages[19].split("\n").map { it.trim() }.contains("7"))
    }

    @Test
    fun chunkCarriesExactHighlightBand() {
        val a = result.chunks.first { it.clause == "4-1-3-4" && it.pageFrom == 20 }
        assertTrue(a.text.startsWith("4-1-3-4 ساختمان های ثبت شده"))
        assertTrue(a.heading.startsWith("4-1-3 "))
        assertTrue(a.hlTop!! in 0.10f..0.115f)
        assertTrue(a.hlBottom!! in 0.16f..0.18f)
        val b = result.chunks.first { it.clause == "4-1-5-1" && it.pageFrom == 20 }
        assertTrue(b.hlTop!! in 0.67f..0.695f)
        assertTrue(b.hlBottom!! in 0.735f..0.76f)
    }
}
