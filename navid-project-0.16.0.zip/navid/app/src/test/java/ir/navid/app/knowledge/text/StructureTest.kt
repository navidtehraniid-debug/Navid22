package ir.navid.app.knowledge.text

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StructureTest {

    @Test
    fun orientationReversedWhenOnlyReversedIsAscending() {
        val pages = listOf("1-1-4 الف\n2-1-4 ب\n3-1-4 ج\n1-2-4 د\n2-2-4 ه")
        val d = ClauseOrientation.decide(pages)
        assertTrue(d.reversed)
        assertEquals(0, d.rawTotal)
        assertEquals(3, d.revOk)
        assertEquals(3, d.revTotal)
    }

    @Test
    fun orientationKeptWhenAlreadyCorrect() {
        val pages = listOf("4-1-1 الف\n4-1-2 ب\n4-1-3 ج\n4-2-1 د\n4-2-2 ه")
        val d = ClauseOrientation.decide(pages)
        assertFalse(d.reversed)
        assertEquals(3, d.rawOk)
    }

    @Test
    fun fixRunsReversesEveryHyphenatedNumber() {
        assertEquals("4-1-3-4 و 3-12", ClauseOrientation.fixRuns("4-3-1-4 و 12-3"))
    }

    @Test
    fun printedPageOffsetAndRemoval() {
        val pages = (1..8).map { i -> if (i >= 3) "متن صفحه $i\n${i - 2}" else "متن صفحه $i" }
        val printed = PageStructure.detectPrinted(pages)
        assertEquals(2, printed.offset)
        val stripped = PageStructure.stripPageNumbers(pages, printed.offset)
        assertEquals("متن صفحه 5", stripped[4])
        assertEquals("متن صفحه 1", stripped[0])
    }

    @Test
    fun noOffsetWhenNumbersAreInconsistent() {
        val pages = listOf("الف\n5", "ب\n9", "ج\n1", "د\n20")
        assertNull(PageStructure.detectPrinted(pages).offset)
    }

    @Test
    fun runningHeadersAreRemovedAndChaptersCarriedForward() {
        val pages = listOf("فصل اول - الف\nمتن 1") +
            listOf("فصل اول - الف\nمتن 2", "فصل اول - الف\nمتن 3", "فصل اول - الف\nمتن 4") +
            listOf("فصل دوم - ب\nمتن 5", "فصل دوم - ب\nمتن 6", "فصل دوم - ب\nمتن 7")
        val headers = PageStructure.detectHeaders(pages)
        assertTrue("فصل اول - الف" in headers)
        assertTrue("فصل دوم - ب" in headers)
        val s = PageStructure.stripHeaders(pages, headers)
        assertEquals("متن 1", s.pages[0])
        assertEquals("فصل اول - الف", s.chapters[2])
        assertEquals("فصل دوم - ب", s.chapters[6])
    }

    @Test
    fun chunkerKeepsClausesPagesAndHeadings() {
        val pages = listOf(
            "4-1-1 عنوان یک\nمتن بند یک ادامه\n4-1-1-1 زیر بند اول\n4-1-1-2 زیر بند دوم شروع",
            "ادامه زیر بند دوم در صفحه بعد"
        )
        val chunks = Chunker.chunk(pages, listOf("فصل ۱", "فصل ۱"))
        assertEquals(listOf("4-1-1", "4-1-1-1", "4-1-1-2"), chunks.map { it.clause })
        assertTrue(chunks[1].heading.startsWith("4-1-1 "))
        assertEquals(1, chunks[2].pageFrom)
        assertEquals(2, chunks[2].pageTo)
        assertEquals("فصل ۱", chunks[0].chapter)
    }

    @Test
    fun chunkerWithoutClausesStillChunksByPage() {
        val chunks = Chunker.chunk(listOf("یک متن ساده بدون شماره بند"), listOf(""))
        assertEquals(1, chunks.size)
        assertEquals("", chunks[0].clause)
    }

    @Test
    fun veryLongTextIsSplit() {
        val long = (1..400).joinToString(" ") { "جمله شماره $it است." }
        val chunks = Chunker.chunk(listOf("4-1-1 $long"), listOf("فصل"))
        assertTrue(chunks.size >= 2)
        assertTrue(chunks.all { it.text.length <= 1500 })
    }
}
