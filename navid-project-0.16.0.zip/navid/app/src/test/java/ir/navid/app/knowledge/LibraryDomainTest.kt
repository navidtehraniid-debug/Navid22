package ir.navid.app.knowledge

import ir.navid.app.domain.LibraryNaming
import ir.navid.app.domain.SourceGroups
import ir.navid.app.domain.StoragePolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LibraryDomainTest {
    @Test
    fun extensionIsLowercasedAndSanitized() {
        assertEquals("pdf", LibraryNaming.extensionOf("Book.PDF"))
        assertEquals("gz", LibraryNaming.extensionOf("a.tar.gz"))
        assertEquals("", LibraryNaming.extensionOf("name."))
        assertEquals("", LibraryNaming.extensionOf("noext"))
        assertEquals("", LibraryNaming.extensionOf("bad.p-f"))
    }

    @Test
    fun supportedFormats() {
        assertTrue("pdf" in LibraryNaming.supportedExtensions)
        assertTrue("docx" in LibraryNaming.supportedExtensions)
        assertFalse("exe" in LibraryNaming.supportedExtensions)
        assertEquals("application/pdf", LibraryNaming.mimeFor("pdf"))
    }

    @Test
    fun guessTitleAndYearFromFileName() {
        val g = LibraryNaming.guess("Mabhas4-v3_0-1396-ATNasr_ir.pdf")
        assertEquals(1396, g.year)
        assertEquals("Mabhas4-v3 0-1396-ATNasr ir", g.title)
        val p = LibraryNaming.guess("مبحث_چهارم_1396.pdf")
        assertEquals("مبحث چهارم 1396", p.title)
        assertEquals(1396, p.year)
        assertEquals(2019, LibraryNaming.guess("book (2019).pdf").year)
        assertNull(LibraryNaming.guess("12345.pdf").year)
        assertEquals("سند بدون عنوان", LibraryNaming.guess("").title)
    }

    @Test
    fun storagePolicyHonorsCap() {
        assertTrue(StoragePolicy.allows(0, 10, 100))
        assertTrue(StoragePolicy.allows(90, 10, 100))
        assertFalse(StoragePolicy.allows(95, 10, 100))
        assertFalse(StoragePolicy.allows(0, -1, 100))
        assertFalse(StoragePolicy.allows(-1, 10, 100))
    }

    @Test
    fun sizeFormatting() {
        assertEquals("512 بایت", StoragePolicy.formatSize(512))
        assertEquals("2 کیلوبایت", StoragePolicy.formatSize(2048))
        assertEquals("5.0 مگابایت", StoragePolicy.formatSize(5L * 1024 * 1024))
        assertEquals("3.0 گیگابایت", StoragePolicy.formatSize(3L * 1024 * 1024 * 1024))
    }

    @Test
    fun fourSourceGroupsWithDefault() {
        assertEquals(setOf(1, 2, 3, 4), SourceGroups.labels.keys)
        assertTrue(SourceGroups.DEFAULT in SourceGroups.labels.keys)
    }
}
