package ir.navid.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryTextTest {

    @Test
    fun normalizeCollapsesWhitespaceAndCase() {
        assertEquals("hello world", MemoryText.normalize("  Hello   WORLD \n"))
    }

    @Test
    fun normalizeTreatsHalfSpaceAsSpace() {
        val withHalfSpace = "\u0645\u06CC\u200C\u062E\u0648\u0627\u0647\u0645"
        val withSpace = "\u0645\u06CC \u062E\u0648\u0627\u0647\u0645"
        assertEquals(MemoryText.normalize(withSpace), MemoryText.normalize(withHalfSpace))
    }

    @Test
    fun normalizeUnifiesArabicLettersAndDigits() {
        assertEquals(MemoryText.normalize("\u0643\u062A\u0627\u0628 \u064A\u06A9"), MemoryText.normalize("\u06A9\u062A\u0627\u0628 \u06CC\u06A9"))
        assertEquals("12 345", MemoryText.normalize("\u06F1\u06F2 \u0663\u0664\u0665"))
    }

    @Test
    fun sameContentSameHashDifferentContentDifferentHash() {
        assertEquals(MemoryText.hash("Meeting at 5"), MemoryText.hash("  meeting   at 5 "))
        assertNotEquals(MemoryText.hash("meeting at 5"), MemoryText.hash("meeting at 6"))
        assertEquals(64, MemoryText.hash("x").length)
        assertTrue(MemoryText.hash("x").all { it in '0'..'9' || it in 'a'..'f' })
    }

    @Test
    fun allEightCategoriesHaveLabels() {
        assertEquals(8, MemoryCategory.values().size)
        assertTrue(MemoryCategory.values().all { it.labelFa.isNotBlank() })
    }
}
