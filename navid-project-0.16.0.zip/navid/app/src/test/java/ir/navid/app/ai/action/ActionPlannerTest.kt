package ir.navid.app.ai.action

import ir.navid.app.ai.nlu.CommandParser
import ir.navid.app.ai.nlu.Intent
import ir.navid.app.core.JalaliDate
import ir.navid.app.domain.AccountType
import ir.navid.app.domain.MemoryCategory
import ir.navid.app.domain.TxKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionPlannerTest {
    private val today = JalaliDate(1405, 8, 10)
    private val accounts = listOf(
        AccountRef("a1", "صندوق نقد", AccountType.ASSET),
        AccountRef("a2", "حساب بانکی", AccountType.ASSET),
        AccountRef("i1", "حقوق و دستمزد", AccountType.INCOME),
        AccountRef("i2", "سایر درآمدها", AccountType.INCOME),
        AccountRef("e1", "خوراک", AccountType.EXPENSE),
        AccountRef("e2", "حمل و نقل", AccountType.EXPENSE),
        AccountRef("e3", "قبوض", AccountType.EXPENSE),
        AccountRef("e4", "سلامت", AccountType.EXPENSE),
        AccountRef("e5", "سایر هزینه ها", AccountType.EXPENSE)
    )
    private val assetNames = accounts.filter { it.type == AccountType.ASSET }.map { it.name }

    private fun plan(text: String, forced: Intent? = null, projects: List<ProjectRef> = emptyList()): Proposal {
        val parsed = CommandParser.parse(text, today, assetNames)
        return ActionPlanner.plan(parsed, text, accounts, today, forced, projects)
    }

    private fun money(text: String, forced: Intent? = null) = plan(text, forced) as Proposal.Money

    @Test
    fun fuelExpenseGuessesTransportCategory() {
        val m = money("چهارصد هزار تومان بنزین زدم")
        assertEquals(TxKind.EXPENSE, m.kind)
        assertEquals(400_000L, m.amount)
        assertFalse(m.amountNeedsCheck)
        assertEquals("e2", m.counterId)
        assertEquals("a1", m.primaryId)
        assertFalse(m.dateFromText)
        assertEquals(today, m.date)
    }

    @Test
    fun mentionedBankIsUsedAndFoodGuessed() {
        val m = money("از بانک 200 هزار تومان برای نهار دادم")
        assertEquals("a2", m.primaryId)
        assertEquals("e1", m.counterId)
        assertEquals(200_000L, m.amount)
    }

    @Test
    fun salaryWithoutAmountLeavesAmountEmpty() {
        val m = money("حقوقم واریز شد")
        assertEquals(TxKind.INCOME, m.kind)
        assertNull(m.amount)
        assertEquals("i1", m.counterId)
    }

    @Test
    fun transferKeepsOrderOfMentionedAccounts() {
        val m = money("5 میلیون از بانک به صندوق منتقل کردم")
        assertEquals(TxKind.TRANSFER, m.kind)
        assertEquals("a2", m.primaryId)
        assertEquals("a1", m.counterId)
        assertEquals(5_000_000L, m.amount)
        assertFalse("TRANSFER_ACCOUNTS_UNCERTAIN" in m.warnings)
    }

    @Test
    fun transferWithOneAccountWarnsAboutDirection() {
        val m = money("انتقال 5 میلیون از بانک")
        assertEquals(TxKind.TRANSFER, m.kind)
        assertTrue("TRANSFER_ACCOUNTS_UNCERTAIN" in m.warnings)
    }

    @Test
    fun rangeAmountNeedsCheck() {
        val m = money("از 2 تا 3 میلیون خرج کردم")
        assertEquals(3_000_000L, m.amount)
        assertTrue(m.amountNeedsCheck)
    }

    @Test
    fun twoAmountsLeaveAmountEmptyAndNeedCheck() {
        val m = money("5 میلیون و 3 میلیون خرج کردم")
        assertNull(m.amount)
        assertTrue(m.amountNeedsCheck)
    }

    @Test
    fun noteStripsPrefix() {
        val n = plan("یادداشت کن که کد تخفیف سه شنبه تموم میشه") as Proposal.Note
        assertEquals(MemoryCategory.NOTES, n.category)
        assertEquals("کد تخفیف سه شنبه تموم میشه", n.content)
    }

    @Test
    fun siteReportBecomesBuildingNoteWithHonestInfo() {
        val n = plan("بتن ریزی فونداسیون انجام شد") as Proposal.Note
        assertEquals(MemoryCategory.BUILDING, n.category)
        assertTrue(n.info != null)
    }

    @Test
    fun technicalQuestionGoesToTheLibrary() {
        val p = plan("حداقل پهنای مفید در ورودی اتاق اقامت چقدر است؟")
        assertTrue(p is Proposal.Knowledge)
        assertEquals("حداقل پهنای مفید در ورودی اتاق اقامت چقدر است؟", (p as Proposal.Knowledge).query)
    }

    @Test
    fun financeQuestionIsUnsupportedWithoutModel() {
        assertTrue(plan("امروز چقدر خرج کردم؟") is Proposal.Unsupported)
    }

    @Test
    fun reminderWithDateAndTimeFromText() {
        val r = plan("فردا ساعت 10 با پیمانکار نازک کاری جلسه دارم، یادم بنداز.") as Proposal.Reminder
        assertEquals("فردا ساعت 10 با پیمانکار نازک کاری جلسه دارم", r.title)
        assertEquals(JalaliDate(1405, 8, 11), r.date)
        assertEquals(10, r.hour)
        assertEquals(0, r.minute)
        assertTrue(r.dateFromText)
        assertTrue(r.timeFromText)
    }

    @Test
    fun reminderWithoutDateOrTimeUsesVisibleDefaults() {
        val r = plan("یادم بنداز جلسه") as Proposal.Reminder
        assertEquals("جلسه", r.title)
        assertNull(r.date)
        assertFalse(r.dateFromText)
        assertFalse(r.timeFromText)
        assertEquals(ActionPlanner.DEFAULT_REMINDER_HOUR, r.hour)
        assertEquals(ActionPlanner.DEFAULT_REMINDER_MINUTE, r.minute)
    }

    @Test
    fun reminderTitleFallsBackToSentence() {
        assertEquals("یادم باشه", ReminderTitle.clean("یادم باشه"))
    }

    @Test
    fun ambiguousSentenceAsksUserThenPlansAfterChoice() {
        val text = "حقوق گرفتم و 3 میلیون هم خرج کردم"
        val choice = plan(text) as Proposal.Choice
        assertEquals(listOf(Intent.INCOME, Intent.EXPENSE), choice.options)
        val m = money(text, Intent.EXPENSE)
        assertEquals(TxKind.EXPENSE, m.kind)
        assertEquals(3_000_000L, m.amount)
    }

    @Test
    fun unknownSentenceOffersDefaultChoices() {
        val c = plan("سلام") as Proposal.Choice
        assertEquals(4, c.options.size)
    }

    @Test
    fun siteReportWithPaymentGivesExpenseAndFlag() {
        val m = money("امروز ستون های طبقه دوم آرماتوربندی شد و 15 میلیون تومان دستمزد پرداخت کردم.")
        assertEquals(TxKind.EXPENSE, m.kind)
        assertEquals(15_000_000L, m.amount)
        assertTrue(m.alsoSiteReport)
        assertTrue(m.dateFromText)
        assertEquals("e5", m.counterId)
    }

    @Test
    fun siteReportWithOneProjectIsRealReportForThatProject() {
        val p = listOf(ProjectRef("p1", "برج"))
        val r = plan("بتن ریزی فونداسیون انجام شد", projects = p) as Proposal.SiteReport
        assertEquals("p1", r.projectId)
    }

    @Test
    fun siteReportWithTwoProjectsLeavesChoiceToUser() {
        val p = listOf(ProjectRef("p1", "برج"), ProjectRef("p2", "ویلا"))
        val r = plan("بتن ریزی فونداسیون انجام شد", projects = p) as Proposal.SiteReport
        assertNull(r.projectId)
    }

    @Test
    fun siteReportExpenseGetsDefaultProjectOnlyWhenSingle() {
        val text = "امروز ستون های طبقه دوم آرماتوربندی شد و 15 میلیون تومان دستمزد پرداخت کردم."
        val one = plan(text, projects = listOf(ProjectRef("p1", "برج"))) as Proposal.Money
        assertEquals("p1", one.projectId)
        val two = plan(text, projects = listOf(ProjectRef("p1", "برج"), ProjectRef("p2", "ویلا"))) as Proposal.Money
        assertNull(two.projectId)
        val plain = plan("چهارصد هزار تومان بنزین زدم", projects = listOf(ProjectRef("p1", "برج"))) as Proposal.Money
        assertNull(plain.projectId)
    }
}
