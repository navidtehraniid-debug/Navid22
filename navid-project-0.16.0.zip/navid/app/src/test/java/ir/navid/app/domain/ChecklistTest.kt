package ir.navid.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChecklistTest {
    @Test
    fun parserStripsBulletsAndNumbers() {
        val text = "- مورد اول\n• مورد دوم\n۱- مورد سوم\n2. مورد چهارم\n\n   \n5 میلیون هزینه\n* پنجم"
        assertEquals(
            listOf("مورد اول", "مورد دوم", "مورد سوم", "مورد چهارم", "5 میلیون هزینه", "پنجم"),
            ChecklistParser.parseItems(text)
        )
    }

    @Test
    fun parserLimits() {
        val many = (1..300).joinToString("\n") { "مورد $it" }
        assertEquals(200, ChecklistParser.parseItems(many).size)
        assertEquals(300, ChecklistParser.parseItems("ا".repeat(500)).single().length)
        assertTrue(ChecklistParser.parseItems("  \n \n").isEmpty())
    }

    @Test
    fun summaryCountsAndPercent() {
        val s = ChecklistMath.summarize(
            listOf(CheckStatus.APPROVED, CheckStatus.APPROVED, CheckStatus.REJECTED, CheckStatus.NEEDS_REVIEW, CheckStatus.NOT_APPLICABLE, CheckStatus.PENDING, CheckStatus.PENDING, CheckStatus.PENDING)
        )
        assertEquals(8, s.total)
        assertEquals(2, s.approved)
        assertEquals(3, s.pending)
        assertEquals(63, s.checkedPercent)
        assertEquals(0, ChecklistMath.summarize(emptyList()).checkedPercent)
    }

    @Test
    fun sampleTemplateIsFromTheUserListWithoutNumbers() {
        assertEquals(9, SampleChecklists.concretePouring.size)
        assertTrue(SampleChecklists.concretePouring.none { item -> item.any { it.isDigit() } })
    }
}
