package ir.navid.app.knowledge.text

import org.junit.Assert.assertEquals
import org.junit.Test

class PdfTextCleanerTest {
    @Test
    fun digitsAreConvertedToLatin() {
        assertEquals("1396 2", PdfTextCleaner.cleanRaw("\u06F1\u06F3\u06F9\u06F6 \u0662"))
    }

    @Test
    fun clauseNumberGluedToTextGetsASpace() {
        assertEquals("4-3-1-4 \u0633\u0627\u062E\u062A\u0645\u0627\u0646", PdfTextCleaner.cleanRaw("4-3-1-4\u0633\u0627\u062E\u062A\u0645\u0627\u0646"))
    }

    @Test
    fun misplacedCommaIsFixed() {
        assertEquals("\u0641\u0631\u0647\u0646\u06AF\u06CC\u060C \u0635\u0646\u0627\u06CC\u0639", PdfTextCleaner.cleanRaw("\u0641\u0631\u0647\u0646\u06AF\u06CC \u060C\u0635\u0646\u0627\u06CC\u0639"))
    }

    @Test
    fun directionControlsAreRemoved() {
        assertEquals("4-1", PdfTextCleaner.cleanRaw("\u202B4-1\u202C"))
    }

    @Test
    fun arabicLettersBecomePersianAndTatweelIsDropped() {
        assertEquals("\u06A9\u062A\u0627\u0628 \u06CC\u06A9", PdfTextCleaner.cleanRaw("\u0643\u062A\u0627\u0628 \u064A\u0643"))
        assertEquals("\u0635\u0646\u0627\u06CC\u0639", PdfTextCleaner.cleanRaw("\u0635\u0640\u0646\u0627\u06CC\u0639"))
    }

    @Test
    fun halfSpaceBecomesSpace() {
        assertEquals("\u0645\u06CC \u0634\u0648\u062F", PdfTextCleaner.cleanRaw("\u0645\u06CC\u200C\u0634\u0648\u062F"))
    }

    @Test
    fun qualityScore() {
        assertEquals(1.0f, PdfTextCleaner.qualityScore("\u0633\u0644\u0627\u0645 \u062F\u0646\u06CC\u0627"), 0.001f)
        assertEquals(0.0f, PdfTextCleaner.qualityScore("abc 123"), 0.001f)
        assertEquals(0.0f, PdfTextCleaner.qualityScore(""), 0.001f)
    }
}
