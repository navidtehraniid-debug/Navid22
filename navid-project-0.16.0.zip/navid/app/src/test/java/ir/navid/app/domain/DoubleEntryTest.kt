package ir.navid.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class DoubleEntryTest {

    @Test
    fun expenseIsBalancedAndValid() {
        val lines = DoubleEntry.expense("cash", "food", 15_000_000)
        assertNull(DoubleEntry.validate(lines))
        assertEquals(15_000_000L, lines.sumOf { it.debit })
        assertEquals(15_000_000L, lines.sumOf { it.credit })
        assertEquals(15_000_000L, lines.first { it.accountId == "food" }.debit)
        assertEquals(15_000_000L, lines.first { it.accountId == "cash" }.credit)
    }

    @Test
    fun incomeIsBalancedAndValid() {
        val lines = DoubleEntry.income("bank", "salary", 40_000_000)
        assertNull(DoubleEntry.validate(lines))
        assertEquals(40_000_000L, lines.first { it.accountId == "bank" }.debit)
        assertEquals(40_000_000L, lines.first { it.accountId == "salary" }.credit)
    }

    @Test
    fun transferTouchesOnlyGivenAccounts() {
        val lines = DoubleEntry.transfer("bank", "cash", 5_000_000)
        assertNull(DoubleEntry.validate(lines))
        assertEquals(setOf("bank", "cash"), lines.map { it.accountId }.toSet())
    }

    @Test
    fun rejectsTransferToSameAccount() {
        assertNotNull(DoubleEntry.validate(DoubleEntry.transfer("cash", "cash", 1000)))
    }

    @Test
    fun rejectsUnbalancedZeroNegativeAndHuge() {
        assertNotNull(DoubleEntry.validate(listOf(EntryLine("a", 100, 0), EntryLine("b", 0, 90))))
        assertNotNull(DoubleEntry.validate(DoubleEntry.expense("a", "b", 0)))
        assertNotNull(DoubleEntry.validate(listOf(EntryLine("a", -5, 0), EntryLine("b", 0, -5))))
        assertNotNull(DoubleEntry.validate(DoubleEntry.expense("a", "b", DoubleEntry.MAX_AMOUNT + 1)))
        assertNotNull(DoubleEntry.validate(listOf(EntryLine("a", 100, 0))))
        assertNotNull(DoubleEntry.validate(listOf(EntryLine("a", 5, 5), EntryLine("b", 0, 0))))
    }

    @Test
    fun balancesFollowAccountNature() {
        // دارایی با افتتاحیه 100، بدهکار 50، بستانکار 20 => 130
        assertEquals(130L, DoubleEntry.balanceOf(AccountType.ASSET, 50, 20, 100))
        // هزینه جمع بدهکار منهای بستانکار
        assertEquals(30L, DoubleEntry.balanceOf(AccountType.EXPENSE, 50, 20))
        // درآمد جمع بستانکار منهای بدهکار
        assertEquals(30L, DoubleEntry.balanceOf(AccountType.INCOME, 20, 50))
        // بدهی
        assertEquals(130L, DoubleEntry.balanceOf(AccountType.LIABILITY, 20, 50, 100))
    }

    @Test
    fun expenseThenTransferDoesNotDoubleCountExpense() {
        // انتقال 5 میلیون از بانک به صندوق و بعد هزینه 2 میلیون از صندوق: هزینه فقط 2 میلیون است.
        val all = DoubleEntry.transfer("bank", "cash", 5_000_000) +
            DoubleEntry.expense("cash", "food", 2_000_000)
        val expenseTotal = all.filter { it.accountId == "food" }.sumOf { it.debit - it.credit }
        assertEquals(2_000_000L, expenseTotal)
        val cash = DoubleEntry.balanceOf(
            AccountType.ASSET,
            all.filter { it.accountId == "cash" }.sumOf { it.debit },
            all.filter { it.accountId == "cash" }.sumOf { it.credit }
        )
        assertEquals(3_000_000L, cash)
    }
}
