package ir.navid.app.ai.nlu

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MiniJsonTest {
    @Test
    fun parsesFlatObject() {
        val m = MiniJson.parseObject("""{"intent": "expense", "amount": 15000000, "date": null, "ok": true, "x": 1.5}""")!!
        assertEquals("expense", m["intent"])
        assertEquals(15000000L, m["amount"])
        assertNull(m["date"])
        assertEquals(true, m["ok"])
        assertEquals(1.5, m["x"])
    }

    @Test
    fun ignoresTextAndFencesAroundObject() {
        val m = MiniJson.parseObject("Result:\n```json\n{\"a\": 1}\n```\nDone")!!
        assertEquals(1L, m["a"])
    }

    @Test
    fun negativeNumbersAndEmptyObject() {
        assertEquals(-3L, MiniJson.parseObject("""{"a": -3}""")!!["a"])
        assertEquals(0, MiniJson.parseObject("{}")!!.size)
    }

    @Test
    fun stringEscapes() {
        assertEquals("x\"y", MiniJson.parseObject("""{"a":"x\"y"}""")!!["a"])
        assertEquals("\u0627", MiniJson.parseObject("""{"a":"\u0627"}""")!!["a"])
    }

    @Test
    fun rejectsInvalid() {
        assertNull(MiniJson.parseObject("no json here"))
        assertNull(MiniJson.parseObject("{'a': 1}"))
        assertNull(MiniJson.parseObject("""{"a": }"""))
        assertNull(MiniJson.parseObject("""{"a": 1,}"""))
        assertNull(MiniJson.parseObject("""{"a": [1,2]}"""))
        assertNull(MiniJson.parseObject("""{"a": "unterminated}"""))
    }
}
