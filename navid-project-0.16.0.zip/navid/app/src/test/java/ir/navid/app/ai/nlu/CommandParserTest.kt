package ir.navid.app.ai.nlu

import ir.navid.app.core.JalaliDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    private val today = JalaliDate(1405, 8, 10)
    private val accounts = listOf("صندوق نقد", "حساب بانکی")
    private fun parse(t: String) = CommandParser.parse(t, today, accounts)

    @Test
    fun siteReportAndExpenseFromOneSentence() {
        val p = parse("امروز ستون های طبقه دوم آرماتوربندی شد و 15 میلیون تومان دستمزد پرداخت کردم.")
        assertEquals(listOf(Intent.SITE_REPORT, Intent.EXPENSE), p.intents)
        assertEquals(15_000_000L, p.safeAmount)
        assertEquals(today, p.date.date)
        assertTrue(p.missing.isEmpty())
        assertFalse(p.needsModel)
    }

    @Test
    fun incomeWithoutAmountNeverInventsOne() {
        val p = parse("حقوقم واریز شد")
        assertEquals(listOf(Intent.INCOME), p.intents)
        assertTrue(p.amounts.isEmpty())
        assertNull(p.safeAmount)
        assertEquals(listOf(MissingField.AMOUNT), p.missing)
    }

    @Test
    fun reminderWithDateAndTime() {
        val p = parse("فردا ساعت 10 با پیمانکار نازک کاری جلسه دارم، یادم بنداز.")
        assertEquals(listOf(Intent.REMINDER), p.intents)
        assertEquals(JalaliDate(1405, 8, 11), p.date.date)
        assertEquals(10, p.date.hour)
        assertEquals(0, p.date.minute)
        assertTrue(p.missing.isEmpty())
    }

    @Test
    fun reminderWithoutDateIsMissingDate() {
        val p = parse("یادم بنداز جلسه")
        assertEquals(listOf(MissingField.DATE), p.missing)
    }

    @Test
    fun wordAmountIsExactNotTenTimesOff() {
        assertEquals(400_000L, parse("چهارصد هزار تومان بنزین زدم").safeAmount)
    }

    @Test
    fun rangeAmountRequiresConfirmation() {
        val p = parse("از 2 تا 3 میلیون خرج کردم")
        assertNull(p.safeAmount)
        assertTrue("AMOUNT_RANGE" in p.warnings)
    }

    @Test
    fun multipleAmountsAreFlagged() {
        val p = parse("5 میلیون و 3 میلیون خرج کردم")
        assertNull(p.safeAmount)
        assertTrue("MULTIPLE_AMOUNTS" in p.warnings)
    }

    @Test
    fun ambiguousIntentGoesToModelOrUser() {
        val p = parse("حقوق گرفتم و 3 میلیون هم خرج کردم")
        assertTrue(p.intents.isEmpty())
        assertEquals(listOf(Intent.INCOME, Intent.EXPENSE), p.candidates)
        assertTrue(p.needsModel)
        assertTrue(p.hasMoneyIntent)
        assertTrue("AMBIGUOUS_INTENT" in p.warnings)
    }

    @Test
    fun greetingIsUnknown() {
        val p = parse("سلام")
        assertTrue(p.needsModel)
        assertFalse(p.hasMoneyIntent)
    }

    @Test
    fun tooLargeAmountIsRejected() {
        assertTrue(parse("9999999999999999 تومان").amounts.isEmpty())
    }
}
