package ir.navid.app.domain

import ir.navid.app.data.LineEntity
import ir.navid.app.data.TransactionEntity
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.data.amount
import ir.navid.app.data.counterAccountId
import ir.navid.app.data.primaryAccountId
import org.junit.Assert.assertEquals
import org.junit.Test

class TrashAndAccessorsTest {

    private fun item(kind: TxKind, entry: List<EntryLine>): TransactionWithLines {
        val tx = TransactionEntity(
            id = "t1",
            ledger = LedgerKind.PERSONAL,
            occurredAt = 0,
            localDate = "2026-10-31",
            kind = kind,
            dataClass = DataClass.ACTUAL,
            status = TxStatus.CONFIRMED,
            description = "",
            source = TxSource.MANUAL,
            createdAt = 0,
            updatedAt = 0
        )
        val lines = entry.mapIndexed { i, e -> LineEntity("l$i", "t1", e.accountId, e.debit, e.credit) }
        return TransactionWithLines(tx, lines)
    }

    @Test
    fun expenseAccessors() {
        val it = item(TxKind.EXPENSE, DoubleEntry.expense("cash", "food", 1000))
        assertEquals("cash", it.primaryAccountId())
        assertEquals("food", it.counterAccountId())
        assertEquals(1000L, it.amount())
    }

    @Test
    fun incomeAccessors() {
        val it = item(TxKind.INCOME, DoubleEntry.income("bank", "salary", 5000))
        assertEquals("bank", it.primaryAccountId())
        assertEquals("salary", it.counterAccountId())
        assertEquals(5000L, it.amount())
    }

    @Test
    fun transferAccessors() {
        val it = item(TxKind.TRANSFER, DoubleEntry.transfer("bank", "cash", 700))
        assertEquals("bank", it.primaryAccountId())
        assertEquals("cash", it.counterAccountId())
        assertEquals(700L, it.amount())
    }

    @Test
    fun trashCutoffIsThirtyDaysBack() {
        val now = 100L * 24 * 60 * 60 * 1000
        assertEquals(70L * 24 * 60 * 60 * 1000, Trash.purgeCutoff(now))
        assertEquals(30, Trash.RETENTION_DAYS)
    }
}
