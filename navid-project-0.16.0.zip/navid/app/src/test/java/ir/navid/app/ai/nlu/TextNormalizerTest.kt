package ir.navid.app.ai.nlu

import org.junit.Assert.assertEquals
import org.junit.Test

class TextNormalizerTest {
    @Test
    fun arabicLettersAndDigits() {
        assertEquals("\u06A9\u062A\u0627\u0628 \u06CC\u06A9", TextNormalizer.normalize("\u0643\u062A\u0627\u0628  \u064A\u0643"))
        assertEquals("15", TextNormalizer.normalize("  \u06F1\u06F5 "))
    }

    @Test
    fun halfSpaceBecomesSpace() {
        assertEquals("\u0645\u06CC \u062E\u0648\u0627\u0647\u0645", TextNormalizer.normalize("\u0645\u06CC\u200C\u062E\u0648\u0627\u0647\u0645"))
    }

    @Test
    fun thousandSeparatorsRemoved() {
        assertEquals("1500000", TextNormalizer.normalize("1,500,000"))
        assertEquals("1500000", TextNormalizer.normalize("\u06F1\u066C\u06F5\u06F0\u06F0\u066C\u06F0\u06F0\u06F0"))
    }

    @Test
    fun tokenizeKeepsPunctuationAsTokens() {
        val t = TextNormalizer.tokenize("15 \u0645\u06CC\u0644\u06CC\u0648\u0646.")
        assertEquals(3, t.size)
        assertEquals("15", t[0].text)
        assertEquals(".", t[2].text)
    }
}
