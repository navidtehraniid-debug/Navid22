package ir.navid.app.knowledge.text

import ir.navid.app.domain.DocStatus
import ir.navid.app.domain.PageRefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchTextTest {
    @Test
    fun clauseAndWordsAreSeparated() {
        val p = SearchText.parse("بند 4-1-5-1 مدارک")
        assertEquals("4-1-5-1", p.clause)
        assertEquals(listOf("بند", "مدارک"), p.tokens)
        assertEquals("بند* مدارک*", p.andExpr)
        assertEquals("بند* OR مدارک* OR \"بند مدارک\" OR بندمدارک", p.orExpr)
    }

    @Test
    fun persianDigitsInClauseAreAccepted() {
        assertEquals("4-1-5-1", SearchText.parse("\u06F4-\u06F1-\u06F5-\u06F1").clause)
    }

    @Test
    fun onlyStopwordsGivesNoExpression() {
        val p = SearchText.parse("و در به")
        assertNull(p.clause)
        assertNull(p.andExpr)
        assertNull(p.orExpr)
    }

    @Test
    fun yearIsNotAClause() {
        val p = SearchText.parse("سال 1396")
        assertNull(p.clause)
        assertEquals(listOf("سال", "1396"), p.tokens)
    }

    @Test
    fun lightStemmerOnlyRemovesPlurals() {
        assertEquals("ساختمان", SearchText.stem("ساختمانهای"))
        assertEquals("کتاب", SearchText.stem("کتابها"))
        assertEquals("ها", SearchText.stem("ها"))
        assertEquals("ساختمان", SearchText.stem("ساختمان"))
        assertEquals("نقشه", SearchText.stem("نقشه"))
    }

    @Test
    fun rankingPrefersMatchingChunksAndAppliesMultipliers() {
        val a = RankInput(listOf("ساختمان", "میراث", "فرهنگی"), true, false, 1, DocStatus.CURRENT)
        val b = RankInput(listOf("ساختمان", "آب"), true, false, 1, DocStatus.CURRENT)
        val q = listOf("میراث", "فرهنگی")
        val df = mapOf("میراث" to 1, "فرهنگی" to 1)
        assertTrue(Ranking.bm25(q, a, 3, 2.0, df) > 0.0)
        assertEquals(0.0, Ranking.bm25(q, b, 3, 2.0, df), 0.0001)
        val front = a.copy(frontMatter = true)
        assertTrue(Ranking.bm25(q, front, 3, 2.0, df) < Ranking.bm25(q, a, 3, 2.0, df))
        val old = a.copy(status = DocStatus.SUPERSEDED)
        assertTrue(Ranking.bm25(q, old, 3, 2.0, df) < Ranking.bm25(q, a, 3, 2.0, df))
        val g4 = a.copy(sourceGroup = 4)
        assertTrue(Ranking.bm25(q, g4, 3, 2.0, df) < Ranking.bm25(q, a, 3, 2.0, df))
    }

    @Test
    fun snippetContainsTheQueryWord() {
        val text = "الف ".repeat(100) + "کلمه_مورد_نظر" + " ب".repeat(200)
        val s = Ranking.snippet(text, listOf("کلمه_مورد_نظر"))
        assertTrue(s.contains("کلمه_مورد_نظر"))
        assertTrue(s.length <= 310)
    }

    @Test
    fun pageReferencesShowPrintedAndFilePage() {
        assertEquals(7, PageRefs.printed(20, 13))
        assertNull(PageRefs.printed(10, 13))
        assertNull(PageRefs.printed(20, null))
        assertEquals("صفحه چاپی ۷ (صفحه ۲۰ فایل)", PageRefs.format(20, 20, 13))
        assertEquals("صفحه چاپی ۷ تا ۸ (صفحه ۲۰ تا ۲۱ فایل)", PageRefs.format(20, 21, 13))
        assertEquals("صفحه ۵ فایل", PageRefs.format(5, 5, 13))
        assertEquals("صفحه ۲۰ فایل", PageRefs.format(20, 20, null))
    }

    @Test
    fun clauseNumberIsRecognizedInEveryWritingStyle() {
        val forms = listOf(
            "4-1-5-1", "\u06F4-\u06F1-\u06F5-\u06F1", "4 - 1 - 5 - 1", "\u06F4\u2013\u06F1\u2013\u06F5\u2013\u06F1",
            "4\u22121\u22125\u22121", "4.1.5.1", "4/1/5/1", "4_1_5_1", "\u06F4\u0640\u06F1\u0640\u06F5\u0640\u06F1",
            "\u06F4 \u06F1 \u06F5 \u06F1", "04-01-05-01", "بند 4-1-5-1", "بند \u06F4-\u06F1-\u06F5-\u06F1"
        )
        for (f in forms) {
            val p = SearchText.parse(f)
            assertEquals("شکل: $f", "4-1-5-1", p.clause)
            assertEquals("شکل: $f", "1-5-1-4", p.clauseAlt)
        }
    }

    @Test
    fun reversedAndPalindromeClauses() {
        val r = SearchText.parse("1-5-1-4")
        assertEquals("1-5-1-4", r.clause)
        assertEquals("4-1-5-1", r.clauseAlt)
        assertNull(SearchText.parse("4-1-4").clauseAlt)
    }

    @Test
    fun decimalsYearsAndAmountsAreNotClauses() {
        assertNull(SearchText.parse("0.8 متر").clause)
        assertNull(SearchText.parse("سال 1396").clause)
        assertNull(SearchText.parse("1,500 تومان").clause)
    }

    @Test
    fun clauseWithWordsKeepsWords() {
        val p = SearchText.parse("بند \u06F4\u2013\u06F1\u2013\u06F5\u2013\u06F1 مدارک")
        assertEquals("4-1-5-1", p.clause)
        assertEquals(listOf("بند", "مدارک"), p.tokens)
    }
}
