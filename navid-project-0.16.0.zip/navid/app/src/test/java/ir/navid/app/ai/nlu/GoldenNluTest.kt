package ir.navid.app.ai.nlu

import ir.navid.app.core.JalaliDate
import ir.navid.app.core.PersianNumberWords
import org.junit.Assert.assertTrue
import org.junit.Test

/** مجموعه آزمون طلایی: همان فایل با پیاده سازی مرجع Python هم راستی آزمایی شده است. */
class GoldenNluTest {
    private val today = JalaliDate(1405, 8, 10)
    private val accounts = listOf("صندوق نقد", "حساب بانکی")

    private fun loadCases(): List<Triple<String, String, String>> {
        val stream = javaClass.classLoader!!.getResourceAsStream("nlu_golden.tsv")
        requireNotNull(stream) { "nlu_golden.tsv پیدا نشد" }
        return stream.bufferedReader(Charsets.UTF_8).readLines()
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .map { line ->
                val p = line.split("\t")
                Triple(p[0], p[1].replace("<ZWNJ>", "\u200C"), p[2])
            }
    }

    @Test
    fun goldenSetIsLargeEnough() {
        assertTrue(loadCases().size >= 100)
    }

    @Test
    fun allGoldenCasesPass() {
        val failures = ArrayList<String>()
        for ((kind, input, expected) in loadCases()) {
            val norm = TextNormalizer.normalize(input)
            val got = when (kind) {
                "AMOUNT" -> AmountExtractor.toGoldenString(norm)
                "DATE" -> DateExtractor.toGoldenString(norm, today)
                "INTENT" -> IntentRules.classify(norm, accounts).toGoldenString()
                "ACCOUNTS" -> IntentRules.accountsMentionedOrdered(norm, accounts).joinToString("|").ifEmpty { "none" }
                "WORDS" -> PersianNumberWords.toWords(input.toLong())
                else -> "UNKNOWN_KIND"
            }
            if (got != expected) failures.add("$kind [$input] expected=$expected got=$got")
        }
        assertTrue("${failures.size} مورد ناموفق:\n" + failures.joinToString("\n"), failures.isEmpty())
    }
}
