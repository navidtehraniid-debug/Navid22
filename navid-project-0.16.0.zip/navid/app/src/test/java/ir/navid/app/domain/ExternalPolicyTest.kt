package ir.navid.app.domain

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExternalPolicyTest {
    @Test
    fun defaultsFollowSourceGroup() {
        assertTrue(ExternalPolicy.allowed(null, 1))
        assertTrue(ExternalPolicy.allowed(null, 2))
        assertFalse(ExternalPolicy.allowed(null, 3))
        assertFalse(ExternalPolicy.allowed(null, 4))
    }

    @Test
    fun explicitChoiceWins() {
        assertTrue(ExternalPolicy.allowed(true, 4))
        assertFalse(ExternalPolicy.allowed(false, 1))
    }
}
