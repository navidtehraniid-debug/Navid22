package ir.navid.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectContextTest {
    private data class P(val order: Int, val status: PhaseStatus, val name: String)

    private fun current(ps: List<P>) = CurrentPhase.of(ps, { it.order }, { it.status })

    @Test
    fun currentPhaseIsFirstInProgressThenFirstNotStarted() {
        val ps = listOf(
            P(3, PhaseStatus.NOT_STARTED, "ج"), P(1, PhaseStatus.DONE, "الف"),
            P(2, PhaseStatus.IN_PROGRESS, "ب"), P(4, PhaseStatus.IN_PROGRESS, "د")
        )
        assertEquals("ب", current(ps)!!.name)
        assertEquals("ج", current(ps.filter { it.status != PhaseStatus.IN_PROGRESS })!!.name)
        assertNull(current(listOf(P(1, PhaseStatus.DONE, "الف"))))
        assertNull(current(emptyList()))
    }

    @Test
    fun phaseKeysMatchPhaseName() {
        assertTrue(PhaseMatch.matches("فونداسیون، اسکلت", "فونداسیون"))
        assertTrue(PhaseMatch.matches("اسکلت", "اسکلت و سقف"))
        assertTrue(PhaseMatch.matches("فونداسیون,اسکلت", "اسکلت"))
        assertFalse(PhaseMatch.matches("نما", "فونداسیون"))
        assertFalse(PhaseMatch.matches("", "فونداسیون"))
        assertFalse(PhaseMatch.matches("فونداسیون", null))
        assertFalse(PhaseMatch.matches("نم", "نما")) // کلید کوتاه تر از 3 نویسه نادیده گرفته می شود
    }

    @Test
    fun documentRolesHaveLabels() {
        assertEquals(5, DocRole.values().size)
        assertTrue(DocRole.values().all { it.labelFa.isNotBlank() })
    }
}
