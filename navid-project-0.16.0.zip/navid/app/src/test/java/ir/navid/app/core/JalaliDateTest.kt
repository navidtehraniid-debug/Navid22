package ir.navid.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class JalaliDateTest {

    @Test
    fun knownNowruzDates() {
        assertEquals(JalaliDate(1399, 1, 1), JalaliDate.from(LocalDate.of(2020, 3, 20)))
        assertEquals(JalaliDate(1400, 1, 1), JalaliDate.from(LocalDate.of(2021, 3, 21)))
        assertEquals(JalaliDate(1403, 1, 1), JalaliDate.from(LocalDate.of(2024, 3, 20)))
        assertEquals(JalaliDate(1404, 1, 1), JalaliDate.from(LocalDate.of(2025, 3, 21)))
        assertEquals(JalaliDate(1405, 1, 1), JalaliDate.from(LocalDate.of(2026, 3, 21)))
    }

    @Test
    fun lastDayOfLeapYear() {
        assertEquals(JalaliDate(1403, 12, 30), JalaliDate.from(LocalDate.of(2025, 3, 20)))
    }

    @Test
    fun specificDay() {
        assertEquals(JalaliDate(1405, 8, 9), JalaliDate.from(LocalDate.of(2026, 10, 31)))
    }

    @Test
    fun leapYears() {
        assertTrue(JalaliDate.isLeap(1399))
        assertTrue(JalaliDate.isLeap(1403))
        assertTrue(JalaliDate.isLeap(1408))
        assertFalse(JalaliDate.isLeap(1404))
        assertFalse(JalaliDate.isLeap(1405))
    }

    @Test
    fun roundTripForManyYears() {
        var date = LocalDate.of(2015, 1, 1)
        val end = LocalDate.of(2045, 1, 1)
        while (date.isBefore(end)) {
            assertEquals(date, JalaliDate.from(date).toLocalDate())
            date = date.plusDays(1)
        }
    }

    @Test
    fun parseAcceptsLatinAndPersianDigits() {
        assertEquals(JalaliDate(1405, 8, 9), JalaliDate.parse("1405/08/09"))
        assertEquals(JalaliDate(1405, 8, 9), JalaliDate.parse("۱۴۰۵/۰۸/۰۹"))
    }

    @Test
    fun parseRejectsInvalid() {
        assertNull(JalaliDate.parse("1404/13/01"))
        assertNull(JalaliDate.parse("1404/12/30"))
        assertNull(JalaliDate.parse("abc"))
        assertNull(JalaliDate.parse(""))
    }

    @Test
    fun formatting() {
        assertEquals("1405/08/09", JalaliDate(1405, 8, 9).format())
        assertEquals("۹ آبان ۱۴۰۵", JalaliDate(1405, 8, 9).formatLong())
    }
}
