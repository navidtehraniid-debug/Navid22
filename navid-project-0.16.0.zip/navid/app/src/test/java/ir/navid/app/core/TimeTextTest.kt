package ir.navid.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimeTextTest {
    @Test
    fun parsesCommonForms() {
        assertEquals(Pair(10, 0), TimeText.parse("10"))
        assertEquals(Pair(10, 30), TimeText.parse("10:30"))
        assertEquals(Pair(10, 30), TimeText.parse("\u06F1\u06F0:\u06F3\u06F0"))
        assertEquals(Pair(7, 5), TimeText.parse(" 7:05 "))
        assertEquals(Pair(0, 0), TimeText.parse("0:00"))
        assertEquals(Pair(23, 59), TimeText.parse("23:59"))
    }

    @Test
    fun rejectsInvalid() {
        assertNull(TimeText.parse("25:00"))
        assertNull(TimeText.parse("10:60"))
        assertNull(TimeText.parse("abc"))
        assertNull(TimeText.parse(""))
        assertNull(TimeText.parse("10:5"))
    }

    @Test
    fun formatPadsZeros() {
        assertEquals("07:05", TimeText.format(7, 5))
    }
}
