package ir.navid.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PersianTextTest {

    @Test
    fun digitConversion() {
        assertEquals("۱۲۳۴۵", "12345".toPersianDigits())
        assertEquals("12345", "۱۲۳۴۵".toLatinDigits())
        assertEquals("12345", "١٢٣٤٥".toLatinDigits())
    }

    @Test
    fun formatToman() {
        assertEquals("۱٬۵۰۰٬۰۰۰ تومان", 1_500_000L.formatToman())
        assertEquals("۰ تومان", 0L.formatToman())
        assertEquals("۹۹۹ تومان", 999L.formatToman())
        assertEquals("−۱٬۰۰۰ تومان", (-1000L).formatToman())
    }

    @Test
    fun parseAmountValid() {
        assertEquals(1_500_000L, parseAmount("۱٬۵۰۰٬۰۰۰"))
        assertEquals(1_500_000L, parseAmount("1,500,000"))
        assertEquals(15L, parseAmount(" 15 "))
    }

    @Test
    fun parseAmountInvalid() {
        assertNull(parseAmount(""))
        assertNull(parseAmount("0"))
        assertNull(parseAmount("abc"))
        assertNull(parseAmount("12.5"))
        assertNull(parseAmount("-5"))
        assertNull(parseAmount("9999999999999999"))
    }
}
