package ir.navid.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class JalaliCalendarTest {
    @Test
    fun abanOf1405StartsOnFriday() {
        val grid = JalaliCalendar.monthGrid(1405, 8)
        assertEquals(6, grid.size)
        assertTrue7(grid)
        for (i in 0..5) assertNull(grid[0][i])
        assertEquals(1, grid[0][6])
        assertEquals(30, grid[5][0])
        assertEquals(30, grid.flatten().filterNotNull().size)
    }

    @Test
    fun farvardinOf1405StartsOnSaturday() {
        val grid = JalaliCalendar.monthGrid(1405, 1)
        assertEquals(listOf(1, 2, 3, 4, 5, 6, 7), grid[0])
        assertEquals(31, grid.flatten().filterNotNull().size)
    }

    @Test
    fun leapEsfandHasThirtyDays() {
        val grid = JalaliCalendar.monthGrid(1403, 12)
        assertEquals(30, grid.flatten().filterNotNull().size)
        assertEquals(5, grid.size)
    }

    @Test
    fun shiftCrossesYearBoundaries() {
        assertEquals(Pair(1404, 12), JalaliCalendar.shift(1405, 1, -1))
        assertEquals(Pair(1406, 1), JalaliCalendar.shift(1405, 12, 1))
        assertEquals(Pair(1405, 11), JalaliCalendar.shift(1405, 8, 3))
        assertEquals(Pair(1404, 12), JalaliCalendar.shift(1405, 8, -8))
    }

    private fun assertTrue7(grid: List<List<Int?>>) {
        grid.forEach { assertEquals(7, it.size) }
    }
}
