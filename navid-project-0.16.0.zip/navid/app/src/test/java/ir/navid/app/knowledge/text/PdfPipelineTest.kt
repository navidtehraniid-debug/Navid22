package ir.navid.app.knowledge.text

import ir.navid.app.domain.DocStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * آزمون روی خروجی خام واقعی pdftotext از صفحه های 1 تا 26 «مبحث چهارم مقررات ملی ساختمان، ویرایش 1396»
 * (src/test/resources/mabhas4_raw_p1_26.txt). مقدارهای مورد انتظار قبلاً با پیاده سازی مرجع Python به دست آمده اند.
 */
class PdfPipelineTest {

    private fun loadRawPages(): List<String> {
        val stream = javaClass.classLoader!!.getResourceAsStream("mabhas4_raw_p1_26.txt")
        requireNotNull(stream) { "فایل نمونه پیدا نشد" }
        val text = stream.bufferedReader(Charsets.UTF_8).readText()
        return text.split("\n<<<PAGE>>>\n").map { it.replace("<ZWNJ>", "\u200C") }
    }

    private val raw = loadRawPages()
    private val result = TextPipeline.process(raw)

    @Test
    fun fixtureHasTwentySixPages() {
        assertEquals(26, raw.size)
        assertEquals(26, result.pages.size)
    }

    @Test
    fun clauseOrientationIsDetectedFromTheDocumentItself() {
        val o = result.orientation
        assertTrue(o.reversed)
        assertEquals(0, o.rawTotal)
        assertTrue(o.revTotal >= 50)
        assertEquals(o.revTotal, o.revOk)
    }

    @Test
    fun printedPageOffsetIsThirteen() {
        assertEquals(13, result.printedOffset)
    }

    @Test
    fun runningHeadersAreStrippedAndChapterIsKept() {
        val page20Lines = result.pages[19].split("\n")
        assertFalse(page20Lines.any { it.trim().startsWith("فصل اول") })
        assertTrue(result.chapters[19].startsWith("فصل اول"))
        assertTrue(result.headerCount >= 2)
    }

    @Test
    fun printedPageNumberLineIsRemoved() {
        val lines = result.pages[19].split("\n").map { it.trim() }
        assertFalse(lines.contains("7"))
    }

    @Test
    fun noArabicPresentationFormsRemain() {
        val bad = result.pages.joinToString("").any { it in '\uFB50'..'\uFDFF' || it in '\uFE70'..'\uFEFF' }
        assertFalse(bad)
        val controls = result.pages.joinToString("").any { it in '\u202A'..'\u202E' || it in '\u2066'..'\u2069' }
        assertFalse(controls)
    }

    @Test
    fun knownClauseIsExtractedWithCorrectNumberHeadingAndPage() {
        val c = result.chunks.first { it.clause == "4-1-3-4" && it.pageFrom == 20 }
        assertTrue(c.text.startsWith("4-1-3-4 "))
        assertTrue(c.text.contains("میراث فرهنگی"))
        assertTrue(c.heading.startsWith("4-1-3 "))
        assertTrue(c.chapter.startsWith("فصل اول"))
    }

    @Test
    fun chunkCountsAreReasonable() {
        assertTrue(result.chunks.size in 100..130)
        assertTrue(result.chunks.count { it.clause.isNotEmpty() } >= 95)
        assertTrue(result.chunks.all { it.text.length <= 1500 })
    }

    private fun rankAll(query: String): List<TextChunk> {
        val chunks = result.chunks
        val parsed = SearchText.parse(query)
        val tokenLists = chunks.map { SearchText.tokens(it.text + " " + it.heading + " " + it.chapter) }
        val avg = tokenLists.map { it.size }.average()
        val df = parsed.tokens.toSet().associateWith { t -> tokenLists.count { l -> l.any { it.startsWith(t) } } }
        return chunks.indices
            .map { i ->
                val input = RankInput(tokenLists[i], chunks[i].clause.isNotEmpty(), chunks[i].chapter.isEmpty(), 1, DocStatus.CURRENT)
                Pair(i, Ranking.bm25(parsed.tokens, input, chunks.size, avg, df))
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .map { chunks[it.first] }
    }

    @Test
    fun searchRanksTheRightClauseFirst() {
        assertEquals("4-1-3-4", rankAll("ساختمان های ثبت شده میراث فرهنگی").first().clause)
        assertEquals("4-1-5-1", rankAll("مالکان اراضی پروانه ساختمان مدارک فنی").first().clause)
    }

    @Test
    fun glueAndSpacedFormsBothFindTheSameClause() {
        // در فایل «ساختمانهای ثبتشده» چسبیده است؛ پرسش با فاصله هم باید همان بند را بیاورد
        assertEquals("4-1-3-4", rankAll("ساختمان\u200Cهای ثبت\u200Cشده توسط سازمان میراث فرهنگی").first().clause)
    }
}
