package ir.navid.app.ai.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExternalApiProtocolTest {
    private val anthropic = ExternalConfig(ApiFormat.ANTHROPIC, "https://api.anthropic.com/", "m1", "KEY")
    private val openai = ExternalConfig(ApiFormat.OPENAI, "https://example.com/v1", "m2", "KEY")
    private val req = ModelRequest("سیستم \"x\"", "کاربر\nخط دوم", 300, 0.0)

    @Test
    fun endpointsAndHeaders() {
        assertEquals("https://api.anthropic.com/v1/messages", ExternalApiProtocol.endpoint(anthropic))
        assertEquals("https://example.com/v1/chat/completions", ExternalApiProtocol.endpoint(openai))
        assertEquals("https://example.com/v1/chat/completions", ExternalApiProtocol.endpoint(openai.copy(baseUrl = "https://example.com")))
        assertEquals("KEY", ExternalApiProtocol.headers(anthropic)["x-api-key"])
        assertEquals("Bearer KEY", ExternalApiProtocol.headers(openai)["Authorization"])
    }

    @Test
    fun jsonStringEscapes() {
        assertEquals("\"a\\\"b\\\\c\\nd\"", ExternalApiProtocol.jsonString("a\"b\\c\nd"))
    }

    @Test
    fun requestBodiesCarryModelSystemAndUser() {
        val a = ExternalApiProtocol.requestBody(anthropic, req)
        assertTrue(a.contains("\"model\":\"m1\"") && a.contains("\"system\":") && a.contains("\"role\":\"user\""))
        val o = ExternalApiProtocol.requestBody(openai, req)
        assertTrue(o.contains("\"role\":\"system\"") && o.contains("\"model\":\"m2\""))
        assertTrue(a.contains("\\\"x\\\"") && a.contains("\\n"))
    }

    @Test
    fun responsesAreParsed() {
        val a = "{\"id\":\"1\",\"content\":[{\"type\":\"text\",\"text\":\"سلام \\\"دنیا\\\"\\n\\u0627\"}],\"usage\":{}}"
        assertEquals("سلام \"دنیا\"\nا", ExternalApiProtocol.parseResponse(ApiFormat.ANTHROPIC, a))
        val o = "{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"پاسخ\"}}]}"
        assertEquals("پاسخ", ExternalApiProtocol.parseResponse(ApiFormat.OPENAI, o))
        assertNull(ExternalApiProtocol.parseResponse(ApiFormat.OPENAI, "{\"choices\":[]}"))
        assertEquals("نامعتبر", ExternalApiProtocol.firstString("{\"error\":{\"message\":\"نامعتبر\"}}", "message"))
    }
}
