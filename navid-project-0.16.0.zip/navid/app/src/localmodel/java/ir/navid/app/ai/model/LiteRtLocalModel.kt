package ir.navid.app.ai.model

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * مدل محلی با LiteRT-LM (API رسمی Kotlin، فایل .litertlm). فقط در ساخت آزمایشی (-PlocalModel=true) کامپایل می شود.
 * پشتیبان CPU انتخاب شده چون پشتیبانی GPU روی Exynos 990 تضمین نشده است. API از مستندات رسمی گرفته شده و روی گوشی آزمایش نشده است.
 */
class LiteRtLocalModel(private val modelPath: String, private val cacheDir: String) : LanguageModel {
    override val name: String get() = "مدل محلی (LiteRT-LM، CPU)"
    private var engine: Engine? = null

    override suspend fun generate(request: ModelRequest): ModelResult = withContext(Dispatchers.Default) {
        try {
            val started = System.currentTimeMillis()
            val e = engine ?: Engine(EngineConfig(modelPath = modelPath, backend = Backend.CPU(), cacheDir = cacheDir))
                .also {
                    it.initialize()
                    engine = it
                }
            val config = ConversationConfig(
                systemInstruction = Contents.of(request.system),
                samplerConfig = SamplerConfig(topK = 10, topP = 0.95, temperature = 0.2)
            )
            val text = e.createConversation(config).use { it.sendMessage(request.user).toString() }
            ModelResult.Ok(text, System.currentTimeMillis() - started)
        } catch (t: Throwable) {
            ModelResult.Error("خطای مدل محلی: " + (t.message ?: t.javaClass.simpleName).take(160))
        }
    }

    override fun close() {
        try {
            engine?.close()
        } catch (t: Throwable) {
            // نادیده گرفته می شود
        }
        engine = null
    }
}
