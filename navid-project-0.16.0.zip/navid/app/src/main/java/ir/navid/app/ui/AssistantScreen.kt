package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.navid.app.ai.action.AccountRef
import ir.navid.app.ai.action.ActionPlanner
import androidx.compose.material3.AlertDialog
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import ir.navid.app.ai.model.ModelProvider
import ir.navid.app.ai.rag.RagPrompt
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.Divider
import ir.navid.app.core.toPersianDigits
import ir.navid.app.domain.PageRefs
import ir.navid.app.knowledge.data.SearchHit
import ir.navid.app.ai.action.ProjectRef
import ir.navid.app.ai.action.Proposal
import ir.navid.app.ai.nlu.CommandParser
import ir.navid.app.ai.nlu.Intent
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.PersianNumberWords
import ir.navid.app.core.TimeText
import ir.navid.app.core.formatToman
import ir.navid.app.core.parseAmount
import ir.navid.app.domain.AccountType
import ir.navid.app.domain.MemoryCategory
import ir.navid.app.domain.ReminderLevel
import ir.navid.app.domain.TxKind

private fun warningText(code: String): String? = when (code) {
    "MULTIPLE_AMOUNTS" -> "در جمله چند مبلغ هست؛ مبلغ درست را خودتان وارد کنید."
    "AMOUNT_RANGE" -> "مبلغ به صورت بازه نوشته شده؛ مقدار دقیق را بررسی کنید."
    "AMOUNT_APPROX" -> "مبلغ تقریبی است؛ مقدار دقیق را بررسی کنید."
    "AMOUNT_RELATIVE" -> "مبلغ نسبی است (برابر یا درصد)؛ مقدار نهایی را خودتان وارد کنید."
    "AMOUNT_TRAILING" -> "بعد از مبلغ عدد دیگری هست و ممکن است مبلغ ناقص خوانده شده باشد."
    "TRANSFER_ACCOUNTS_UNCERTAIN" -> "مبدأ و مقصد انتقال را بررسی کنید."
    else -> null
}

/** دستیار فعلی: بدون مدل هوش مصنوعی. جمله را با قواعد و کد تحلیل می کند و فقط پس از تأیید شما ثبت می کند. */
@Composable
fun AssistantScreen(
    vm: FinanceViewModel,
    memoryVm: MemoryViewModel,
    reminderVm: ReminderViewModel,
    buildingVm: BuildingViewModel,
    libraryVm: LibraryViewModel,
    onOpenLibrary: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val accounts by vm.accounts.collectAsState()
    val projectList by buildingVm.projects.collectAsState()
    val projectRefs = projectList.map { ProjectRef(it.id, it.name) }
    val refs = accounts.map { AccountRef(it.id, it.name, it.type) }
    var input by remember { mutableStateOf("") }
    var proposal by remember { mutableStateOf<Proposal?>(null) }
    var analyzedText by remember { mutableStateOf("") }
    var resultMessage by remember { mutableStateOf<String?>(null) }

    fun analyze(force: Intent?) {
        val today = JalaliDate.today()
        val assetNames = refs.filter { it.type == AccountType.ASSET }.map { it.name }
        val parsed = CommandParser.parse(input, today, assetNames)
        analyzedText = input
        proposal = ActionPlanner.plan(parsed, input, refs, today, force, projectRefs)
        resultMessage = null
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("دستیار", style = MaterialTheme.typography.headlineSmall)
        Text(
            "فعلاً بدون مدل هوش مصنوعی است: جمله را با قواعد و کد تحلیل می کند و فقط بعد از تأیید شما ثبت می کند.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("مثلاً: چهارصد هزار تومان بنزین زدم") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { analyze(null) }, enabled = input.isNotBlank()) { Text("تحلیل") }

        resultMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
        }

        val p = proposal
        if (p != null) {
            key(p) {
                when (p) {
                    is Proposal.Money -> MoneyCard(p, refs, projectRefs, analyzedText, vm, memoryVm, buildingVm) { message ->
                        resultMessage = message
                        proposal = null
                        input = ""
                    }
                    is Proposal.Note -> NoteCard(p, memoryVm) { message ->
                        resultMessage = message
                        proposal = null
                        input = ""
                    }
                    is Proposal.SiteReport -> SiteReportCard(p, projectRefs, buildingVm) { message ->
                        resultMessage = message
                        proposal = null
                        input = ""
                    }
                    is Proposal.Reminder -> ReminderCard(p, reminderVm) { message ->
                        resultMessage = message
                        proposal = null
                        input = ""
                    }
                    is Proposal.Choice -> SectionCard("نوع پیام مشخص نیست؛ کدام را می خواهید؟") {
                        p.options.forEach { option ->
                            OutlinedButton(onClick = { analyze(option) }, modifier = Modifier.fillMaxWidth()) {
                                Text(intentLabel(option))
                            }
                        }
                    }
                    is Proposal.Knowledge -> KnowledgeCard(p.query, libraryVm, onOpenLibrary)
                    is Proposal.Unsupported -> SectionCard("فعلاً ممکن نیست") { Text(p.reason) }
                }
            }
        }
    }
}

@Composable
private fun MoneyCard(
    p: Proposal.Money,
    refs: List<AccountRef>,
    projects: List<ProjectRef>,
    original: String,
    vm: FinanceViewModel,
    memoryVm: MemoryViewModel,
    buildingVm: BuildingViewModel,
    onSaved: (String) -> Unit
) {
    val assets = refs.filter { it.type == AccountType.ASSET }
    var amountText by remember { mutableStateOf(p.amount?.toString() ?: "") }
    var dateText by remember { mutableStateOf(p.date.format()) }
    var description by remember { mutableStateOf(p.description) }
    var primaryId by remember { mutableStateOf(p.primaryId) }
    var counterId by remember { mutableStateOf(p.counterId) }
    var saveSite by remember { mutableStateOf(p.alsoSiteReport) }
    var projectId by remember { mutableStateOf(p.projectId) }
    var checked by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val counterList = when (p.kind) {
        TxKind.EXPENSE -> refs.filter { it.type == AccountType.EXPENSE }
        TxKind.INCOME -> refs.filter { it.type == AccountType.INCOME }
        TxKind.TRANSFER -> assets.filter { it.id != primaryId }
    }
    val needsCheck = p.amountNeedsCheck || "TRANSFER_ACCOUNTS_UNCERTAIN" in p.warnings
    val amount = parseAmount(amountText)
    val canSave = amount != null && (!needsCheck || checked)
    val title = when (p.kind) {
        TxKind.EXPENSE -> "ثبت هزینه"
        TxKind.INCOME -> "ثبت درآمد"
        TxKind.TRANSFER -> "ثبت انتقال بین حساب ها"
    }

    SectionCard(title) {
        if (amount != null) {
            Text(amount.formatToman(), style = MaterialTheme.typography.headlineSmall)
            Text(PersianNumberWords.toWords(amount) + " تومان", style = MaterialTheme.typography.bodyMedium)
        } else {
            Text("مبلغ پیدا نشد؛ لطفاً وارد کنید.", color = MaterialTheme.colorScheme.error)
        }
        OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it; error = null },
            label = { Text("مبلغ (تومان)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = dateText,
            onValueChange = { dateText = it; error = null },
            label = { Text(if (p.dateFromText) "تاریخ شمسی (از جمله)" else "تاریخ شمسی (در جمله نبود؛ امروز)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("توضیحات") },
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            when (p.kind) {
                TxKind.EXPENSE -> "پرداخت از"
                TxKind.INCOME -> "واریز به"
                TxKind.TRANSFER -> "از حساب"
            },
            style = MaterialTheme.typography.labelLarge
        )
        assets.forEach { acc -> AccountChoice(acc.name, primaryId == acc.id) { primaryId = acc.id } }
        Text(
            when (p.kind) {
                TxKind.EXPENSE -> "دسته بندی هزینه"
                TxKind.INCOME -> "نوع درآمد"
                TxKind.TRANSFER -> "به حساب"
            },
            style = MaterialTheme.typography.labelLarge
        )
        counterList.forEach { acc -> AccountChoice(acc.name, counterId == acc.id) { counterId = acc.id } }

        if (p.kind == TxKind.EXPENSE && projects.isNotEmpty()) {
            Text("پروژه ساختمانی (اختیاری)", style = MaterialTheme.typography.labelLarge)
            AccountChoice("بدون پروژه", projectId == null) { projectId = null }
            projects.forEach { pr -> AccountChoice(pr.name, projectId == pr.id) { projectId = pr.id } }
        }

        p.warnings.mapNotNull { warningText(it) }.forEach {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        if (p.alsoSiteReport) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = saveSite, onCheckedChange = { saveSite = it })
                Text(if (projectId != null) "گزارش کارگاه را هم برای این پروژه ثبت کن" else "گزارش کارگاه را هم به صورت یادداشت «ساختمان» ذخیره کن")
            }
        }
        if (needsCheck) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = checked, onCheckedChange = { checked = it })
                Text("مبلغ و حساب ها را بررسی کردم")
            }
        }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Button(
            enabled = canSave,
            onClick = {
                vm.save(p.kind, primaryId, counterId, amountText, dateText, description, null, projectId) { result ->
                    if (result == null) {
                        if (saveSite) {
                            if (projectId != null) {
                                buildingVm.addReport(projectId!!, null, dateText, original) { }
                            } else {
                                memoryVm.save(null, MemoryCategory.BUILDING, "گزارش کارگاه", original) { }
                            }
                        }
                        onSaved("ثبت شد: " + (parseAmount(amountText)?.formatToman() ?: ""))
                    } else {
                        error = result
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تأیید و ثبت") }
    }
}

@Composable
private fun NoteCard(p: Proposal.Note, memoryVm: MemoryViewModel, onSaved: (String) -> Unit) {
    var title by remember { mutableStateOf(p.title) }
    var content by remember { mutableStateOf(p.content) }
    var error by remember { mutableStateOf<String?>(null) }
    SectionCard("ذخیره یادداشت (دسته: ${p.category.labelFa})") {
        p.info?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("عنوان (اختیاری)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = content,
            onValueChange = { content = it; error = null },
            label = { Text("متن") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Button(
            onClick = {
                memoryVm.save(null, p.category, title, content) { result ->
                    if (result == null) onSaved("یادداشت ذخیره شد.") else error = result
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تأیید و ذخیره") }
    }
}

@Composable
private fun ReminderCard(p: Proposal.Reminder, reminderVm: ReminderViewModel, onSaved: (String) -> Unit) {
    var title by remember { mutableStateOf(p.title) }
    var dateText by remember { mutableStateOf(p.date?.format() ?: "") }
    var timeText by remember { mutableStateOf(TimeText.format(p.hour, p.minute)) }
    var level by remember { mutableStateOf(ReminderLevel.NORMAL) }
    var error by remember { mutableStateOf<String?>(null) }

    SectionCard("ثبت یادآوری") {
        if (!p.dateFromText) {
            Text("تاریخ در جمله نبود؛ لطفاً تاریخ را وارد کنید.", color = MaterialTheme.colorScheme.error)
        }
        if (!p.timeFromText) {
            Text("ساعت در جمله نبود؛ ساعت پیش فرض ۷:۳۰ گذاشته شد. در صورت نیاز تغییر دهید.", style = MaterialTheme.typography.bodySmall)
        }
        OutlinedTextField(
            value = title,
            onValueChange = { title = it; error = null },
            label = { Text("عنوان") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = dateText,
            onValueChange = { dateText = it; error = null },
            label = { Text("تاریخ شمسی (سال/ماه/روز)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = timeText,
            onValueChange = { timeText = it; error = null },
            label = { Text("ساعت (مثلاً 10:30)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("اهمیت", style = MaterialTheme.typography.labelLarge)
        ReminderLevel.values().forEach { l -> AccountChoice(l.labelFa, level == l) { level = l } }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Button(
            onClick = {
                reminderVm.save(null, title, dateText, timeText, level) { result ->
                    if (result == null) onSaved("یادآوری ثبت شد.") else error = result
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تأیید و ثبت یادآوری") }
    }
}

@Composable
private fun SiteReportCard(
    p: Proposal.SiteReport,
    projects: List<ProjectRef>,
    buildingVm: BuildingViewModel,
    onSaved: (String) -> Unit
) {
    var text by remember { mutableStateOf(p.text) }
    var dateText by remember { mutableStateOf(JalaliDate.today().format()) }
    var projectId by remember { mutableStateOf(p.projectId) }
    var error by remember { mutableStateOf<String?>(null) }
    SectionCard("ثبت گزارش کارگاه") {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; error = null },
            label = { Text("متن گزارش") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = dateText,
            onValueChange = { dateText = it; error = null },
            label = { Text("تاریخ شمسی") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("پروژه", style = MaterialTheme.typography.labelLarge)
        projects.forEach { pr -> AccountChoice(pr.name, projectId == pr.id) { projectId = pr.id; error = null } }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Button(
            enabled = projectId != null,
            onClick = {
                val id = projectId
                if (id != null) {
                    buildingVm.addReport(id, null, dateText, text) { result ->
                        if (result == null) onSaved("گزارش کارگاه ثبت شد.") else error = result
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تأیید و ثبت گزارش") }
    }
}

@Composable
private fun KnowledgeCard(query: String, libraryVm: LibraryViewModel, onOpenLibrary: (String) -> Unit) {
    val ai: AiViewModel = viewModel()
    val settings by ai.settings.collectAsState()
    val scope = rememberCoroutineScope()
    var hits by remember(query) { mutableStateOf<List<SearchHit>?>(null) }
    var consent by remember(query) { mutableStateOf(false) }
    var running by remember(query) { mutableStateOf(false) }
    var result by remember(query) { mutableStateOf<AnswerResult?>(null) }
    LaunchedEffect(query) { hits = libraryVm.ask(query, 5) }

    fun run() {
        val list = hits ?: return
        running = true
        result = null
        scope.launch {
            result = ai.answer(query, list)
            running = false
        }
    }

    SectionCard("گزیده های مرتبط از کتابخانه") {
        Text(
            "این پاسخ نهایی نیست: فقط متن های پیدا شده در کتاب های خودتان با ارجاع نشان داده می شود. تصمیم فنی با تأیید مهندس مسئول است.",
            style = MaterialTheme.typography.bodySmall
        )
        val list = hits
        if (list == null) Text("در حال جست وجو...")
        else if (list.isEmpty()) {
            Text("در کتابخانه منبعی برای این پرسش پیدا نشد و جواب را حدس نمی زنم. کتاب یا مبحث مرتبط را به کتابخانه اضافه و «استخراج متن» را بزنید.")
        }
        list?.take(3)?.forEach { h ->
            Divider()
            Text(h.title, style = MaterialTheme.typography.titleSmall)
            val where = listOfNotNull(h.clause.takeIf { it.isNotEmpty() }?.let { "بند $it" }, h.chapter.takeIf { it.isNotEmpty() }).joinToString("  •  ")
            if (where.isNotEmpty()) Text(where.toPersianDigits(), style = MaterialTheme.typography.bodySmall)
            Text(PageRefs.format(h.pageFrom, h.pageTo, h.printedOffset), style = MaterialTheme.typography.bodySmall)
            val badges = listOfNotNull(if (h.governing) "نسخه حاکم پروژه" else null, if (h.phaseMatch) "مرتبط با مرحله فعلی" else null)
            if (badges.isNotEmpty()) Text(badges.joinToString("  •  "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(h.snippet, style = MaterialTheme.typography.bodyMedium)
        }
        if (!list.isNullOrEmpty() && settings.provider != ModelProvider.NONE) {
            Button(
                onClick = { if (settings.provider == ModelProvider.EXTERNAL) consent = true else run() },
                enabled = !running,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (running) "در حال نوشتن پاسخ..." else "پاسخ با مدل، فقط از همین منابع") }
        }
        result?.let { AnswerView(it) }
        OutlinedButton(onClick = { onOpenLibrary(query) }, modifier = Modifier.fillMaxWidth()) {
            Text("همه نتیجه ها و باز کردن صفحه در کتابخانه")
        }
    }

    val list = hits
    if (consent && list != null) {
        val sendable = list.filter { it.externalAllowed }
        val blocked = list.size - sendable.size
        val sources = RagPrompt.sourcesFrom(sendable)
        val chars = query.length + sources.sumOf { it.text.length }
        AlertDialog(
            onDismissRequest = { consent = false },
            title = { Text("ارسال به سرویس بیرونی؟") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "پرسش شما و ${sources.size} گزیده از کتابخانه (حدود $chars نویسه) به «${ai.modelDescription()}» فرستاده می شود. این گزیده ها از کتاب هایی است که خودتان بارگذاری کرده اید. اطلاعات مالی و اطلاعات پروژه ارسال نمی شود.".toPersianDigits(),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text("پرسش: $query", style = MaterialTheme.typography.bodySmall)
                    if (blocked > 0) Text("$blocked گزیده به دلیل قفل ارسال سند فرستاده نمی شود.".toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                    sources.forEach { Text("[${it.id}] ${it.reference}".toPersianDigits(), style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = { TextButton(onClick = { consent = false; run() }) { Text("ارسال") } },
            dismissButton = { TextButton(onClick = { consent = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun AnswerView(r: AnswerResult) {
    when (r) {
        is AnswerResult.Error -> Text(r.message, color = MaterialTheme.colorScheme.error)
        is AnswerResult.Done -> {
            Divider()
            Text("پاسخ مدل (" + r.modelName + ")", style = MaterialTheme.typography.titleSmall)
            if (r.validated.noAnswer) Text("مدل اعلام کرد در منابع پاسخی پیدا نشد.")
            r.validated.sentences.forEach { s ->
                if (s.supported) {
                    Text((s.text + if (s.citations.isNotEmpty()) "  [" + s.citations.joinToString("][") + "]" else "").toPersianDigits(), style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text(
                        (s.text + "\n(تأیید نشده در منابع: " + (s.problem ?: "") + ")").toPersianDigits(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            if (r.validated.usedSourceIds.isNotEmpty()) {
                Text("منبع ها:", style = MaterialTheme.typography.labelLarge)
                r.sources.filter { it.id in r.validated.usedSourceIds }.forEach {
                    Text("[${it.id}] ${it.reference}".toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                }
            }
            Text(
                "این متن را مدل نوشته؛ فقط ارجاع و عددهایش با منبع تطبیق داده شده است. جمله های قرمز به منبع وصل نشدند. تصمیم فنی با مهندس مسئول است. (${r.millis / 1000.0} ثانیه)".toPersianDigits(),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
