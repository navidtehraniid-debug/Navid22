package ir.navid.app.knowledge.text

import ir.navid.app.domain.DocStatus
import kotlin.math.ln

data class RankInput(
    val tokens: List<String>,
    val hasClause: Boolean,
    val frontMatter: Boolean,
    val sourceGroup: Int,
    val status: DocStatus
)

/** رتبه بندی BM25 در Kotlin روی نامزدهای FTS4 (FTS5 در اندروید در دسترس نیست). */
object Ranking {
    private const val K1 = 1.2
    private const val B = 0.75

    fun bm25(queryTokens: List<String>, input: RankInput, n: Int, avgdl: Double, df: Map<String, Int>): Double {
        val tf = input.tokens.groupingBy { it }.eachCount()
        val dl = input.tokens.size.toDouble()
        val safeAvg = if (avgdl <= 0.0) 1.0 else avgdl
        var s = 0.0
        for (t in queryTokens.toSet()) {
            val f = tf.entries.filter { it.key.startsWith(t) }.sumOf { it.value }
            if (f > 0) {
                val dft = (df[t] ?: 0).coerceAtMost(n)
                val idf = ln(1.0 + (n - dft + 0.5) / (dft + 0.5))
                s += idf * f * (K1 + 1.0) / (f + K1 * ((1.0 - B) + B * dl / safeAvg))
            }
        }
        for (i in 0 until queryTokens.size - 1) {
            if (tf.containsKey(queryTokens[i] + queryTokens[i + 1])) s += 2.0
        }
        return s * multiplier(input)
    }

    fun multiplier(input: RankInput): Double {
        var m = 1.0
        if (input.hasClause) m *= 1.05
        if (input.frontMatter) m *= 0.5
        m *= when (input.sourceGroup) {
            1 -> 1.2
            2 -> 1.1
            3 -> 1.0
            else -> 0.9
        }
        m *= when (input.status) {
            DocStatus.CURRENT -> 1.1
            DocStatus.UNKNOWN -> 1.0
            DocStatus.DRAFT -> 0.85
            DocStatus.SUPERSEDED -> 0.6
        }
        return m
    }

    /** قطعه ای حدود 300 نویسه ای دور اولین کلمه جست وجو. */
    fun snippet(text: String, queryTokens: List<String>, maxLen: Int = 300): String {
        val lower = text.lowercase()
        var idx = -1
        for (t in queryTokens) {
            val i = lower.indexOf(t)
            if (i >= 0 && (idx < 0 || i < idx)) idx = i
        }
        val start = if (idx <= 80) 0 else idx - 80
        val end = minOf(text.length, start + maxLen)
        return (if (start > 0) "…" else "") + text.substring(start, end).trim() + (if (end < text.length) "…" else "")
    }
}
