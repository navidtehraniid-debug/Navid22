package ir.navid.app.data

import ir.navid.app.core.JalaliDate
import ir.navid.app.core.ReminderTime
import ir.navid.app.domain.ReminderLevel
import ir.navid.app.domain.ReminderStatus
import ir.navid.app.domain.Trash
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class ReminderSaveResult(val reminder: ReminderEntity?, val error: String?)

class ReminderRepository(private val dao: ReminderDao) {

    fun observe(): Flow<List<ReminderEntity>> = dao.observeActive()

    suspend fun create(
        title: String,
        date: JalaliDate,
        hour: Int,
        minute: Int,
        level: ReminderLevel,
        source: String = "MANUAL"
    ): ReminderSaveResult {
        val t = title.trim()
        if (t.isEmpty()) return ReminderSaveResult(null, "عنوان یادآوری را وارد کنید")
        if (t.length > 200) return ReminderSaveResult(null, "عنوان بیش از حد طولانی است")
        val dueAt = ReminderTime.dueAtMillis(date, hour, minute)
        val now = System.currentTimeMillis()
        if (dueAt <= now) return ReminderSaveResult(null, "زمان انتخاب شده گذشته است")
        val r = ReminderEntity(
            id = UUID.randomUUID().toString(),
            title = t,
            notes = "",
            dueAt = dueAt,
            localDate = date.toLocalDate().toString(),
            hour = hour,
            minute = minute,
            level = level,
            exact = true,
            status = ReminderStatus.PENDING,
            source = source,
            createdAt = now,
            updatedAt = now
        )
        dao.insert(r)
        return ReminderSaveResult(r, null)
    }

    suspend fun update(
        id: String,
        title: String,
        date: JalaliDate,
        hour: Int,
        minute: Int,
        level: ReminderLevel
    ): ReminderSaveResult {
        val existing = dao.byId(id) ?: return ReminderSaveResult(null, "یادآوری پیدا نشد")
        val t = title.trim()
        if (t.isEmpty()) return ReminderSaveResult(null, "عنوان یادآوری را وارد کنید")
        if (t.length > 200) return ReminderSaveResult(null, "عنوان بیش از حد طولانی است")
        val dueAt = ReminderTime.dueAtMillis(date, hour, minute)
        val now = System.currentTimeMillis()
        if (existing.status == ReminderStatus.PENDING && dueAt <= now) {
            return ReminderSaveResult(null, "زمان انتخاب شده گذشته است")
        }
        val updated = existing.copy(
            title = t,
            dueAt = dueAt,
            localDate = date.toLocalDate().toString(),
            hour = hour,
            minute = minute,
            level = level,
            updatedAt = now
        )
        dao.update(updated)
        return ReminderSaveResult(updated, null)
    }

    suspend fun complete(id: String) = dao.setStatus(id, ReminderStatus.DONE.name, System.currentTimeMillis())
    suspend fun delete(id: String) = dao.softDelete(id, System.currentTimeMillis())
    suspend fun purgeExpired() = dao.purgeDeletedBefore(Trash.purgeCutoff(System.currentTimeMillis()))
}
