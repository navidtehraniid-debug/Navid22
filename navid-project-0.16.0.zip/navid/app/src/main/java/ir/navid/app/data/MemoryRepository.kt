package ir.navid.app.data

import ir.navid.app.domain.MemoryCategory
import ir.navid.app.domain.MemoryText
import ir.navid.app.domain.Trash
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class MemoryRepository(private val dao: MemoryDao) {

    fun search(query: String, category: MemoryCategory?): Flow<List<MemoryEntity>> =
        dao.search(query.trim(), category?.name)

    fun deleted(): Flow<List<MemoryEntity>> = dao.observeDeleted()

    /** ذخیره یا ویرایش. خروجی null یعنی موفق، در غیر این صورت پیام خطا. */
    suspend fun save(editId: String?, category: MemoryCategory, title: String, content: String): String? {
        val text = content.trim()
        if (text.isEmpty()) return "متن را وارد کنید"
        if (text.length > 20000) return "متن بیش از حد طولانی است"
        val hash = MemoryText.hash(text)
        val duplicate = dao.findByHash(hash)
        if (duplicate != null && duplicate.id != editId) {
            return "یک مورد کاملاً مشابه از قبل ذخیره شده است: «${duplicate.title}»"
        }
        val finalTitle = title.trim().ifEmpty { text.lineSequence().first().take(40) }
        val now = System.currentTimeMillis()
        if (editId == null) {
            dao.insert(
                MemoryEntity(
                    id = UUID.randomUUID().toString(),
                    category = category,
                    title = finalTitle,
                    content = text,
                    source = "MANUAL",
                    dedupeHash = hash,
                    createdAt = now,
                    updatedAt = now
                )
            )
        } else {
            val existing = dao.byId(editId) ?: return "مورد پیدا نشد"
            dao.update(
                existing.copy(
                    category = category,
                    title = finalTitle,
                    content = text,
                    dedupeHash = hash,
                    updatedAt = now
                )
            )
        }
        return null
    }

    suspend fun delete(id: String) = dao.softDelete(id, System.currentTimeMillis())
    suspend fun restore(id: String) = dao.restore(id, System.currentTimeMillis())
    suspend fun deletePermanently(id: String) = dao.hardDelete(id)
    suspend fun purgeExpired() = dao.purgeDeletedBefore(Trash.purgeCutoff(System.currentTimeMillis()))
}
