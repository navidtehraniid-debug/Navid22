package ir.navid.app.ai.nlu

/** حروف فارسی و عربی (بدون ارقام و علائم نگارشی) برای ساخت عبارت باقاعده. */
internal const val LETTER = "\u0621-\u063A\u0641-\u064A\u0671-\u06D3"
internal const val NOT_LETTER_BEFORE = "(?<![${LETTER}A-Za-z])"
internal const val NOT_LETTER_AFTER = "(?![${LETTER}A-Za-z])"

data class Token(val text: String, val start: Int, val end: Int)

object TextNormalizer {
    private val thousandComma = Regex("(?<=\\d),(?=\\d{3})")
    private val spaces = Regex("\\s+")
    private val tokenRegex = Regex("\\d+(?:\\.\\d+)?|[${LETTER}A-Za-z]+|[^\\s\\d${LETTER}A-Za-z]")

    /** ارقام فارسی و عربی به لاتین، ی و ک عربی به فارسی، نیم فاصله به فاصله، حذف اعراب، فاصله های اضافه. */
    fun normalize(text: String): String {
        val sb = StringBuilder(text.length)
        for (original in text) {
            var ch = original
            if (ch in '\u064B'..'\u0652' || ch == '\u0640') continue
            ch = when {
                ch == '\u064A' -> '\u06CC'
                ch == '\u0643' -> '\u06A9'
                ch in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                ch in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                ch == '\u200C' -> ' '
                ch == '\u066B' -> '.'
                ch == '\u066C' -> ','
                else -> ch
            }
            sb.append(ch.lowercaseChar())
        }
        var s = thousandComma.replace(sb.toString(), "")
        s = spaces.replace(s, " ").trim()
        return s
    }

    fun tokenize(s: String): List<Token> =
        tokenRegex.findAll(s).map { Token(it.value, it.range.first, it.range.last + 1) }.toList()
}
