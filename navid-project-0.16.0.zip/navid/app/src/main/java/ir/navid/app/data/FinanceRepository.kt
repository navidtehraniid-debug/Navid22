package ir.navid.app.data

import ir.navid.app.domain.AccountType
import ir.navid.app.domain.DataClass
import ir.navid.app.domain.DoubleEntry
import ir.navid.app.domain.EntryLine
import ir.navid.app.domain.LedgerKind
import ir.navid.app.domain.Trash
import ir.navid.app.domain.TxKind
import ir.navid.app.domain.TxSource
import ir.navid.app.domain.TxStatus
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class FinanceRepository(private val dao: FinanceDao) {

    val accounts: Flow<List<AccountEntity>> = dao.observeAccounts()
    val accountTotals: Flow<List<AccountTotals>> = dao.observeAccountTotals()

    fun recent(limit: Int): Flow<List<TransactionWithLines>> = dao.observeRecent(limit)
    fun deleted(): Flow<List<TransactionWithLines>> = dao.observeDeleted()

    fun totalsByType(fromDate: String, toDate: String): Flow<List<TypeTotals>> =
        dao.observeTotalsByType(fromDate, toDate)

    /** حساب های پیش فرض دفتر شخصی در اولین اجرا. */
    suspend fun ensureSeed() {
        if (dao.accountCount() > 0) return
        var order = 0
        fun acc(name: String, type: AccountType, subtype: String) = AccountEntity(
            id = UUID.randomUUID().toString(),
            ledger = LedgerKind.PERSONAL,
            name = name,
            type = type,
            subtype = subtype,
            sortOrder = order++
        )
        dao.insertAccounts(
            listOf(
                acc("صندوق نقد", AccountType.ASSET, "CASH"),
                acc("حساب بانکی", AccountType.ASSET, "BANK"),
                acc("حقوق و دستمزد", AccountType.INCOME, "CATEGORY"),
                acc("سایر درآمدها", AccountType.INCOME, "CATEGORY"),
                acc("خوراک", AccountType.EXPENSE, "CATEGORY"),
                acc("حمل و نقل", AccountType.EXPENSE, "CATEGORY"),
                acc("قبوض", AccountType.EXPENSE, "CATEGORY"),
                acc("سلامت", AccountType.EXPENSE, "CATEGORY"),
                acc("سایر هزینه ها", AccountType.EXPENSE, "CATEGORY")
            )
        )
    }

    private sealed interface Built {
        data class Ok(val lines: List<EntryLine>) : Built
        data class Error(val message: String) : Built
    }

    private suspend fun buildEntry(kind: TxKind, primaryId: String, counterId: String, amount: Long): Built {
        val primary = dao.accountById(primaryId) ?: return Built.Error("حساب انتخاب شده پیدا نشد")
        val counter = dao.accountById(counterId) ?: return Built.Error("حساب انتخاب شده پیدا نشد")
        val typesOk = when (kind) {
            TxKind.EXPENSE -> primary.type == AccountType.ASSET && counter.type == AccountType.EXPENSE
            TxKind.INCOME -> primary.type == AccountType.ASSET && counter.type == AccountType.INCOME
            TxKind.TRANSFER -> primary.type == AccountType.ASSET && counter.type == AccountType.ASSET
        }
        if (!typesOk) return Built.Error("نوع حساب ها با نوع تراکنش سازگار نیست")
        val entry = when (kind) {
            TxKind.EXPENSE -> DoubleEntry.expense(primaryId, counterId, amount)
            TxKind.INCOME -> DoubleEntry.income(primaryId, counterId, amount)
            TxKind.TRANSFER -> DoubleEntry.transfer(primaryId, counterId, amount)
        }
        val error = DoubleEntry.validate(entry)
        return if (error != null) Built.Error(error) else Built.Ok(entry)
    }

    private fun toLines(txId: String, entry: List<EntryLine>): List<LineEntity> = entry.map {
        LineEntity(
            id = UUID.randomUUID().toString(),
            transactionId = txId,
            accountId = it.accountId,
            debit = it.debit,
            credit = it.credit
        )
    }

    /**
     * ثبت یک تراکنش تأییدشده. خروجی null یعنی موفق، در غیر این صورت پیام خطا.
     * primary: هزینه=حساب پرداخت، درآمد=حساب دریافت، انتقال=مبدأ
     * counter: هزینه=دسته، درآمد=نوع درآمد، انتقال=مقصد
     */
    suspend fun record(
        kind: TxKind,
        ledger: LedgerKind,
        primaryAccountId: String,
        counterAccountId: String,
        amount: Long,
        localDate: String,
        description: String,
        source: TxSource = TxSource.MANUAL,
        projectId: String? = null
    ): String? {
        val built = buildEntry(kind, primaryAccountId, counterAccountId, amount)
        if (built is Built.Error) return built.message
        val entry = (built as Built.Ok).lines

        val now = System.currentTimeMillis()
        val txId = UUID.randomUUID().toString()
        val tx = TransactionEntity(
            id = txId,
            ledger = ledger,
            occurredAt = now,
            localDate = localDate,
            kind = kind,
            dataClass = DataClass.ACTUAL,
            status = TxStatus.CONFIRMED,
            description = description.trim(),
            source = source,
            createdAt = now,
            updatedAt = now,
            projectId = if (kind == TxKind.EXPENSE) projectId else null
        )
        dao.insertTransactionWithLines(tx, toLines(txId, entry))
        return null
    }

    /** ویرایش مبلغ، حساب ها، تاریخ و توضیح. نوع تراکنش قابل تغییر نیست. */
    suspend fun update(
        txId: String,
        kind: TxKind,
        primaryAccountId: String,
        counterAccountId: String,
        amount: Long,
        localDate: String,
        description: String,
        projectId: String? = null
    ): String? {
        val existing = dao.txById(txId) ?: return "تراکنش پیدا نشد"
        if (existing.deletedAt != null) return "این تراکنش در سطل بازیافت است"
        if (existing.kind != kind) return "نوع تراکنش قابل تغییر نیست"
        val built = buildEntry(kind, primaryAccountId, counterAccountId, amount)
        if (built is Built.Error) return built.message
        val entry = (built as Built.Ok).lines
        dao.replaceLines(
            txId,
            toLines(txId, entry),
            localDate,
            description.trim(),
            if (kind == TxKind.EXPENSE) projectId else null,
            System.currentTimeMillis()
        )
        return null
    }

    /** افزودن حساب دارایی، دسته هزینه یا نوع درآمد. */
    suspend fun addAccount(name: String, type: AccountType, subtype: String, openingBalance: Long): String? {
        val n = name.trim()
        if (n.isEmpty()) return "نام حساب را وارد کنید"
        if (n.length > 40) return "نام حساب بیش از حد طولانی است"
        if (type != AccountType.ASSET && type != AccountType.INCOME && type != AccountType.EXPENSE) {
            return "این نوع حساب فعلاً پشتیبانی نمی شود"
        }
        if (openingBalance < 0) return "مانده اولیه نمی تواند منفی باشد"
        if (dao.countByName(type.name, n) > 0) return "حسابی با این نام وجود دارد"
        dao.insertAccount(
            AccountEntity(
                id = UUID.randomUUID().toString(),
                ledger = LedgerKind.PERSONAL,
                name = n,
                type = type,
                subtype = subtype,
                openingBalance = if (type == AccountType.ASSET) openingBalance else 0,
                sortOrder = dao.maxSortOrder() + 1
            )
        )
        return null
    }

    suspend fun renameAccount(id: String, name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "نام حساب را وارد کنید"
        if (n.length > 40) return "نام حساب بیش از حد طولانی است"
        val account = dao.accountById(id) ?: return "حساب پیدا نشد"
        if (account.name == n) return null
        if (dao.countByName(account.type.name, n) > 0) return "حسابی با این نام وجود دارد"
        dao.renameAccount(id, n)
        return null
    }

    suspend fun delete(txId: String) = dao.softDelete(txId, System.currentTimeMillis())
    suspend fun restore(txId: String) = dao.restore(txId, System.currentTimeMillis())
    suspend fun deletePermanently(txId: String) = dao.hardDelete(txId)
    suspend fun purgeExpired() = dao.purgeDeletedBefore(Trash.purgeCutoff(System.currentTimeMillis()))
}
