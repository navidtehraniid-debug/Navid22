package ir.navid.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.navid.app.ai.action.ProjectRef
import ir.navid.app.data.MemoryEntity
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.domain.MemoryCategory
import ir.navid.app.domain.TxKind

private data class Tab(val title: String, val emoji: String, val stage: String)

private val tabs = listOf(
    Tab("خانه", "🏠", ""),
    Tab("دستیار", "💬", ""),
    Tab("ساختمان", "🏗", ""),
    Tab("مالی", "💰", ""),
    Tab("ابزارها", "🧰", "")
)

private data class FormState(
    val kind: TxKind,
    val editing: TransactionWithLines?,
    val defaultProjectId: String? = null
)

private data class MemoryForm(val editing: MemoryEntity?, val category: MemoryCategory)

@Composable
fun NavidApp() {
    val vm: FinanceViewModel = viewModel()
    val memoryVm: MemoryViewModel = viewModel()
    val reminderVm: ReminderViewModel = viewModel()
    val buildingVm: BuildingViewModel = viewModel()
    val libraryVm: LibraryViewModel = viewModel()
    val checklistVm: ChecklistViewModel = viewModel()
    val aiVm: AiViewModel = viewModel()
    val projectList by buildingVm.projects.collectAsState()
    val projectRefs = projectList.map { ProjectRef(it.id, it.name) }
    val accounts by vm.accounts.collectAsState()
    val names = accounts.associate { it.id to it.name }

    var tab by rememberSaveable { mutableStateOf(0) }
    var showQuick by remember { mutableStateOf(false) }
    var form by remember { mutableStateOf<FormState?>(null) }
    var selected by remember { mutableStateOf<TransactionWithLines?>(null) }
    var showTrash by remember { mutableStateOf(false) }
    var showAccounts by remember { mutableStateOf(false) }
    var showMemory by remember { mutableStateOf(false) }
    var showNlu by remember { mutableStateOf(false) }
    var showReminders by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var showAi by remember { mutableStateOf(false) }
    var memoryForm by remember { mutableStateOf<MemoryForm?>(null) }
    var showMemoryTrash by remember { mutableStateOf(false) }

    BackHandler(enabled = (showMemory || showNlu || showReminders || showLibrary || showAi) && tab == 4) {
        showMemory = false
        showNlu = false
        showReminders = false
        showLibrary = false
        showAi = false
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, t ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Text(t.emoji) },
                        label = { Text(t.title) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showQuick = true }) { Text("＋") }
        }
    ) { padding ->
        val contentModifier = Modifier.padding(padding)
        when (tab) {
            0 -> HomeScreen(vm, onTxClick = { selected = it }, modifier = contentModifier)
            1 -> AssistantScreen(vm, memoryVm, reminderVm, buildingVm, libraryVm, { q ->
                libraryVm.pendingQuery.value = q
                showLibrary = true
                tab = 4
            }, contentModifier)
            2 -> BuildingScreen(
                vm = buildingVm,
                finVm = vm,
                checklistVm = checklistVm,
                onAddExpense = { projectId -> form = FormState(TxKind.EXPENSE, null, projectId) },
                onTxClick = { selected = it },
                modifier = contentModifier
            )
            3 -> FinanceScreen(
                vm,
                onTxClick = { selected = it },
                onOpenTrash = { showTrash = true },
                onManageAccounts = { showAccounts = true },
                modifier = contentModifier
            )
            4 -> if (showMemory) {
                MemoryScreen(
                    vm = memoryVm,
                    onBack = { showMemory = false },
                    onAdd = { memoryForm = MemoryForm(null, memoryVm.category.value ?: MemoryCategory.NOTES) },
                    onEdit = { memoryForm = MemoryForm(it, it.category) },
                    onOpenTrash = { showMemoryTrash = true },
                    modifier = contentModifier
                )
            } else if (showAi) {
                AiSettingsScreen(vm = aiVm, onBack = { showAi = false }, modifier = contentModifier)
            } else if (showLibrary) {
                LibraryScreen(
                    vm = libraryVm,
                    onBack = { showLibrary = false },
                    modifier = contentModifier
                )
            } else if (showReminders) {
                RemindersScreen(
                    vm = reminderVm,
                    onBack = { showReminders = false },
                    modifier = contentModifier
                )
            } else if (showNlu) {
                NluTestScreen(
                    accountNames = accounts.map { it.name },
                    onBack = { showNlu = false },
                    modifier = contentModifier
                )
            } else {
                ToolsScreen(
                    onOpenMemory = { showMemory = true },
                    onOpenNlu = { showNlu = true },
                    onOpenReminders = { showReminders = true },
                    onOpenLibrary = { showLibrary = true },
                    onOpenAi = { showAi = true },
                    modifier = contentModifier
                )
            }
            else -> Placeholder(tabs[tab], contentModifier)
        }
    }

    if (showQuick) {
        QuickAddSheet(
            onDismiss = { showQuick = false },
            onPick = { kind ->
                showQuick = false
                form = FormState(kind, null)
            },
            onNote = {
                showQuick = false
                memoryForm = MemoryForm(null, MemoryCategory.NOTES)
            }
        )
    }

    form?.let { state ->
        TransactionDialog(
            kind = state.kind,
            editing = state.editing,
            vm = vm,
            onDismiss = { form = null },
            projects = projectRefs,
            defaultProjectId = state.defaultProjectId
        )
    }

    selected?.let { item ->
        TransactionDetailDialog(
            item = item,
            names = names,
            projectName = projectList.firstOrNull { it.id == item.tx.projectId }?.name,
            onEdit = {
                selected = null
                form = FormState(item.tx.kind, item)
            },
            onDelete = {
                vm.delete(item.tx.id)
                selected = null
            },
            onDismiss = { selected = null }
        )
    }

    if (showTrash) {
        TrashDialog(vm = vm, onDismiss = { showTrash = false })
    }

    if (showAccounts) {
        AccountsDialog(vm = vm, onDismiss = { showAccounts = false })
    }

    memoryForm?.let { f ->
        MemoryDialog(
            editing = f.editing,
            defaultCategory = f.category,
            vm = memoryVm,
            onDismiss = { memoryForm = null }
        )
    }

    if (showMemoryTrash) {
        MemoryTrashDialog(vm = memoryVm, onDismiss = { showMemoryTrash = false })
    }
}

@Composable
private fun Placeholder(tab: Tab, modifier: Modifier) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tab.title, style = MaterialTheme.typography.headlineSmall)
        Text(
            "این بخش هنوز پیاده سازی نشده است (${tab.stage}).",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}
