package ir.navid.app.data

import ir.navid.app.core.JalaliDate
import ir.navid.app.domain.BuildingPhases
import ir.navid.app.domain.PhaseRules
import ir.navid.app.domain.PhaseStatus
import ir.navid.app.domain.ProjectStatus
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID

class BuildingRepository(private val dao: BuildingDao) {

    fun projects(): Flow<List<ProjectEntity>> = dao.observeProjects()
    fun phases(): Flow<List<PhaseEntity>> = dao.observePhases()
    fun reports(): Flow<List<SiteReportEntity>> = dao.observeReports()

    private fun todayIso(): String = LocalDate.now(ZoneId.of("Asia/Tehran")).toString()

    /** ساخت پروژه همراه 14 مرحله پیش فرض. خروجی null یعنی موفق. */
    suspend fun createProject(
        name: String,
        address: String,
        landArea: Double?,
        builtArea: Double?,
        floors: Int?,
        structureType: String,
        budget: Long
    ): String? {
        val n = name.trim()
        if (n.isEmpty()) return "نام پروژه را وارد کنید"
        if (n.length > 80) return "نام پروژه بیش از حد طولانی است"
        if (budget < 0) return "بودجه نمی تواند منفی باشد"
        if (floors != null && floors !in 1..100) return "تعداد طبقات نامعتبر است"
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val project = ProjectEntity(
            id = id,
            name = n,
            address = address.trim(),
            landArea = landArea,
            builtArea = builtArea,
            floors = floors,
            structureType = structureType.trim(),
            initialBudget = budget,
            status = ProjectStatus.ACTIVE,
            createdAt = now,
            updatedAt = now
        )
        val phases = BuildingPhases.defaults.mapIndexed { index, phaseName ->
            PhaseEntity(
                id = UUID.randomUUID().toString(),
                projectId = id,
                name = phaseName,
                sortOrder = index,
                plannedStart = null,
                plannedEnd = null,
                actualStart = null,
                actualEnd = null,
                status = PhaseStatus.NOT_STARTED,
                progressPct = 0,
                notes = ""
            )
        }
        dao.insertProjectWithPhases(project, phases)
        return null
    }

    suspend fun deleteProject(id: String) = dao.softDeleteProject(id, System.currentTimeMillis())

    /** تغییر وضعیت و درصد مرحله؛ تاریخ شروع و پایان واقعی خودکار ثبت می شود. */
    suspend fun updatePhase(phaseId: String, status: PhaseStatus, progress: Int, notes: String): String? {
        val phase = dao.phaseById(phaseId) ?: return "مرحله پیدا نشد"
        val (st, pct) = PhaseRules.normalize(status, progress)
        val today = todayIso()
        val start = if (st != PhaseStatus.NOT_STARTED) (phase.actualStart ?: today) else null
        val end = if (st == PhaseStatus.DONE) (phase.actualEnd ?: today) else null
        dao.updatePhase(phase.copy(status = st, progressPct = pct, actualStart = start, actualEnd = end, notes = notes.trim()))
        return null
    }

    suspend fun addReport(projectId: String, phaseId: String?, date: JalaliDate, text: String, source: String = "MANUAL"): String? {
        val t = text.trim()
        if (t.isEmpty()) return "متن گزارش را وارد کنید"
        if (t.length > 5000) return "گزارش بیش از حد طولانی است"
        if (dao.projectById(projectId) == null) return "پروژه پیدا نشد"
        dao.insertReport(
            SiteReportEntity(
                id = UUID.randomUUID().toString(),
                projectId = projectId,
                phaseId = phaseId,
                reportDate = date.toLocalDate().toString(),
                text = t,
                source = source,
                createdAt = System.currentTimeMillis()
            )
        )
        return null
    }

    suspend fun deleteReport(id: String) = dao.softDeleteReport(id, System.currentTimeMillis())
}
