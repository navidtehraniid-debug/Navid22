package ir.navid.app.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

/**
 * تاریخ شمسی (جلالی) بر پایه الگوریتم حسابی 33 ساله.
 * برای سال های حدود 1200 تا 1500 با تقویم رسمی هم خوان است؛ برای سال های دورتر نیاز به بازبینی دارد.
 */
data class JalaliDate(val year: Int, val month: Int, val day: Int) {

    init {
        require(month in 1..12) { "ماه نامعتبر" }
        require(day in 1..daysInMonth(year, month)) { "روز نامعتبر" }
    }

    fun toLocalDate(): LocalDate {
        val g = jalaliToGregorianRaw(year, month, day)
        return LocalDate.of(g[0], g[1], g[2])
    }

    /** مثال: 1405/08/09 */
    fun format(): String = String.format(Locale.US, "%04d/%02d/%02d", year, month, day)

    /** مثال: ۹ آبان ۱۴۰۵ */
    fun formatLong(): String = "$day ${monthNames[month - 1]} $year".toPersianDigits()

    companion object {
        val monthNames = listOf(
            "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
        )

        fun from(date: LocalDate): JalaliDate {
            val j = gregorianToJalaliRaw(date.year, date.monthValue, date.dayOfMonth)
            return JalaliDate(j[0], j[1], j[2])
        }

        fun today(): JalaliDate = from(LocalDate.now(ZoneId.of("Asia/Tehran")))

        fun isLeap(year: Int): Boolean {
            val a = jalaliToGregorianRaw(year, 1, 1)
            val b = jalaliToGregorianRaw(year + 1, 1, 1)
            return LocalDate.of(b[0], b[1], b[2]).toEpochDay() - LocalDate.of(a[0], a[1], a[2]).toEpochDay() == 366L
        }

        fun daysInMonth(year: Int, month: Int): Int = when {
            month <= 6 -> 31
            month <= 11 -> 30
            else -> if (isLeap(year)) 30 else 29
        }

        /** قالب ورودی: سال/ماه/روز با ارقام فارسی یا لاتین. نامعتبر یعنی null. */
        fun parse(text: String): JalaliDate? {
            val parts = text.toLatinDigits().trim().split('/', '-', '.')
            if (parts.size != 3) return null
            val y = parts[0].trim().toIntOrNull() ?: return null
            val m = parts[1].trim().toIntOrNull() ?: return null
            val d = parts[2].trim().toIntOrNull() ?: return null
            if (y !in 1200..1600 || m !in 1..12 || d < 1) return null
            if (d > daysInMonth(y, m)) return null
            return JalaliDate(y, m, d)
        }
    }
}

fun weekdayNameFa(day: DayOfWeek): String = when (day) {
    DayOfWeek.SATURDAY -> "شنبه"
    DayOfWeek.SUNDAY -> "یکشنبه"
    DayOfWeek.MONDAY -> "دوشنبه"
    DayOfWeek.TUESDAY -> "سه شنبه"
    DayOfWeek.WEDNESDAY -> "چهارشنبه"
    DayOfWeek.THURSDAY -> "پنجشنبه"
    DayOfWeek.FRIDAY -> "جمعه"
}

internal fun gregorianToJalaliRaw(gy: Int, gm: Int, gd: Int): IntArray {
    val gDm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gDm[gm - 1]
    var jy = -1595 + (33 * (days / 12053))
    days %= 12053
    jy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        jy += (days - 1) / 365
        days = (days - 1) % 365
    }
    val jm: Int
    val jd: Int
    if (days < 186) {
        jm = 1 + days / 31
        jd = 1 + days % 31
    } else {
        jm = 7 + (days - 186) / 30
        jd = 1 + (days - 186) % 30
    }
    return intArrayOf(jy, jm, jd)
}

internal fun jalaliToGregorianRaw(jy0: Int, jm: Int, jd: Int): IntArray {
    val jy = jy0 + 1595
    var days = -355668 + (365 * jy) + ((jy / 33) * 8) + (((jy % 33) + 3) / 4) + jd +
        (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
    var gy = 400 * (days / 146097)
    days %= 146097
    if (days > 36524) {
        days -= 1
        gy += 100 * (days / 36524)
        days %= 36524
        if (days >= 365) days += 1
    }
    gy += 4 * (days / 1461)
    days %= 1461
    if (days > 365) {
        gy += (days - 1) / 365
        days = (days - 1) % 365
    }
    var gd = days + 1
    val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
    val monthLengths = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    var gm = 0
    while (gm < 13 && gd > monthLengths[gm]) {
        gd -= monthLengths[gm]
        gm++
    }
    return intArrayOf(gy, gm, gd)
}
