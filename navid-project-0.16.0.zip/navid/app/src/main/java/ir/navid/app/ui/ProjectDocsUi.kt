package ir.navid.app.ui

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.ProjectDocumentEntity
import ir.navid.app.domain.DocRole
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProjectDocsViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).projectDocDao()
    val links: StateFlow<List<ProjectDocumentEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun link(projectId: String, docId: String, role: DocRole) {
        viewModelScope.launch { dao.upsert(ProjectDocumentEntity(projectId, docId, role, "", System.currentTimeMillis())) }
    }

    fun unlink(projectId: String, docId: String) {
        viewModelScope.launch { dao.remove(projectId, docId) }
    }
}

/** مدارک پروژه: نسخه حاکم استاندارد، نقشه مصوب، مشخصات و قرارداد. نسخه حاکم و مرحله فعلی در جست وجو اولویت می گیرند. */
@Composable
fun ProjectDocsSection(projectId: String, currentPhase: String?) {
    val pvm: ProjectDocsViewModel = viewModel()
    val lib: LibraryViewModel = viewModel()
    val links by pvm.links.collectAsState()
    val docs by lib.allDocuments.collectAsState()
    val mine = links.filter { it.projectId == projectId }
    var showAdd by remember { mutableStateOf(false) }

    SectionCard("مدارک پروژه و نسخه حاکم") {
        Text(
            if (currentPhase != null) "مرحله فعلی: $currentPhase. منابع و چک لیست هایی که برای این مرحله علامت خورده اند در جست وجو و در شروع بازدید اولویت می گیرند."
            else "مرحله فعلی مشخص نیست (وضعیت یک مرحله را «در حال انجام» کنید).",
            style = MaterialTheme.typography.bodySmall
        )
        mine.forEach { link ->
            val d = docs.firstOrNull { it.id == link.docId }
            val title = d?.title ?: "سندی که از کتابخانه حذف شده"
            val meta = listOfNotNull(d?.year?.toString(), d?.edition?.takeIf { it.isNotBlank() }).joinToString("  •  ")
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text((link.role.labelFa + if (meta.isNotEmpty()) "  •  $meta" else "").toPersianDigits(), style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { pvm.unlink(projectId, link.docId) }) { Text("حذف پیوند") }
            Divider()
        }
        if (mine.none { it.role == DocRole.GOVERNING }) {
            Text(
                "هنوز سند «نسخه حاکم» انتخاب نشده. اگر از یک مبحث چند ویرایش دارید، ویرایش مربوط به قرارداد این پروژه را مشخص کنید.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("افزودن سند از کتابخانه") }
    }

    if (showAdd) {
        val candidates = docs.filter { d -> mine.none { it.docId == d.id } }
        var picked by remember { mutableStateOf<String?>(null) }
        var role by remember { mutableStateOf(DocRole.GOVERNING) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("افزودن سند به پروژه") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (candidates.isEmpty()) Text("سندی برای افزودن نیست.")
                    candidates.forEach { d ->
                        val meta = listOfNotNull(d.year?.toString(), d.edition.takeIf { it.isNotBlank() }).joinToString(" • ")
                        AccountChoice((d.title + if (meta.isNotEmpty()) " ($meta)" else "").toPersianDigits(), picked == d.id) { picked = d.id }
                    }
                    Divider()
                    Text("نقش سند در این پروژه", style = MaterialTheme.typography.labelLarge)
                    DocRole.values().forEach { r -> AccountChoice(r.labelFa, role == r) { role = r } }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    picked?.let { pvm.link(projectId, it, role) }
                    showAdd = false
                }) { Text("افزودن") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("انصراف") } }
        )
    }
}
