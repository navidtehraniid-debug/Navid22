package ir.navid.app.domain

data class EntryLine(val accountId: String, val debit: Long, val credit: Long)

/**
 * قواعد حسابداری دوطرفه. همه محاسبات مالی فقط اینجا و با کد انجام می شود.
 * - هزینه: بدهکار حساب هزینه، بستانکار حساب پرداخت (دارایی)
 * - درآمد: بدهکار حساب دریافت (دارایی)، بستانکار حساب درآمد
 * - انتقال: بدهکار مقصد، بستانکار مبدأ؛ هیچ حساب هزینه یا درآمدی درگیر نمی شود
 */
object DoubleEntry {
    const val MAX_AMOUNT: Long = 1_000_000_000_000_000L

    fun expense(payFromAccountId: String, expenseAccountId: String, amount: Long): List<EntryLine> = listOf(
        EntryLine(expenseAccountId, debit = amount, credit = 0),
        EntryLine(payFromAccountId, debit = 0, credit = amount)
    )

    fun income(depositToAccountId: String, incomeAccountId: String, amount: Long): List<EntryLine> = listOf(
        EntryLine(depositToAccountId, debit = amount, credit = 0),
        EntryLine(incomeAccountId, debit = 0, credit = amount)
    )

    fun transfer(fromAccountId: String, toAccountId: String, amount: Long): List<EntryLine> = listOf(
        EntryLine(toAccountId, debit = amount, credit = 0),
        EntryLine(fromAccountId, debit = 0, credit = amount)
    )

    /** null یعنی معتبر؛ در غیر این صورت پیام خطا. */
    fun validate(lines: List<EntryLine>): String? {
        if (lines.size < 2) return "تراکنش باید حداقل دو سطر داشته باشد"
        var totalDebit = 0L
        var totalCredit = 0L
        for (line in lines) {
            if (line.debit < 0 || line.credit < 0) return "مبلغ منفی مجاز نیست"
            if (line.debit > MAX_AMOUNT || line.credit > MAX_AMOUNT) return "مبلغ بیش از حد بزرگ است"
            if (line.debit > 0 && line.credit > 0) return "هر سطر فقط یکی از بدهکار یا بستانکار را دارد"
            if (line.debit == 0L && line.credit == 0L) return "سطر با مبلغ صفر مجاز نیست"
            totalDebit += line.debit
            totalCredit += line.credit
        }
        if (totalDebit != totalCredit) return "جمع بدهکار و بستانکار برابر نیست"
        if (lines.size == 2 && lines[0].accountId == lines[1].accountId) return "حساب مبدأ و مقصد نباید یکی باشد"
        return null
    }

    /** مانده حساب با توجه به نوع آن؛ دارایی و هزینه ماهیت بدهکار دارند و بقیه بستانکار. */
    fun balanceOf(type: AccountType, debit: Long, credit: Long, opening: Long = 0): Long = when (type) {
        AccountType.ASSET, AccountType.EXPENSE -> opening + debit - credit
        AccountType.LIABILITY, AccountType.EQUITY, AccountType.INCOME -> opening + credit - debit
    }
}
