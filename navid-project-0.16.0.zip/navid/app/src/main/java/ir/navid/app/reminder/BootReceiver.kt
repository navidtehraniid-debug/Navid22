package ir.navid.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.navid.app.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** بعد از روشن شدن گوشی یا به روزرسانی برنامه، آلارم یادآوری های آینده دوباره ثبت می شود (آلارم ها با خاموش شدن گوشی پاک می شوند). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val list = AppDatabase.get(appContext).reminderDao().pendingAfter(System.currentTimeMillis())
                list.forEach { ReminderScheduler.schedule(appContext, it) }
            } finally {
                pending.finish()
            }
        }
    }
}
