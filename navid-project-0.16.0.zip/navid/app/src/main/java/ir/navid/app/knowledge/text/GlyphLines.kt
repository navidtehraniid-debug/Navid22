package ir.navid.app.knowledge.text

import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.max

/** یک نویسه چاپ شده روی صفحه با مختصات (مبدأ بالا چپ، پوینت). baseline = خط پایه. */
data class Glyph(val text: String, val x: Float, val width: Float, val baseline: Float, val size: Float)

/** سطر بازسازی شده؛ اگر bottom <= top مختصات نامعلوم است. */
data class TextLine(val text: String, val top: Float, val bottom: Float) {
    val hasGeometry: Boolean get() = bottom > top
}

/**
 * بازسازی سطرهای فارسی از روی موقعیت نویسه ها، نه ترتیب جریان محتوا.
 * ریشه مشکل: در PDF واقعی حروف هر کلمه در جریان محتوا به ترتیب دیداری (معکوس) آمده اند و ابزارهای مبتنی بر ترتیب
 * جریان حروف و کلمه ها را به هم می ریزند. مراحل: خوشه بندی سطر با خط پایه، مرتب سازی x نزولی (راست به چپ)،
 * برگرداندن اجرای های چپ به راست (ارقام و لاتین؛ خط تیره بین ارقام جزو اجرا نیست و اجزای 4-1-3-4 راست به چپ
 * می مانند)، اصلاح پرانتز و گیومه آینه ای، و افزودن فاصله برای شکاف بزرگ بدون نویسه فاصله.
 */
object GlyphLineBuilder {
    private const val SPACE_GAP = 0.12

    private val brackets = mapOf(
        '(' to ')', ')' to '(', '[' to ']', ']' to '[', '{' to '}', '}' to '{',
        '\u00AB' to '\u00BB', '\u00BB' to '\u00AB', '<' to '>', '>' to '<'
    )
    private val separators = setOf('.', '/', ',', ':', '\u066B', '\u066C')

    private fun isLtrChar(ch: Char): Boolean = ch.isDigit() || ch in 'a'..'z' || ch in 'A'..'Z'

    /** ورودی: نویسه ها به ترتیب x نزولی؛ خروجی: ترتیب منطقی با اجرای های چپ به راست اصلاح شده. */
    internal fun toLogical(desc: List<Char>): String {
        val out = ArrayList<Char>(desc.size)
        var i = 0
        val n = desc.size
        while (i < n) {
            val ch = desc[i]
            if (isLtrChar(ch)) {
                var j = i
                while (j < n && (isLtrChar(desc[j]) || (desc[j] in separators && j + 1 < n && j > i && isLtrChar(desc[j + 1])))) j++
                for (k in j - 1 downTo i) out.add(desc[k])
                i = j
            } else {
                out.add(ch)
                i++
            }
        }
        return out.joinToString("")
    }

    private class Group(var cy: Double, val items: ArrayList<Glyph>)

    fun build(glyphs: List<Glyph>, toleranceFactor: Double = 0.45): List<TextLine> {
        val g = glyphs.filter { it.text.isNotEmpty() }
        if (g.isEmpty()) return emptyList()
        val sizes = g.map { (if (it.size > 0f) it.size else 10f).toDouble() }.sorted()
        val mid = sizes.size / 2
        val median = if (sizes.size % 2 == 1) sizes[mid] else (sizes[mid - 1] + sizes[mid]) / 2.0
        val tol = toleranceFactor * median

        val groups = ArrayList<Group>()
        for (x in g.sortedBy { it.baseline }) {
            val last = groups.lastOrNull()
            if (last != null && abs(x.baseline - last.cy) <= tol) {
                last.items.add(x)
                last.cy = (last.cy * (last.items.size - 1) + x.baseline) / last.items.size
            } else {
                groups.add(Group(x.baseline.toDouble(), arrayListOf(x)))
            }
        }

        val lines = ArrayList<TextLine>()
        for (group in groups) {
            val ordered = group.items.sortedByDescending { it.x.toDouble() + it.width.toDouble() / 2.0 }
            val chars = ArrayList<Char>()
            var prev: Glyph? = null
            for (gl in ordered) {
                if (prev != null && prev.text.isNotBlank() && gl.text.isNotBlank()) {
                    val gap = prev.x - (gl.x + gl.width)
                    if (gap > SPACE_GAP * max(prev.size, gl.size)) chars.add(' ')
                }
                for (c in Normalizer.normalize(gl.text, Normalizer.Form.NFKC)) chars.add(c)
                prev = gl
            }
            val logical = toLogical(chars)
            val text = buildString(logical.length) { for (c in logical) append(brackets[c] ?: c) }
            lines.add(
                TextLine(text, ordered.minOf { it.baseline - it.size }, ordered.maxOf { it.baseline + 0.25f * it.size })
            )
        }
        return lines
    }
}
