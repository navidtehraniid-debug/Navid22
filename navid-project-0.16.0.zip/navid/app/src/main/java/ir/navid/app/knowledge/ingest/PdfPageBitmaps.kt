package ir.navid.app.knowledge.ingest

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

/** رندر صفحه PDF به تصویر برای OCR (یک صفحه در هر لحظه؛ تصویر را بعد از استفاده recycle کنید). */
class PdfPageBitmaps private constructor(private val pfd: ParcelFileDescriptor, private val renderer: PdfRenderer) {
    fun render(index: Int, widthPx: Int): Bitmap {
        val page = renderer.openPage(index)
        try {
            val h = (widthPx * page.height.toFloat() / page.width.toFloat()).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
            return bmp
        } finally {
            page.close()
        }
    }

    fun close() {
        try { renderer.close() } catch (e: Exception) { }
        try { pfd.close() } catch (e: Exception) { }
    }

    companion object {
        fun open(file: File): PdfPageBitmaps? = try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                PdfPageBitmaps(pfd, PdfRenderer(pfd))
            } catch (e: Exception) {
                pfd.close()
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
