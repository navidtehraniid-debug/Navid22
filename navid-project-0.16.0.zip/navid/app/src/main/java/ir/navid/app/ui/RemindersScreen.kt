package ir.navid.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import ir.navid.app.core.JalaliCalendar
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.TimeText
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.ReminderEntity
import ir.navid.app.domain.ReminderLevel
import ir.navid.app.domain.ReminderStatus
import java.time.LocalDate

private data class ReminderEdit(val editing: ReminderEntity?, val date: JalaliDate)

private const val DEFAULT_TIME = "07:30"

private fun describe(r: ReminderEntity): String {
    val date = try {
        JalaliDate.from(LocalDate.parse(r.localDate)).formatLong()
    } catch (e: Exception) {
        r.localDate
    }
    return date + "  ساعت " + TimeText.format(r.hour, r.minute).toPersianDigits() + "  •  " + r.level.labelFa
}

@Composable
fun RemindersScreen(vm: ReminderViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val reminders by vm.reminders.collectAsState()
    val today = remember { JalaliDate.today() }
    var year by remember { mutableStateOf(today.year) }
    var month by remember { mutableStateOf(today.month) }
    var selected by remember { mutableStateOf<JalaliDate?>(today) }
    var dialog by remember { mutableStateOf<ReminderEdit?>(null) }

    val context = LocalContext.current
    var notifGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notifGranted = granted
    }

    val grid = JalaliCalendar.monthGrid(year, month)
    val pendingDates = reminders.filter { it.status == ReminderStatus.PENDING }.map { it.localDate }.toSet()
    val selectedIso = selected?.toLocalDate()?.toString()
    val selectedList = if (selectedIso == null) emptyList() else reminders.filter { it.localDate == selectedIso }
    val now = System.currentTimeMillis()
    val upcoming = reminders.filter { it.status == ReminderStatus.PENDING && it.dueAt >= now }.take(10)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack) { Text("بازگشت") }
        Text("تقویم شمسی و یادآوری ها", style = MaterialTheme.typography.titleLarge)

        if (!notifGranted) {
            SectionCard("اعلان ها خاموش است") {
                Text("بدون مجوز اعلان، یادآوری ها نمایش داده نمی شوند.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("فعال کردن") }
                    TextButton(onClick = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        context.startActivity(intent)
                    }) { Text("تنظیمات اعلان") }
                }
            }
        }

        SectionCard("${JalaliDate.monthNames[month - 1]} $year".toPersianDigits()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = {
                    val s = JalaliCalendar.shift(year, month, -1)
                    year = s.first
                    month = s.second
                }) { Text("ماه قبل") }
                TextButton(onClick = {
                    year = today.year
                    month = today.month
                    selected = today
                }) { Text("امروز") }
                TextButton(onClick = {
                    val s = JalaliCalendar.shift(year, month, 1)
                    year = s.first
                    month = s.second
                }) { Text("ماه بعد") }
            }
            Row(modifier = Modifier.fillMaxWidth()) {
                JalaliCalendar.weekdayShort.forEach { d ->
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(d, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            grid.forEach { week ->
                Row(modifier = Modifier.fillMaxWidth()) {
                    week.forEach { day ->
                        if (day == null) {
                            Box(modifier = Modifier.weight(1f).aspectRatio(1f))
                        } else {
                            val date = JalaliDate(year, month, day)
                            val isSelected = selected == date
                            val isToday = date == today
                            val bg = when {
                                isSelected -> MaterialTheme.colorScheme.primary
                                isToday -> MaterialTheme.colorScheme.secondaryContainer
                                else -> MaterialTheme.colorScheme.surface
                            }
                            val fg = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            val dot = date.toLocalDate().toString() in pendingDates
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg)
                                    .clickable { selected = date },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(day.toString().toPersianDigits(), color = fg, style = MaterialTheme.typography.bodyMedium)
                                    Text(if (dot) "•" else " ", color = fg, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
            Text("تعطیلات رسمی در این نسخه نمایش داده نمی شوند.", style = MaterialTheme.typography.bodySmall)
        }

        val sel = selected
        SectionCard(if (sel != null) "یادآوری های ${sel.formatLong()}" else "یادآوری ها") {
            if (selectedList.isEmpty()) Text("برای این روز یادآوری ثبت نشده است.")
            selectedList.forEach { r ->
                ReminderItem(r, vm) { dialog = ReminderEdit(r, today) }
            }
            Button(
                onClick = { dialog = ReminderEdit(null, sel ?: today) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("افزودن یادآوری") }
        }

        SectionCard("یادآوری های پیش رو") {
            if (upcoming.isEmpty()) Text("یادآوری فعالی نیست.")
            upcoming.forEach { r ->
                ReminderItem(r, vm) { dialog = ReminderEdit(r, today) }
            }
        }

        SectionCard("راهنمای باتری سامسونگ") {
            Text(
                "برای اینکه گوشی یادآوری ها را با بسته شدن برنامه نبندد، برنامه NAVID را در تنظیمات باتری گوشی از حالت «بهینه سازی» یا «Sleeping apps» خارج کنید و مصرف باتری آن را «بدون محدودیت» بگذارید. نام و مسیر دقیق منوها در نسخه های One UI کمی فرق می کند.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    dialog?.let { d ->
        ReminderDialog(
            editing = d.editing,
            defaultDate = d.date,
            titleDefault = "",
            timeDefault = DEFAULT_TIME,
            vm = vm,
            onDismiss = { dialog = null }
        )
    }
}

@Composable
private fun ReminderItem(r: ReminderEntity, vm: ReminderViewModel, onEdit: () -> Unit) {
    val overdue = r.status == ReminderStatus.PENDING && r.dueAt < System.currentTimeMillis()
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            r.title + if (r.status == ReminderStatus.DONE) "  (انجام شد)" else "",
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            describe(r) + if (overdue) "  •  از موعد گذشته" else "",
            style = MaterialTheme.typography.bodySmall,
            color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (r.status == ReminderStatus.PENDING) {
                TextButton(onClick = { vm.complete(r.id) }) { Text("انجام شد") }
            }
            TextButton(onClick = onEdit) { Text("ویرایش") }
            TextButton(onClick = { vm.delete(r.id) }) { Text("حذف") }
        }
    }
}

/** فرم افزودن یا ویرایش یادآوری. */
@Composable
fun ReminderDialog(
    editing: ReminderEntity?,
    defaultDate: JalaliDate,
    titleDefault: String,
    timeDefault: String,
    vm: ReminderViewModel,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(editing?.title ?: titleDefault) }
    var dateText by remember {
        mutableStateOf(
            if (editing != null) JalaliDate.from(LocalDate.parse(editing.localDate)).format() else defaultDate.format()
        )
    }
    var timeText by remember {
        mutableStateOf(if (editing != null) TimeText.format(editing.hour, editing.minute) else timeDefault)
    }
    var level by remember { mutableStateOf(editing?.level ?: ReminderLevel.NORMAL) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing != null) "ویرایش یادآوری" else "یادآوری جدید") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; error = null },
                    label = { Text("عنوان") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it; error = null },
                    label = { Text("تاریخ شمسی (سال/ماه/روز)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeText,
                    onValueChange = { timeText = it; error = null },
                    label = { Text("ساعت (مثلاً 10:30)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("اهمیت", style = MaterialTheme.typography.labelLarge)
                ReminderLevel.values().forEach { l ->
                    AccountChoice(l.labelFa, level == l) { level = l }
                }
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.save(editing?.id, title, dateText, timeText, level) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
