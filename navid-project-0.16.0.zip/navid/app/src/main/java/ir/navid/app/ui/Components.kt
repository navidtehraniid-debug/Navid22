package ir.navid.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.formatToman
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.domain.TxKind
import java.time.LocalDate

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun LabeledAmount(label: String, amount: Long) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(amount.formatToman(), style = MaterialTheme.typography.bodyMedium)
    }
}

fun kindLabel(kind: TxKind): String = when (kind) {
    TxKind.INCOME -> "درآمد"
    TxKind.EXPENSE -> "هزینه"
    TxKind.TRANSFER -> "انتقال"
}

@Composable
fun TransactionRow(
    item: TransactionWithLines,
    accountNames: Map<String, String>,
    onClick: (() -> Unit)? = null
) {
    val amount = item.lines.sumOf { it.debit }
    val title = item.tx.description.ifBlank {
        when (item.tx.kind) {
            TxKind.EXPENSE -> accountNames[item.lines.firstOrNull { it.debit > 0 }?.accountId] ?: "هزینه"
            TxKind.INCOME -> accountNames[item.lines.firstOrNull { it.credit > 0 }?.accountId] ?: "درآمد"
            TxKind.TRANSFER -> {
                val from = accountNames[item.lines.firstOrNull { it.credit > 0 }?.accountId] ?: "؟"
                val to = accountNames[item.lines.firstOrNull { it.debit > 0 }?.accountId] ?: "؟"
                "انتقال از $from به $to"
            }
        }
    }
    val dateText = try {
        JalaliDate.from(LocalDate.parse(item.tx.localDate)).format().toPersianDigits()
    } catch (e: Exception) {
        item.tx.localDate
    }
    val rowModifier = if (onClick != null) {
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp)
    } else {
        Modifier.fillMaxWidth()
    }
    Row(
        modifier = rowModifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(
                "${kindLabel(item.tx.kind)}  •  $dateText",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
        val sign = when (item.tx.kind) {
            TxKind.INCOME -> "+ "
            TxKind.EXPENSE -> "− "
            TxKind.TRANSFER -> ""
        }
        Text(sign + amount.formatToman(), style = MaterialTheme.typography.bodyMedium)
    }
}
