package ir.navid.app.core

/** شبکه ماه شمسی برای تقویم: هفته از شنبه شروع می شود و خانه های خالی null هستند. */
object JalaliCalendar {
    val weekdayShort = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

    fun monthGrid(year: Int, month: Int): List<List<Int?>> {
        val firstDow = JalaliDate(year, month, 1).toLocalDate().dayOfWeek.value // دوشنبه=1 ... یکشنبه=7
        val offset = (firstDow + 1) % 7 // شنبه=0
        val cells = ArrayList<Int?>()
        repeat(offset) { cells.add(null) }
        for (d in 1..JalaliDate.daysInMonth(year, month)) cells.add(d)
        while (cells.size % 7 != 0) cells.add(null)
        return cells.chunked(7)
    }

    /** ماه قبل یا بعد با گذر از مرز سال. */
    fun shift(year: Int, month: Int, delta: Int): Pair<Int, Int> {
        val index = year * 12 + (month - 1) + delta
        return Pair(index / 12, index % 12 + 1)
    }
}
