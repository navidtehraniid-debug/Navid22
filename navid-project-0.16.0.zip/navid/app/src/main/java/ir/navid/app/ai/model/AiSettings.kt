package ir.navid.app.ai.model

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class AiSettings(
    val provider: ModelProvider = ModelProvider.NONE,
    val format: ApiFormat = ApiFormat.ANTHROPIC,
    val baseUrl: String = "https://api.anthropic.com",
    val model: String = "claude-sonnet-5-5",
    val localModelPath: String? = null,
    val localServerUrl: String = "http://127.0.0.1:8080",
    val localServerModel: String = "local"
)

/** کلید API با کلید AES داخل Android Keystore رمز می شود و هرگز در متن ساده ذخیره نمی شود. */
object SecretStore {
    private const val ALIAS = "navid_ai_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val enc = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + enc, Base64.NO_WRAP)
    }

    fun decrypt(token: String): String? = try {
        val all = Base64.decode(token, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        String(cipher.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }
}

class AiSettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ai_settings", Context.MODE_PRIVATE)

    fun load(): AiSettings {
        val d = AiSettings()
        return AiSettings(
            provider = runCatching { ModelProvider.valueOf(prefs.getString("provider", d.provider.name)!!) }.getOrDefault(d.provider),
            format = runCatching { ApiFormat.valueOf(prefs.getString("format", d.format.name)!!) }.getOrDefault(d.format),
            baseUrl = prefs.getString("baseUrl", d.baseUrl) ?: d.baseUrl,
            model = prefs.getString("model", d.model) ?: d.model,
            localModelPath = prefs.getString("localModelPath", null),
            localServerUrl = prefs.getString("localServerUrl", d.localServerUrl) ?: d.localServerUrl,
            localServerModel = prefs.getString("localServerModel", d.localServerModel) ?: d.localServerModel
        )
    }

    fun save(s: AiSettings) {
        prefs.edit()
            .putString("provider", s.provider.name)
            .putString("format", s.format.name)
            .putString("baseUrl", s.baseUrl.trim())
            .putString("model", s.model.trim())
            .putString("localModelPath", s.localModelPath)
            .putString("localServerUrl", s.localServerUrl.trim())
            .putString("localServerModel", s.localServerModel.trim())
            .apply()
    }

    fun apiKey(): String? = prefs.getString("apiKeyEnc", null)?.let { SecretStore.decrypt(it) }

    fun hasApiKey(): Boolean = prefs.getString("apiKeyEnc", null) != null

    fun saveApiKey(key: String?) {
        val e = prefs.edit()
        if (key.isNullOrBlank()) e.remove("apiKeyEnc") else e.putString("apiKeyEnc", SecretStore.encrypt(key.trim()))
        e.apply()
    }

    fun externalConfig(): ExternalConfig? {
        val s = load()
        val k = apiKey() ?: return null
        if (s.baseUrl.isBlank() || s.model.isBlank()) return null
        return ExternalConfig(s.format, s.baseUrl, s.model, k)
    }
}
