package ir.navid.app.domain

enum class LedgerKind { PERSONAL, BUILDING, INVESTMENT, EUROMEN }

enum class AccountType { ASSET, LIABILITY, EQUITY, INCOME, EXPENSE }

enum class TxKind { INCOME, EXPENSE, TRANSFER }

enum class DataClass { ACTUAL, ESTIMATED, FORECAST }

enum class TxStatus { DRAFT, CONFIRMED, VOID }

enum class TxSource { MANUAL, CHAT, VOICE, DOCUMENT, IMPORT }

enum class ReminderLevel(val labelFa: String) {
    URGENT("فوری"),
    IMPORTANT("مهم"),
    NORMAL("عادی")
}

enum class ReminderStatus { PENDING, DONE }

enum class ProjectStatus { ACTIVE, COMPLETED }

enum class PhaseStatus(val labelFa: String) {
    NOT_STARTED("شروع نشده"),
    IN_PROGRESS("در حال انجام"),
    DONE("تمام شده")
}
