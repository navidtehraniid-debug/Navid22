package ir.navid.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.navid.app.domain.MemoryCategory

@Entity(
    tableName = "memories",
    indices = [Index("category"), Index("dedupeHash")]
)
data class MemoryEntity(
    @PrimaryKey val id: String,
    val category: MemoryCategory,
    val title: String,
    val content: String,
    val source: String,
    val dedupeHash: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)
