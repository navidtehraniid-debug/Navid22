package ir.navid.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.navid.app.domain.ReminderLevel

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(ReminderScheduler.EXTRA_ID) ?: return
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "یادآوری"
        val level = try {
            ReminderLevel.valueOf(intent.getStringExtra(ReminderScheduler.EXTRA_LEVEL) ?: "NORMAL")
        } catch (e: IllegalArgumentException) {
            ReminderLevel.NORMAL
        }
        NotificationHelper.show(context, id, title, level)
    }
}
