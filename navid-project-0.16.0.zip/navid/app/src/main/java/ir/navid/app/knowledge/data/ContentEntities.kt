package ir.navid.app.knowledge.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** متن تمیز شده هر صفحه PDF (منبع حقیقت متنی؛ ایندکس از روی آن بازسازی می شود). */
@Entity(tableName = "lib_pages", primaryKeys = ["docId", "pageNo"])
data class LibPageEntity(
    val docId: String,
    val pageNo: Int,
    val text: String,
    val printedPage: Int?,
    val quality: Float,
    val method: String
)

/** تکه قابل جست وجو (معمولاً یک بند شماره دار) با ارجاع به صفحه های فایل. */
@Entity(tableName = "lib_chunks", indices = [Index("docId")])
data class LibChunkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val docId: String,
    val pageFrom: Int,
    val pageTo: Int,
    val chapter: String,
    val clause: String,
    val heading: String,
    val text: String,
    val tokenCount: Int,
    /** نوار برجسته سازی روی صفحه pageFrom (کسری از ارتفاع)؛ null یعنی نامعلوم. */
    val hlTop: Float? = null,
    val hlBottom: Float? = null
)
