package ir.navid.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.core.JalaliDate
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.ChecklistResultEntity
import ir.navid.app.data.ChecklistRepository
import ir.navid.app.data.ChecklistRunEntity
import ir.navid.app.data.ChecklistTemplateEntity
import ir.navid.app.data.ChecklistTemplateItemEntity
import ir.navid.app.domain.CheckStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChecklistViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ChecklistRepository(AppDatabase.get(app).checklistDao())

    val templates: StateFlow<List<ChecklistTemplateEntity>> =
        repo.templates().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val templateItems: StateFlow<List<ChecklistTemplateItemEntity>> =
        repo.templateItems().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val runs: StateFlow<List<ChecklistRunEntity>> =
        repo.runs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val results: StateFlow<List<ChecklistResultEntity>> =
        repo.results().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch { repo.ensureSample() }
    }

    fun createTemplate(title: String, phaseKey: String, itemsText: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repo.createTemplate(title, phaseKey, itemsText)) }
    }

    fun deleteTemplate(id: String) {
        viewModelScope.launch { repo.deleteTemplate(id) }
    }

    fun startRun(projectId: String, templateId: String, dateText: String, onResult: (String?) -> Unit) {
        val date = JalaliDate.parse(dateText)
        if (date == null) {
            onResult("تاریخ شمسی را به شکل 1405/08/09 وارد کنید")
            return
        }
        viewModelScope.launch { onResult(repo.startRun(projectId, templateId, date)) }
    }

    fun setResult(id: String, status: CheckStatus, note: String) {
        viewModelScope.launch { repo.setResult(id, status, note) }
    }

    fun setSource(id: String, ref: String?) {
        viewModelScope.launch { repo.setSource(id, ref) }
    }

    fun deleteRun(id: String) {
        viewModelScope.launch { repo.deleteRun(id) }
    }
}
