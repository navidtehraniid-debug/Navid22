package ir.navid.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.TimeText
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.ReminderEntity
import ir.navid.app.data.ReminderRepository
import ir.navid.app.domain.ReminderLevel
import ir.navid.app.reminder.ReminderScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ReminderRepository(AppDatabase.get(app).reminderDao())

    val reminders: StateFlow<List<ReminderEntity>> =
        repo.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch { repo.purgeExpired() }
    }

    /** onResult: null یعنی موفق، در غیر این صورت پیام خطا. */
    fun save(
        editId: String?,
        title: String,
        dateText: String,
        timeText: String,
        level: ReminderLevel,
        onResult: (String?) -> Unit
    ) {
        val date = JalaliDate.parse(dateText)
        if (date == null) {
            onResult("تاریخ شمسی را به شکل 1405/08/09 وارد کنید")
            return
        }
        val time = TimeText.parse(timeText)
        if (time == null) {
            onResult("ساعت را به شکل 10:30 وارد کنید")
            return
        }
        viewModelScope.launch {
            val result = if (editId == null) {
                repo.create(title, date, time.first, time.second, level)
            } else {
                repo.update(editId, title, date, time.first, time.second, level)
            }
            result.reminder?.let { ReminderScheduler.schedule(getApplication<Application>(), it) }
            onResult(result.error)
        }
    }

    fun complete(id: String) {
        viewModelScope.launch {
            repo.complete(id)
            ReminderScheduler.cancel(getApplication<Application>(), id)
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            repo.delete(id)
            ReminderScheduler.cancel(getApplication<Application>(), id)
        }
    }
}
