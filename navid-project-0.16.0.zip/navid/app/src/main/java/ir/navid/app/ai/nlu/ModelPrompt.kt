package ir.navid.app.ai.nlu

/**
 * دستور کوتاه و ثابت برای مدل محلی. مدل فقط نوع پیام (intent) و یک خلاصه کوتاه برمی گرداند؛
 * مبلغ و تاریخ هرگز از مدل گرفته نمی شوند. برای نتیجه ثابت باید با دمای صفر اجرا شود.
 */
object ModelPrompt {
    private fun name(i: Intent): String = i.name.lowercase()

    fun build(text: String, candidates: List<Intent>): String {
        val allowed = (if (candidates.isEmpty()) Intent.values().toList() else candidates).joinToString(", ") { name(it) }
        return buildString {
            appendLine("فقط یک JSON معتبر با دو کلید intent و text برگردان و هیچ متن دیگری ننویس.")
            appendLine("intent باید دقیقاً یکی از این ها باشد: $allowed")
            appendLine("text یک خلاصه کوتاه فارسی است. مبلغ و تاریخ را ننویس.")
            appendLine()
            appendLine("جمله: چهارصد هزار تومان بنزین زدم")
            appendLine("""{"intent":"expense","text":"بنزین"}""")
            appendLine("جمله: حقوقم واریز شد")
            appendLine("""{"intent":"income","text":"واریز حقوق"}""")
            appendLine("جمله: پول از بانک به صندوق منتقل شد")
            appendLine("""{"intent":"transfer","text":"انتقال از بانک به صندوق"}""")
            appendLine("جمله: ستون های طبقه دوم آرماتوربندی شد")
            appendLine("""{"intent":"site_report","text":"آرماتوربندی ستون های طبقه دوم"}""")
            appendLine()
            append("جمله: ")
            appendLine(text.trim())
        }
    }
}
