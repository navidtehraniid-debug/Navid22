package ir.navid.app.ai.nlu

/**
 * اعتبارسنجی خروجی مدل. حقیقت نهایی مبلغ و تاریخ همیشه از کد (ParsedCommand) است؛
 * مدل هیچ وقت مبلغ یا تاریخ را تعیین نمی کند. هر اختلاف فقط هشدار می شود.
 */
object ModelOutputValidator {
    data class Result(
        val intent: Intent?,
        val summary: String?,
        val needsUserChoice: Boolean,
        val warnings: List<String>
    )

    private fun parseIntent(raw: String): Intent? = when (raw.trim().lowercase()) {
        "expense" -> Intent.EXPENSE
        "income" -> Intent.INCOME
        "transfer" -> Intent.TRANSFER
        "site_report" -> Intent.SITE_REPORT
        "reminder" -> Intent.REMINDER
        "note" -> Intent.NOTE
        "question" -> Intent.QUESTION
        else -> null
    }

    /** مقدار مبلغ یا تاریخ مدل به صورت عدد، رشته عددی، null یا رشته «null». */
    private fun modelNumber(value: Any?, warnings: MutableList<String>, field: String): Long? = when (value) {
        null -> null
        is Long -> value
        is Double -> if (value == Math.floor(value) && value >= 0 && value < 1e15) value.toLong() else {
            warnings.add("INVALID_${field}_VALUE"); null
        }
        is String -> {
            val t = value.trim()
            when {
                t.equals("null", ignoreCase = true) || t.isEmpty() -> {
                    warnings.add("NULL_AS_STRING_$field"); null
                }
                t.all { it in '0'..'9' } && t.length <= 15 -> {
                    warnings.add("${field}_AS_STRING"); t.toLong()
                }
                else -> {
                    warnings.add("INVALID_${field}_VALUE"); null
                }
            }
        }
        else -> {
            warnings.add("INVALID_${field}_VALUE"); null
        }
    }

    fun validate(modelText: String, parsed: ParsedCommand): Result {
        val obj = MiniJson.parseObject(modelText)
            ?: return Result(null, null, true, listOf("INVALID_JSON"))
        val warnings = ArrayList<String>()

        val intentRaw = obj["intent"] as? String
        var intent: Intent? = intentRaw?.let { parseIntent(it) }
        if (intent == null) warnings.add("INVALID_INTENT")

        var needsChoice = false
        if (intent != null && parsed.candidates.isNotEmpty() && intent !in parsed.candidates) {
            warnings.add("INTENT_OUTSIDE_CANDIDATES")
            intent = null
            needsChoice = true
        }
        if (intent == null) needsChoice = true

        val modelAmount = modelNumber(obj["amount"], warnings, "AMOUNT")
        val codeAmount = parsed.amounts.singleOrNull()?.value
        if (modelAmount != null) {
            if (codeAmount == null) warnings.add("FABRICATED_AMOUNT")
            else if (codeAmount != modelAmount) warnings.add("AMOUNT_MISMATCH")
        }

        val modelDate = obj["date"]
        val dateGiven = modelDate != null && !(modelDate is String && (modelDate.trim().equals("null", true) || modelDate.isBlank()))
        if (modelDate is String && modelDate.trim().equals("null", true)) warnings.add("NULL_AS_STRING_DATE")
        if (dateGiven && parsed.date.date == null) warnings.add("FABRICATED_DATE")

        val summary = (obj["text"] as? String)?.trim()?.takeIf { it.isNotEmpty() }
        return Result(intent, summary, needsChoice, warnings.distinct())
    }
}
