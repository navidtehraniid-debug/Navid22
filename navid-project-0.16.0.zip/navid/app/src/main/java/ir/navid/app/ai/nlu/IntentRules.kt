package ir.navid.app.ai.nlu

enum class Intent { NOTE, REMINDER, QUESTION, TRANSFER, INCOME, EXPENSE, SITE_REPORT }

data class IntentResult(val intents: List<Intent>, val candidates: List<Intent>) {
    /** قالب مقایسه برای مجموعه آزمون. */
    fun toGoldenString(): String = when {
        candidates.isNotEmpty() -> "AMBIGUOUS:" + candidates.joinToString("|") { it.name }
        intents.isNotEmpty() -> intents.joinToString(",") { it.name }
        else -> "UNKNOWN"
    }
}

/**
 * تشخیص نوع پیام با قواعد ساده و قطعی.
 * خروجی خالی (نه intents و نه candidates) یعنی نامشخص؛ در این حالت مدل یا کاربر تصمیم می گیرد.
 * candidates یعنی چند گزینه محتمل که باید بین آن ها انتخاب شود.
 */
object IntentRules {
    private val noteKw = listOf("یادداشت کن", "یادداشت", "نوت کن")
    private val reminderKw = listOf("یادم بنداز", "یادم باشه", "یادآوری", "یاد آوری", "یادم بیار", "به یادم بیار", "ریمایندر")
    private val questionWords = listOf("چقدر", "چند", "چطور", "چرا", "آیا", "کی", "کجا", "کدام", "چه کسی")
    private val transferKw = listOf("انتقال", "منتقل", "کارت به کارت", "جابجا کردم", "جا به جا")
    private val incomeKw = listOf(
        "واریز شد", "واریز شده", "واریزی", "حقوق", "حقوقم", "دریافت کردم", "دریافت شد", "دریافتی",
        "درآمد", "فروختم", "فروش", "سود", "به حسابم نشست", "پول اومد", "پول آمد"
    )
    private val depositVerb = "واریز کردم"
    private val expenseKw = listOf(
        "پرداخت کردم", "پرداخت شد", "پرداخت", "دادم", "خرج کردم", "خرج", "هزینه", "خریدم", "خرید",
        "قسط", "کرایه", "بنزین", "پول دادم", depositVerb
    )
    private val siteKw = listOf(
        "ستون", "ستون ها", "فونداسیون", "آرماتور", "آرماتوربندی", "بتن", "بتن ریزی", "قالب بندی", "اسکلت",
        "گودبرداری", "دیوارچینی", "سقف", "نازک کاری", "تاسیسات", "نما", "کارگاه"
    )
    private val generic = setOf("حساب", "دارایی", "سایر", "نقد", "پول")

    private fun regexOf(alts: List<String>) =
        Regex(NOT_LETTER_BEFORE + "(?:" + alts.joinToString("|") + ")" + NOT_LETTER_AFTER)

    private val noteRe = regexOf(noteKw)
    private val reminderRe = regexOf(reminderKw)
    private val questionRe = regexOf(questionWords + listOf("چنده", "چیه", "چجوری", "کجاست", "کیه", "چیست", "چگونه", "آیا", "کدام", "چطور"))
    private val transferRe = regexOf(transferKw)
    private val incomeRe = regexOf(incomeKw)
    private val expenseRe = regexOf(expenseKw)
    private val expenseWithoutDepositRe = regexOf(expenseKw.filter { it != depositVerb })
    private val depositRe = regexOf(listOf(depositVerb))
    private val siteRe = regexOf(siteKw)
    private val toRe = regexOf(listOf("به"))

    /** نام حساب هایی از کاربر که در متن ذکر شده اند (تطبیق با نام کامل یا کلمه اصلی، مثلاً «بانک» برای «حساب بانکی»). */
    fun accountsMentioned(norm: String, names: List<String>): List<String> {
        val words = TextNormalizer.tokenize(norm).map { it.text }
        val found = ArrayList<String>()
        for (name in names) {
            val n = TextNormalizer.normalize(name)
            val keys = n.split(" ").filter { it.length >= 3 && it !in generic }
            var hit = n in norm
            if (!hit) {
                outer@ for (key in keys) {
                    for (wd in words) {
                        if (wd == key || (minOf(wd.length, key.length) >= 4 && (wd.startsWith(key) || key.startsWith(wd)))) {
                            hit = true
                            break@outer
                        }
                    }
                }
            }
            if (hit) found.add(name)
        }
        return found
    }

    /** همان accountsMentioned ولی به ترتیب اولین ظهور در متن (برای تشخیص مبدأ و مقصد انتقال). */
    fun accountsMentionedOrdered(norm: String, names: List<String>): List<String> {
        val toks = TextNormalizer.tokenize(norm)
        val words = toks.map { it.text }
        val found = ArrayList<Pair<Int, String>>()
        for (name in names) {
            val n = TextNormalizer.normalize(name)
            var pos: Int? = null
            val idx = norm.indexOf(n)
            if (idx >= 0) {
                for ((k, t) in toks.withIndex()) {
                    if (t.start >= idx) {
                        pos = k
                        break
                    }
                }
            }
            if (pos == null) {
                val keys = n.split(" ").filter { it.length >= 3 && it !in generic }
                for ((k, wd) in words.withIndex()) {
                    val match = keys.any { key ->
                        wd == key || (minOf(wd.length, key.length) >= 4 && (wd.startsWith(key) || key.startsWith(wd)))
                    }
                    if (match) {
                        pos = k
                        break
                    }
                }
            }
            if (pos != null) found.add(Pair(pos, name))
        }
        return found.sortedBy { it.first }.map { it.second }
    }

    fun classify(norm: String, accountNames: List<String>): IntentResult {
        if (noteRe.containsMatchIn(norm)) return IntentResult(listOf(Intent.NOTE), emptyList())
        if (reminderRe.containsMatchIn(norm)) return IntentResult(listOf(Intent.REMINDER), emptyList())
        if ('؟' in norm || '?' in norm || questionRe.containsMatchIn(norm)) {
            return IntentResult(listOf(Intent.QUESTION), emptyList())
        }
        val site = siteRe.containsMatchIn(norm)
        var transfer = transferRe.containsMatchIn(norm)
        if (!transfer) {
            val accs = accountsMentioned(norm, accountNames)
            if (accs.size >= 2 && toRe.containsMatchIn(norm)) transfer = true
        }
        val income = incomeRe.containsMatchIn(norm)
        val expense = expenseRe.containsMatchIn(norm)
        val depositOnly = depositRe.containsMatchIn(norm) && !expenseWithoutDepositRe.containsMatchIn(norm)
        var fin: List<Intent> = emptyList()
        var cand: List<Intent> = emptyList()
        if (transfer) {
            fin = listOf(Intent.TRANSFER)
        } else if (depositOnly && !income && accountsMentioned(norm, accountNames).isNotEmpty()) {
            cand = listOf(Intent.TRANSFER, Intent.EXPENSE)
        } else if (income && expense) {
            cand = listOf(Intent.INCOME, Intent.EXPENSE)
        } else if (income) {
            fin = listOf(Intent.INCOME)
        } else if (expense) {
            fin = listOf(Intent.EXPENSE)
        }
        val intents = (if (site) listOf(Intent.SITE_REPORT) else emptyList()) + fin
        if (intents.isEmpty() && cand.isEmpty()) return IntentResult(emptyList(), emptyList())
        return IntentResult(intents, cand)
    }
}
