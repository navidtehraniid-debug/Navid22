package ir.navid.app.domain

object BuildingPhases {
    /** مراحل ساختمان از تخریب تا پایان کار، به ترتیب. */
    val defaults: List<String> = listOf(
        "تخریب", "گودبرداری", "سازه نگهبان", "فونداسیون", "اسکلت", "سقف", "دیوارچینی",
        "تاسیسات", "نما", "نازک کاری", "آسانسور", "مشاعات", "تاییدیه ها", "پایان کار"
    )
}

object PhaseRules {
    /** هماهنگ کردن وضعیت و درصد: تمام شده=100، شروع نشده=0، در حال انجام بین 1 تا 99. */
    fun normalize(status: PhaseStatus, progress: Int): Pair<PhaseStatus, Int> = when (status) {
        PhaseStatus.DONE -> Pair(PhaseStatus.DONE, 100)
        PhaseStatus.NOT_STARTED -> Pair(PhaseStatus.NOT_STARTED, 0)
        PhaseStatus.IN_PROGRESS -> Pair(PhaseStatus.IN_PROGRESS, progress.coerceIn(1, 99))
    }
}

object ProjectMath {
    /** پیشرفت کل پروژه: میانگین ساده درصد مراحل (بدون وزن دهی). */
    fun progress(phaseProgress: List<Int>): Int =
        if (phaseProgress.isEmpty()) 0 else Math.round(phaseProgress.sum().toDouble() / phaseProgress.size).toInt()

    /** بودجه باقی مانده؛ منفی یعنی از بودجه گذشته است. */
    fun remaining(budget: Long, cost: Long): Long = budget - cost

    /** درصد مصرف بودجه؛ اگر بودجه تعریف نشده باشد null. */
    fun usedPercent(budget: Long, cost: Long): Int? =
        if (budget <= 0) null else Math.round(cost.toDouble() * 100.0 / budget.toDouble()).toInt()
}
