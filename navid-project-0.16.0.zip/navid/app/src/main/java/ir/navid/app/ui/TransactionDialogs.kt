package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.formatToman
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.data.amount
import ir.navid.app.data.counterAccountId
import ir.navid.app.data.primaryAccountId
import ir.navid.app.domain.Trash
import ir.navid.app.domain.TxKind
import java.time.LocalDate

@Composable
fun TransactionDetailDialog(
    item: TransactionWithLines,
    names: Map<String, String>,
    projectName: String? = null,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val primary = names[item.primaryAccountId()] ?: "؟"
    val counter = names[item.counterAccountId()] ?: "؟"
    val dateText = try {
        JalaliDate.from(LocalDate.parse(item.tx.localDate)).formatLong()
    } catch (e: Exception) {
        item.tx.localDate
    }
    val (primaryLabel, counterLabel) = when (item.tx.kind) {
        TxKind.EXPENSE -> "پرداخت از" to "دسته"
        TxKind.INCOME -> "واریز به" to "نوع درآمد"
        TxKind.TRANSFER -> "از حساب" to "به حساب"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(kindLabel(item.tx.kind)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(item.amount().formatToman(), style = MaterialTheme.typography.titleMedium)
                Text("تاریخ: $dateText")
                Text("$primaryLabel: $primary")
                Text("$counterLabel: $counter")
                if (projectName != null) Text("پروژه: $projectName")
                if (item.tx.description.isNotBlank()) Text("توضیحات: ${item.tx.description}")
            }
        },
        confirmButton = { TextButton(onClick = onEdit) { Text("ویرایش") } },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) { Text("انتقال به سطل بازیافت") }
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        }
    )
}

@Composable
fun TrashDialog(vm: FinanceViewModel, onDismiss: () -> Unit) {
    val deleted by vm.deleted.collectAsState()
    val accounts by vm.accounts.collectAsState()
    val names = accounts.associate { it.id to it.name }
    var confirmId by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سطل بازیافت") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "موارد بعد از ${Trash.RETENTION_DAYS.toString().toPersianDigits()} روز برای همیشه پاک می شوند.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (deleted.isEmpty()) {
                    Text("سطل بازیافت خالی است.")
                } else {
                    deleted.forEach { item ->
                        TransactionRow(item, names)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { vm.restore(item.tx.id) }) { Text("بازیابی") }
                            TextButton(onClick = { confirmId = item.tx.id }) { Text("حذف دائمی") }
                        }
                        Divider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )

    confirmId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmId = null },
            title = { Text("حذف دائمی؟") },
            text = { Text("این تراکنش برای همیشه پاک می شود و قابل بازگشت نیست.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePermanently(id)
                    confirmId = null
                }) { Text("حذف دائمی") }
            },
            dismissButton = { TextButton(onClick = { confirmId = null }) { Text("انصراف") } }
        )
    }
}
