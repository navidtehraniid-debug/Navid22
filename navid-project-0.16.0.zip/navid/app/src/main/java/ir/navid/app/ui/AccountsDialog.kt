package ir.navid.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.navid.app.core.formatToman
import ir.navid.app.data.AccountEntity
import ir.navid.app.domain.AccountType

private data class KindOption(val label: String, val type: AccountType, val subtype: String)

private val kindOptions = listOf(
    KindOption("حساب بانکی", AccountType.ASSET, "BANK"),
    KindOption("پول نقد", AccountType.ASSET, "CASH"),
    KindOption("دارایی دیگر", AccountType.ASSET, "OTHER"),
    KindOption("دسته هزینه", AccountType.EXPENSE, "CATEGORY"),
    KindOption("نوع درآمد", AccountType.INCOME, "CATEGORY")
)

private fun typeLabel(type: AccountType): String = when (type) {
    AccountType.ASSET -> "حساب ها و دارایی ها"
    AccountType.EXPENSE -> "دسته های هزینه"
    AccountType.INCOME -> "انواع درآمد"
    AccountType.LIABILITY -> "بدهی ها"
    AccountType.EQUITY -> "سرمایه"
}

@Composable
fun AccountsDialog(vm: FinanceViewModel, onDismiss: () -> Unit) {
    val accounts by vm.accounts.collectAsState()
    val balances by vm.balances.collectAsState()
    var renaming by remember { mutableStateOf<AccountEntity?>(null) }
    var adding by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مدیریت حساب ها") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(AccountType.ASSET, AccountType.EXPENSE, AccountType.INCOME).forEach { type ->
                    val group = accounts.filter { it.type == type }
                    if (group.isNotEmpty()) {
                        Text(typeLabel(type), style = MaterialTheme.typography.labelLarge)
                        group.forEach { acc ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(acc.name)
                                    if (type == AccountType.ASSET) {
                                        Text(
                                            (balances[acc.id] ?: 0L).formatToman(),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                                TextButton(onClick = { renaming = acc }) { Text("تغییر نام") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { adding = true }) { Text("افزودن حساب") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )

    renaming?.let { acc ->
        var name by remember(acc.id) { mutableStateOf(acc.name) }
        var error by remember(acc.id) { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("تغییر نام") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; error = null },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    error?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.renameAccount(acc.id, name) { result ->
                        if (result == null) renaming = null else error = result
                    }
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("انصراف") } }
        )
    }

    if (adding) {
        var name by remember { mutableStateOf("") }
        var opening by remember { mutableStateOf("") }
        var kindIndex by remember { mutableStateOf(0) }
        var error by remember { mutableStateOf<String?>(null) }
        val kind = kindOptions[kindIndex]
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("حساب جدید") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; error = null },
                        label = { Text("نام") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("نوع", style = MaterialTheme.typography.labelLarge)
                    kindOptions.forEachIndexed { index, option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { kindIndex = index },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = kindIndex == index, onClick = { kindIndex = index })
                            Text(option.label)
                        }
                    }
                    if (kind.type == AccountType.ASSET) {
                        OutlinedTextField(
                            value = opening,
                            onValueChange = { opening = it; error = null },
                            label = { Text("مانده اولیه (تومان، اختیاری)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    error?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addAccount(name, kind.type, kind.subtype, opening) { result ->
                        if (result == null) adding = false else error = result
                    }
                }) { Text("افزودن") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("انصراف") } }
        )
    }
}
