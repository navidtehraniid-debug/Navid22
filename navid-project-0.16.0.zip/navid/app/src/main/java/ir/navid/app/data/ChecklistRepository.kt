package ir.navid.app.data

import ir.navid.app.core.JalaliDate
import ir.navid.app.domain.CheckStatus
import ir.navid.app.domain.ChecklistParser
import ir.navid.app.domain.SampleChecklists
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ChecklistRepository(private val dao: ChecklistDao) {
    fun templates(): Flow<List<ChecklistTemplateEntity>> = dao.observeTemplates()
    fun templateItems(): Flow<List<ChecklistTemplateItemEntity>> = dao.observeTemplateItems()
    fun runs(): Flow<List<ChecklistRunEntity>> = dao.observeRuns()
    fun results(): Flow<List<ChecklistResultEntity>> = dao.observeResults()

    /** در اولین استفاده، قالب نمونه از فهرست خود کاربر (بتن ریزی) ساخته می شود. */
    suspend fun ensureSample() {
        if (dao.templateCount() > 0) return
        createTemplate(
            SampleChecklists.CONCRETE_TITLE,
            "فونداسیون و اسکلت بتنی",
            SampleChecklists.concretePouring.joinToString("\n"),
            "نمونه از فهرست شما؛ بدون عدد و حد مجاز و هنوز به منبع کتابخانه وصل نشده است"
        )
    }

    /** null یعنی موفق، در غیر این صورت پیام خطا. */
    suspend fun createTemplate(title: String, phaseKey: String, itemsText: String, sourceNote: String = ""): String? {
        val t = title.trim()
        if (t.isEmpty()) return "عنوان قالب را وارد کنید"
        if (t.length > 100) return "عنوان بیش از حد طولانی است"
        val items = ChecklistParser.parseItems(itemsText)
        if (items.isEmpty()) return "حداقل یک مورد وارد کنید (هر مورد در یک خط)"
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        dao.insertTemplateWithItems(
            ChecklistTemplateEntity(id, t, phaseKey.trim(), sourceNote.trim(), now, now),
            items.mapIndexed { i, text -> ChecklistTemplateItemEntity(UUID.randomUUID().toString(), id, i, text) }
        )
        return null
    }

    suspend fun deleteTemplate(id: String) = dao.softDeleteTemplate(id, System.currentTimeMillis())

    suspend fun startRun(projectId: String, templateId: String, date: JalaliDate): String? {
        val template = dao.templateById(templateId) ?: return "قالب پیدا نشد"
        val items = dao.itemsOf(templateId)
        if (items.isEmpty()) return "قالب خالی است"
        val now = System.currentTimeMillis()
        val runId = UUID.randomUUID().toString()
        dao.insertRunWithResults(
            ChecklistRunEntity(runId, projectId, templateId, template.title, date.toLocalDate().toString(), now, now),
            items.map { ChecklistResultEntity(UUID.randomUUID().toString(), runId, it.sortOrder, it.text, CheckStatus.PENDING, "", now) }
        )
        return null
    }

    suspend fun setResult(id: String, status: CheckStatus, note: String) =
        dao.updateResult(id, status.name, note.trim().take(1000), System.currentTimeMillis())

    suspend fun setSource(id: String, ref: String?) = dao.setSource(id, ref?.take(500), System.currentTimeMillis())

    suspend fun deleteRun(id: String) = dao.softDeleteRun(id, System.currentTimeMillis())
}
