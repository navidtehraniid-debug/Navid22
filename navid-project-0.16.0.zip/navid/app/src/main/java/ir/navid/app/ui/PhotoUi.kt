package ir.navid.app.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.SitePhotoEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class PhotoViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).photoDao()
    val photos: StateFlow<List<SitePhotoEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun newFile(): Pair<String, File> {
        val id = UUID.randomUUID().toString()
        val dir = File(app.filesDir, "photos").also { it.mkdirs() }
        return Pair(id, File(dir, "$id.jpg"))
    }

    fun fileOf(p: SitePhotoEntity): File = File(app.filesDir, p.relPath)

    fun register(id: String, projectId: String, refType: String, refId: String, phase: String) {
        viewModelScope.launch {
            dao.insert(SitePhotoEntity(id, projectId, refType, refId, "photos/$id.jpg", "", phase, System.currentTimeMillis()))
        }
    }

    fun discard(file: File) {
        file.delete()
    }

    fun delete(p: SitePhotoEntity) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { fileOf(p).delete() }
            dao.hardDelete(p.id)
        }
    }
}

/** خواندن عکس با کوچک سازی و اعمال چرخش EXIF (دوربین جهت را در EXIF می نویسد). */
internal fun decodePhoto(file: File, maxDim: Int): Bitmap? {
    if (!file.exists()) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxDim) sample *= 2
    val bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
    val degrees = try {
        when (ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
    } catch (e: Exception) {
        0f
    }
    if (degrees == 0f) return bmp
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
}

private fun phaseLabel(phase: String) = when (phase) {
    "BEFORE" -> "قبل"
    "AFTER" -> "بعد"
    else -> "عکس"
}

/** نوار عکس های یک مورد (نتیجه چک لیست یا پروژه) با دکمه های عکس قبل، بعد و عادی. دوربین سیستم باز می شود. */
@Composable
fun PhotoStrip(projectId: String, refType: String, refId: String) {
    val vm: PhotoViewModel = viewModel()
    val all by vm.photos.collectAsState()
    val photos = all.filter { it.refType == refType && it.refId == refId }
    val context = LocalContext.current
    var pending by remember { mutableStateOf<Triple<String, File, String>?>(null) }
    var viewing by remember { mutableStateOf<SitePhotoEntity?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val p = pending
        pending = null
        if (p != null) {
            if (ok) vm.register(p.first, projectId, refType, refId, p.third) else vm.discard(p.second)
        }
    }
    fun capture(phase: String) {
        val (id, file) = vm.newFile()
        pending = Triple(id, file, phase)
        launcher.launch(FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file))
    }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (photos.isNotEmpty()) {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                photos.forEach { p -> PhotoThumb(p, vm.fileOf(p)) { viewing = p } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { capture("BEFORE") }) { Text("عکس قبل") }
            TextButton(onClick = { capture("AFTER") }) { Text("عکس بعد") }
            TextButton(onClick = { capture("NONE") }) { Text("عکس") }
        }
    }

    viewing?.let { p ->
        Dialog(onDismissRequest = { viewing = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { viewing = null }) { Text("بستن") }
                        TextButton(onClick = { vm.delete(p); viewing = null }) { Text("حذف عکس") }
                        Text(phaseLabel(p.phase), style = MaterialTheme.typography.titleSmall)
                    }
                    val bmp by produceState<Bitmap?>(null, p.id) { value = withContext(Dispatchers.IO) { decodePhoto(vm.fileOf(p), 2200) } }
                    bmp?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth().weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoThumb(p: SitePhotoEntity, file: File, onClick: () -> Unit) {
    val bmp by produceState<Bitmap?>(null, p.id) { value = withContext(Dispatchers.IO) { decodePhoto(file, 320) } }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(88.dp).clickable(onClick = onClick)
            )
        } else {
            Text("...", modifier = Modifier.size(88.dp))
        }
        Text(phaseLabel(p.phase), style = MaterialTheme.typography.labelSmall)
    }
}
