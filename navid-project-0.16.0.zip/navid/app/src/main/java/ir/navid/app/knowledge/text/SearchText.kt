package ir.navid.app.knowledge.text

data class ParsedQuery(
    val clause: String?,
    /** همان شماره با اجزای برعکس (کپی از نمایش دیداری)؛ اگر با clause یکی بود null. */
    val clauseAlt: String?,
    val tokens: List<String>,
    val andExpr: String?,
    val orExpr: String?
)

/** توکن سازی، ریشه یابی سبک و ساخت عبارت MATCH برای FTS4 (نحو استاندارد: OR، عبارت با نقل قول، پیشوند با ستاره). */
object SearchText {
    val stopwords: Set<String> =
        "و در به از که را این آن با برای است شود می یا بر تا نیز هم باید ها های بود شده گردد کرد خواهد باشد یک دو آنها بین نباید"
            .split(" ").toSet()

    private val wordRegex = Regex("[\\p{L}\\p{N}]+")
    private val clauseInQuery = Regex("(?<![\\d-])(\\d+(?:-\\d+){1,5})(?![\\d-])")
    private val dashLike = Regex("[\u2010\u2011\u2012\u2013\u2014\u2212\uFE58\uFE63\uFF0D]")
    private val tatweelBetweenDigits = Regex("(?<=\\d)\u0640+(?=\\d)")
    private val spacedDash = Regex("(?<=\\d)\\s*-\\s*(?=\\d)")
    private val dotted = Regex("(?<![\\d./_\u00B7-])\\d+(?:[./_\u00B7]\\d+){2,5}(?![\\d./_\u00B7])")
    private val separatorChars = Regex("[./_\u00B7]")
    private val spacedNumbers = Regex("^\\s*\\d{1,3}(?:\\s+\\d{1,3}){2,4}\\s*$")
    private val whitespaceRuns = Regex("\\s+")

    private fun asciiDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    /**
     * یکسان سازی شماره بند در پرسش پیش از پاک سازی عمومی: ارقام فارسی و عربی، انواع خط تیره، کشیده بین ارقام
     * (پاک سازی عمومی آن را حذف می کرد و «۴ـ۱ـ۵ـ۱» را «4151» می کرد)، فاصله دور خط تیره، و 4.1.5.1 یا 4/1/5/1.
     */
    internal fun normalizeQuery(q: String): String {
        var t = asciiDigits(q)
        t = tatweelBetweenDigits.replace(t, "-")
        t = dashLike.replace(t, "-")
        t = spacedDash.replace(t, "-")
        t = dotted.replace(t) { m -> separatorChars.replace(m.value, "-") }
        if (spacedNumbers.matches(t)) t = whitespaceRuns.replace(t.trim(), "-")
        return t
    }

    private fun canonicalClause(raw: String): String = raw.split("-").joinToString("-") { it.toIntOrNull()?.toString() ?: it }

    /** فقط جمع «ها» و «های» حذف می شود (حذف «ان» کلمه هایی مثل «ساختمان» را خراب می کرد). */
    fun stem(w: String): String {
        for (suf in listOf("\u0647\u0627\u06CC", "\u0647\u0627")) {
            if (w.endsWith(suf) && w.length - suf.length >= 3) return w.substring(0, w.length - suf.length)
        }
        return w
    }

    fun tokens(text: String): List<String> =
        wordRegex.findAll(text.lowercase()).map { stem(it.value) }.toList()

    fun parse(query: String): ParsedQuery {
        val cleaned = PdfTextCleaner.cleanRaw(normalizeQuery(query))
        val clause = clauseInQuery.find(cleaned)?.groupValues?.get(1)?.let { canonicalClause(it) }
        val clauseAlt = clause?.let { c -> c.split("-").reversed().joinToString("-").takeIf { it != c } }
        val rest = clauseInQuery.replace(cleaned, " ")
        val toks = tokens(rest).filter { it !in stopwords }
        if (toks.isEmpty()) return ParsedQuery(clause, clauseAlt, emptyList(), null, null)
        val andExpr = toks.joinToString(" ") { "$it*" }
        val alts = ArrayList<String>()
        toks.forEach { alts.add("$it*") }
        toks.zipWithNext().forEach { (a, b) ->
            alts.add("\"$a $b\"")
            alts.add(a + b)
        }
        return ParsedQuery(clause, clauseAlt, toks, andExpr, alts.joinToString(" OR "))
    }
}
