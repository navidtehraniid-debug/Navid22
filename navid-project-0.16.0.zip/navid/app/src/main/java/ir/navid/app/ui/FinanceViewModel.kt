package ir.navid.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.parseAmount
import ir.navid.app.data.AccountEntity
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.FinanceRepository
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.domain.AccountType
import ir.navid.app.domain.DoubleEntry
import ir.navid.app.domain.LedgerKind
import ir.navid.app.domain.TxKind
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MonthSummary(val income: Long = 0, val expense: Long = 0) {
    val net: Long get() = income - expense
}

class FinanceViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = FinanceRepository(AppDatabase.get(app).financeDao())
    private val today = JalaliDate.today()
    private val monthStart = JalaliDate(today.year, today.month, 1)
    private val monthEnd = JalaliDate(today.year, today.month, JalaliDate.daysInMonth(today.year, today.month))

    val monthTitle: String = "${JalaliDate.monthNames[today.month - 1]} ${today.year}"

    val accounts: StateFlow<List<AccountEntity>> =
        repo.accounts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recent: StateFlow<List<TransactionWithLines>> =
        repo.recent(50).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deleted: StateFlow<List<TransactionWithLines>> =
        repo.deleted().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val monthSummary: StateFlow<MonthSummary> =
        repo.totalsByType(monthStart.toLocalDate().toString(), monthEnd.toLocalDate().toString())
            .map { rows ->
                val income = rows.filter { it.accountType == AccountType.INCOME }
                    .sumOf { DoubleEntry.balanceOf(AccountType.INCOME, it.debit, it.credit) }
                val expense = rows.filter { it.accountType == AccountType.EXPENSE }
                    .sumOf { DoubleEntry.balanceOf(AccountType.EXPENSE, it.debit, it.credit) }
                MonthSummary(income, expense)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MonthSummary())

    /** مانده هر حساب (شناسه حساب به مانده). */
    val balances: StateFlow<Map<String, Long>> =
        combine(repo.accounts, repo.accountTotals) { accountList, totals ->
            val byId = totals.associateBy { it.accountId }
            accountList.associate { acc ->
                val t = byId[acc.id]
                acc.id to DoubleEntry.balanceOf(acc.type, t?.debit ?: 0, t?.credit ?: 0, acc.openingBalance)
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    init {
        viewModelScope.launch {
            repo.ensureSeed()
            repo.purgeExpired()
        }
    }

    fun addAccount(
        name: String,
        type: AccountType,
        subtype: String,
        openingText: String,
        onResult: (String?) -> Unit
    ) {
        var opening = 0L
        if (type == AccountType.ASSET && openingText.isNotBlank()) {
            val parsed = parseAmount(openingText)
            if (parsed == null) {
                onResult("مانده اولیه نامعتبر است")
                return
            }
            opening = parsed
        }
        viewModelScope.launch { onResult(repo.addAccount(name, type, subtype, opening)) }
    }

    fun renameAccount(id: String, name: String, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repo.renameAccount(id, name)) }
    }

    fun delete(txId: String) {
        viewModelScope.launch { repo.delete(txId) }
    }

    fun restore(txId: String) {
        viewModelScope.launch { repo.restore(txId) }
    }

    fun deletePermanently(txId: String) {
        viewModelScope.launch { repo.deletePermanently(txId) }
    }

    /** onResult: null یعنی موفق، در غیر این صورت پیام خطا. */
    fun save(
        kind: TxKind,
        primaryAccountId: String?,
        counterAccountId: String?,
        amountText: String,
        dateText: String,
        description: String,
        editId: String?,
        projectId: String? = null,
        onResult: (String?) -> Unit
    ) {
        val amount = parseAmount(amountText)
        if (amount == null) {
            onResult("مبلغ را به عدد و بزرگ تر از صفر وارد کنید")
            return
        }
        val date = JalaliDate.parse(dateText)
        if (date == null) {
            onResult("تاریخ شمسی را به شکل 1405/08/09 وارد کنید")
            return
        }
        if (primaryAccountId == null || counterAccountId == null) {
            onResult("حساب ها را انتخاب کنید")
            return
        }
        viewModelScope.launch {
            val localDate = date.toLocalDate().toString()
            val error = if (editId == null) {
                repo.record(
                    kind = kind,
                    ledger = LedgerKind.PERSONAL,
                    primaryAccountId = primaryAccountId,
                    counterAccountId = counterAccountId,
                    amount = amount,
                    localDate = localDate,
                    description = description,
                    projectId = projectId
                )
            } else {
                repo.update(
                    txId = editId,
                    kind = kind,
                    primaryAccountId = primaryAccountId,
                    counterAccountId = counterAccountId,
                    amount = amount,
                    localDate = localDate,
                    description = description,
                    projectId = projectId
                )
            }
            onResult(error)
        }
    }
}
