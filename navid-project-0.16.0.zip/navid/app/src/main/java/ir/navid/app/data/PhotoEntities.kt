package ir.navid.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** عکس کارگاه؛ فایل در فضای خصوصی برنامه (files/photos). refType: CHECK_RESULT یا PROJECT. phase: BEFORE، AFTER یا NONE. */
@Entity(tableName = "site_photos", indices = [Index("refId")])
data class SitePhotoEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val refType: String,
    val refId: String,
    val relPath: String,
    val caption: String,
    val phase: String,
    val takenAt: Long,
    val deletedAt: Long? = null
)

@Dao
interface PhotoDao {
    @Query("SELECT * FROM site_photos WHERE deletedAt IS NULL ORDER BY takenAt DESC")
    fun observeAll(): Flow<List<SitePhotoEntity>>

    @Insert
    suspend fun insert(p: SitePhotoEntity)

    @Query("DELETE FROM site_photos WHERE id = :id")
    suspend fun hardDelete(id: String)
}
