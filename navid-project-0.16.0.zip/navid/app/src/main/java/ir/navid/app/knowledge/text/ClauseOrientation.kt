package ir.navid.app.knowledge.text

/**
 * تشخیص خودکار جهت شماره بندها. ابزارهای استخراج برای متن راست به چپ اجزای شماره را گاهی وارونه می دهند
 * (4-3-1-4 به جای 4-1-3-4). در فایل واقعی، با وارونه کردن اجزا همه بندهای هم والد کاملاً صعودی شدند.
 * تصمیم فقط از روی خود سند گرفته می شود (صعودی بودن بندهای هم والد)، نه حدس درباره ابزار.
 */
object ClauseOrientation {
    data class Decision(val reversed: Boolean, val rawOk: Int, val rawTotal: Int, val revOk: Int, val revTotal: Int)

    private val clauseStart = Regex("^(\\d+(?:-\\d+){1,4})(?=\\s|$)")
    private val run = Regex("\\d+(?:-\\d+)+")

    private fun sequences(pages: List<String>): List<List<Int>> {
        val out = ArrayList<List<Int>>()
        for (p in pages) {
            for (ln in p.split("\n")) {
                val m = clauseStart.find(ln) ?: continue
                val nums = m.groupValues[1].split("-").map { it.toIntOrNull() }
                if (nums.all { it != null }) out.add(nums.map { it!! })
            }
        }
        return out
    }

    private fun mono(seqs: List<List<Int>>): Pair<Int, Int> {
        var ok = 0
        var tot = 0
        for (i in 0 until seqs.size - 1) {
            val a = seqs[i]
            val b = seqs[i + 1]
            if (a.size == b.size && a.dropLast(1) == b.dropLast(1)) {
                tot++
                if (b.last() >= a.last()) ok++
            }
        }
        return Pair(ok, tot)
    }

    fun decide(pages: List<String>): Decision {
        val raw = sequences(pages)
        val rev = raw.map { it.reversed() }
        val (ro, rt) = mono(raw)
        val (vo, vt) = mono(rev)
        val reversed = vo > ro && vt >= 3 && vo * 10 >= vt * 9 && (rt == 0 || ro * 10 < rt * 9)
        return Decision(reversed, ro, rt, vo, vt)
    }

    /** اجزای هر عدد خط دار (مثل 4-3-1-4) را وارونه می کند. */
    fun fixRuns(text: String): String =
        run.replace(text) { m -> m.value.split("-").reversed().joinToString("-") }
}
