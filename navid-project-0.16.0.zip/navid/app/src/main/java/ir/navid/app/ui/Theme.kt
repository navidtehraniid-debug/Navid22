package ir.navid.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NavidColors = lightColorScheme(
    primary = Color(0xFF4E8F7C),
    onPrimary = Color.White,
    background = Color(0xFFF7F8F8),
    surface = Color.White,
    onBackground = Color(0xFF1E2322),
    onSurface = Color(0xFF1E2322),
    secondaryContainer = Color(0xFFDCEBE6),
    onSecondaryContainer = Color(0xFF1E2322)
)

@Composable
fun NavidTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NavidColors, content = content)
}
