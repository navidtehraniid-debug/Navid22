package ir.navid.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.navid.app.domain.ReminderLevel
import ir.navid.app.domain.ReminderStatus

@Entity(
    tableName = "reminders",
    indices = [Index("dueAt"), Index("status")]
)
data class ReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val notes: String,
    val dueAt: Long,
    val localDate: String,
    val hour: Int,
    val minute: Int,
    val level: ReminderLevel,
    val exact: Boolean,
    val status: ReminderStatus,
    val source: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)
