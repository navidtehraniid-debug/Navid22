package ir.navid.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import ir.navid.app.ai.model.ApiFormat
import ir.navid.app.ai.model.ModelProvider
import java.io.File

@Composable
fun AiSettingsScreen(vm: AiViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val s by vm.settings.collectAsState()
    val hasKey by vm.hasKey.collectAsState()
    val busy by vm.busy.collectAsState()
    val status by vm.status.collectAsState()
    var baseUrl by remember(s.baseUrl) { mutableStateOf(s.baseUrl) }
    var model by remember(s.model) { mutableStateOf(s.model) }
    var keyText by remember { mutableStateOf("") }
    var serverUrl by remember(s.localServerUrl) { mutableStateOf(s.localServerUrl) }
    var serverModel by remember(s.localServerModel) { mutableStateOf(s.localServerModel) }
    val ocrReady by vm.ocrReady.collectAsState()
    val ocrPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importOcrData(uri)
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLocalModel(uri)
    }

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("بازگشت") }
        }
        Text("مدل هوش مصنوعی", style = MaterialTheme.typography.headlineSmall)
        Text(
            "همه قابلیت های اصلی (مالی، کتابخانه، چک لیست، جست وجو) بدون مدل کار می کنند. مدل فقط برای نوشتن پاسخ از روی گزیده های کتابخانه است و خروجی اش همیشه با اعتبارسنج بررسی می شود (ارجاع و عددها).",
            style = MaterialTheme.typography.bodySmall
        )

        SectionCard("چه کسی پاسخ را بنویسد؟") {
            ModelProvider.values().forEach { p -> AccountChoice(p.labelFa, s.provider == p) { vm.update(s.copy(provider = p)) } }
        }

        SectionCard("سرویس بیرونی (اختیاری)") {
            Text(
                "هر بار پیش از ارسال، پرسش و گزیده های کتابخانه به شما نشان داده می شود و فقط با تأیید شما ارسال می شود. اطلاعات مالی و اطلاعات پروژه ارسال نمی شود.",
                style = MaterialTheme.typography.bodySmall
            )
            ApiFormat.values().forEach { f ->
                AccountChoice(f.labelFa, s.format == f) {
                    val url = if (f == ApiFormat.ANTHROPIC) "https://api.anthropic.com" else s.baseUrl
                    vm.update(s.copy(format = f, baseUrl = url))
                }
            }
            OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("آدرس سرویس") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("نام مدل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                value = keyText,
                onValueChange = { keyText = it },
                label = { Text(if (hasKey) "کلید API (ذخیره شده؛ برای تغییر دوباره وارد کنید)" else "کلید API") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("کلید با Android Keystore رمز می شود و هرگز به صورت متن ساده ذخیره نمی شود.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    vm.update(s.copy(baseUrl = baseUrl, model = model))
                    if (keyText.isNotBlank()) {
                        vm.saveKey(keyText)
                        keyText = ""
                    }
                }) { Text("ذخیره") }
                if (hasKey) TextButton(onClick = { vm.saveKey(null) }) { Text("حذف کلید") }
            }
        }

        SectionCard("مدل محلی روی گوشی (آزمایشی)") {
            if (!vm.localAvailable) {
                Text(
                    "این APK مدل محلی را ندارد. نسخه «NAVID-debug-local.apk» (ساخت آزمایشی با LiteRT-LM) را نصب کنید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            val path = s.localModelPath
            Text(
                if (path != null && File(path).exists()) "فایل مدل آماده است (${File(path).length() / (1024 * 1024)} مگابایت)." else "فایلی انتخاب نشده است.",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "فایل مدل باید با پسوند .litertlm باشد (مدل های LiteRT Community در HuggingFace؛ مدل GGUF سازگار نیست). بنچمارک شما نشان داد مدل های کوچک در فارسی فنی ضعیف اند؛ خروجی مدل محلی هم با همان اعتبارسنج بررسی می شود و بدون ارجاع معتبر پذیرفته نمی شود.",
                style = MaterialTheme.typography.bodySmall
            )
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("انتخاب فایل مدل") }
        }

        SectionCard("سرور محلی روی همین گوشی (برای مدل های GGUF مثل PocketPal)") {
            Text(
                "اگر مدل GGUF دارید، llama.cpp server را روی همین گوشی اجرا کنید (مثلاً در Termux: llama-server -m model.gguf --port 8080) و اینجا آدرسش را بدهید. فقط آدرس 127.0.0.1 یا localhost پذیرفته می شود، چون داده از گوشی خارج نمی شود و پنجره تأیید ارسال لازم نیست.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it }, label = { Text("آدرس سرور") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = serverModel, onValueChange = { serverModel = it }, label = { Text("نام مدل (اختیاری)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.update(s.copy(localServerUrl = serverUrl, localServerModel = serverModel)) }) { Text("ذخیره") }
        }

        SectionCard("خواندن اسکن (OCR فارسی، آزمایشی)") {
            if (!vm.ocrAvailable) {
                Text(
                    "این APK موتور OCR را ندارد. نسخه «NAVID-debug-full.apk» را نصب کنید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            Text(if (ocrReady) "داده فارسی OCR آماده است." else "داده فارسی OCR هنوز نیست.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.downloadOcrData() }, enabled = !busy) { Text("دریافت داده فارسی") }
                TextButton(onClick = { ocrPicker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("انتخاب فایل fas.traineddata") }
            }
            Text("بعد از آماده شدن، در کتابخانه «پردازش مجدد» PDF اسکن شده را بزنید؛ فقط صفحه های بدون لایه متنی با OCR خوانده می شوند. سرعت روی گوشی شما اندازه گیری نشده است.", style = MaterialTheme.typography.bodySmall)
        }

        SectionCard("وضعیت و عیب یابی") {
            SelectionContainer { Text(vm.diagnostics(), style = MaterialTheme.typography.bodySmall) }
            Text("اگر مدل محلی کار نکرد، همین متن (با نگه داشتن انگشت قابل کپی است) را برایم بفرستید.", style = MaterialTheme.typography.bodySmall)
        }

        SectionCard("آزمون مدل فعال") {
            Button(onClick = { vm.testActive() }, enabled = !busy && s.provider != ModelProvider.NONE) {
                Text(if (busy) "در حال کار..." else "آزمون کوتاه")
            }
            status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
