package ir.navid.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.navid.app.domain.CheckStatus

@Entity(tableName = "checklist_templates")
data class ChecklistTemplateEntity(
    @PrimaryKey val id: String,
    val title: String,
    val phaseKey: String,
    val sourceNote: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "checklist_template_items", indices = [Index("templateId")])
data class ChecklistTemplateItemEntity(
    @PrimaryKey val id: String,
    val templateId: String,
    val sortOrder: Int,
    val text: String
)

@Entity(tableName = "checklist_runs", indices = [Index("projectId")])
data class ChecklistRunEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val templateId: String?,
    val title: String,
    val runDate: String,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

/** نتیجه هر مورد در یک بازدید؛ متن مورد از قالب کپی می شود تا ویرایش بعدی قالب بازدیدهای قبلی را تغییر ندهد. */
@Entity(tableName = "checklist_results", indices = [Index("runId")])
data class ChecklistResultEntity(
    @PrimaryKey val id: String,
    val runId: String,
    val sortOrder: Int,
    val itemText: String,
    val status: CheckStatus,
    val note: String,
    val updatedAt: Long,
    /** منبع انتخاب شده از کتابخانه (عنوان، بند، صفحه) به صورت متن خوانا؛ null یعنی هنوز وصل نشده. */
    val sourceRef: String? = null
)
