package ir.navid.app.ai.nlu

import ir.navid.app.core.JalaliDate

enum class MissingField { AMOUNT, DATE }

/**
 * نتیجه تحلیل یک جمله کاربر، فقط با کد.
 * - amounts و date را کد استخراج می کند (نه مدل).
 * - intents خالی و candidates خالی یعنی نامشخص (باید مدل یا کاربر تصمیم بگیرد).
 * - هر هشدار یعنی قبل از ثبت باید کاربر صریحاً تأیید کند.
 */
data class ParsedCommand(
    val normalized: String,
    val intents: List<Intent>,
    val candidates: List<Intent>,
    val amounts: List<AmountMatch>,
    val date: DateMatch,
    val accounts: List<String>,
    val missing: List<MissingField>,
    val warnings: List<String>
) {
    /** مدل فقط وقتی لازم است که قواعد نتوانسته اند نوع پیام را مشخص کنند. */
    val needsModel: Boolean get() = intents.isEmpty()

    /** مبلغ قابل استفاده بدون ابهام: دقیقاً یک مبلغ و بدون پرچم. */
    val safeAmount: Long?
        get() = amounts.singleOrNull()?.takeIf { it.flags.isEmpty() }?.value

    val hasMoneyIntent: Boolean
        get() = (intents + candidates).any { it == Intent.EXPENSE || it == Intent.INCOME || it == Intent.TRANSFER }
}

object CommandParser {
    fun parse(text: String, today: JalaliDate, accountNames: List<String> = emptyList()): ParsedCommand {
        val norm = TextNormalizer.normalize(text)
        val rules = IntentRules.classify(norm, accountNames)
        val amounts = AmountExtractor.extract(norm)
        val date = DateExtractor.extract(norm, today)
        val accounts = IntentRules.accountsMentioned(norm, accountNames)

        val missing = ArrayList<MissingField>()
        val warnings = ArrayList<String>()
        val money = (rules.intents + rules.candidates).any {
            it == Intent.EXPENSE || it == Intent.INCOME || it == Intent.TRANSFER
        }
        if (money && amounts.isEmpty()) missing.add(MissingField.AMOUNT)
        if (Intent.REMINDER in rules.intents && date.date == null) missing.add(MissingField.DATE)

        if (amounts.map { it.value }.distinct().size > 1) warnings.add("MULTIPLE_AMOUNTS")
        for (a in amounts) {
            for (f in a.flags) warnings.add("AMOUNT_" + f.name)
        }
        if (rules.candidates.isNotEmpty()) warnings.add("AMBIGUOUS_INTENT")

        return ParsedCommand(
            normalized = norm,
            intents = rules.intents,
            candidates = rules.candidates,
            amounts = amounts,
            date = date,
            accounts = accounts,
            missing = missing,
            warnings = warnings.distinct()
        )
    }
}
