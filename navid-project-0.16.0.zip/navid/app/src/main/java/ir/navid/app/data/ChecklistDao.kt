package ir.navid.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class ChecklistDao {
    @Query("SELECT * FROM checklist_templates WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    abstract fun observeTemplates(): Flow<List<ChecklistTemplateEntity>>

    @Query("SELECT * FROM checklist_template_items ORDER BY templateId, sortOrder")
    abstract fun observeTemplateItems(): Flow<List<ChecklistTemplateItemEntity>>

    @Query("SELECT COUNT(*) FROM checklist_templates")
    abstract suspend fun templateCount(): Int

    @Query("SELECT * FROM checklist_templates WHERE id = :id LIMIT 1")
    abstract suspend fun templateById(id: String): ChecklistTemplateEntity?

    @Query("SELECT * FROM checklist_template_items WHERE templateId = :id ORDER BY sortOrder")
    abstract suspend fun itemsOf(id: String): List<ChecklistTemplateItemEntity>

    @Insert
    abstract suspend fun insertTemplate(t: ChecklistTemplateEntity)

    @Insert
    abstract suspend fun insertTemplateItems(items: List<ChecklistTemplateItemEntity>)

    @Transaction
    open suspend fun insertTemplateWithItems(t: ChecklistTemplateEntity, items: List<ChecklistTemplateItemEntity>) {
        insertTemplate(t)
        insertTemplateItems(items)
    }

    @Query("UPDATE checklist_templates SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    abstract suspend fun softDeleteTemplate(id: String, at: Long)

    @Query("SELECT * FROM checklist_runs WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    abstract fun observeRuns(): Flow<List<ChecklistRunEntity>>

    @Query("SELECT * FROM checklist_results ORDER BY runId, sortOrder")
    abstract fun observeResults(): Flow<List<ChecklistResultEntity>>

    @Insert
    abstract suspend fun insertRun(run: ChecklistRunEntity)

    @Insert
    abstract suspend fun insertResults(results: List<ChecklistResultEntity>)

    @Transaction
    open suspend fun insertRunWithResults(run: ChecklistRunEntity, results: List<ChecklistResultEntity>) {
        insertRun(run)
        insertResults(results)
    }

    @Query("UPDATE checklist_results SET status = :status, note = :note, updatedAt = :at WHERE id = :id")
    abstract suspend fun updateResult(id: String, status: String, note: String, at: Long)

    @Query("UPDATE checklist_results SET sourceRef = :ref, updatedAt = :at WHERE id = :id")
    abstract suspend fun setSource(id: String, ref: String?, at: Long)

    @Query("UPDATE checklist_runs SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    abstract suspend fun softDeleteRun(id: String, at: Long)
}
