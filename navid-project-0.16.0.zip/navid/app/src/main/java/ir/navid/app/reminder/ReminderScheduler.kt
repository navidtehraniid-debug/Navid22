package ir.navid.app.reminder

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import ir.navid.app.data.ReminderEntity

object ReminderScheduler {
    const val ACTION = "ir.navid.app.REMINDER_ALARM"
    const val EXTRA_ID = "reminder_id"
    const val EXTRA_TITLE = "reminder_title"
    const val EXTRA_LEVEL = "reminder_level"

    private fun baseIntent(context: Context, id: String): Intent =
        Intent(context, ReminderReceiver::class.java).setAction(ACTION).putExtra(EXTRA_ID, id)

    /** آلارم دقیق (حتی در حالت Doze). اگر اجازه آلارم دقیق نباشد، آلارم تقریبی ثبت می شود. */
    @SuppressLint("ScheduleExactAlarm")
    fun schedule(context: Context, r: ReminderEntity) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = baseIntent(context, r.id)
            .putExtra(EXTRA_TITLE, r.title)
            .putExtra(EXTRA_LEVEL, r.level.name)
        val pi = PendingIntent.getBroadcast(
            context,
            r.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val canExact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (canExact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.dueAt, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.dueAt, pi)
        }
    }

    fun cancel(context: Context, id: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            context,
            id.hashCode(),
            baseIntent(context, id),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }
}
