package ir.navid.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        AccountEntity::class,
        TransactionEntity::class,
        LineEntity::class,
        MemoryEntity::class,
        ReminderEntity::class,
        ProjectEntity::class,
        PhaseEntity::class,
        SiteReportEntity::class,
        ChecklistTemplateEntity::class,
        ChecklistTemplateItemEntity::class,
        ChecklistRunEntity::class,
        ChecklistResultEntity::class,
        SitePhotoEntity::class,
        ProjectDocumentEntity::class
    ],
    version = 8,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun financeDao(): FinanceDao
    abstract fun memoryDao(): MemoryDao
    abstract fun reminderDao(): ReminderDao
    abstract fun buildingDao(): BuildingDao
    abstract fun checklistDao(): ChecklistDao
    abstract fun photoDao(): PhotoDao
    abstract fun projectDocDao(): ProjectDocDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        /** نسخه 1 به 2: افزودن جدول حافظه و یادداشت ها. داده های مالی دست نخورده می مانند. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `memories` (" +
                        "`id` TEXT NOT NULL, " +
                        "`category` TEXT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`content` TEXT NOT NULL, " +
                        "`source` TEXT NOT NULL, " +
                        "`dedupeHash` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`updatedAt` INTEGER NOT NULL, " +
                        "`deletedAt` INTEGER, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_memories_category` ON `memories` (`category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_memories_dedupeHash` ON `memories` (`dedupeHash`)")
            }
        }

        /** نسخه 2 به 3: افزودن جدول یادآوری ها. داده های قبلی دست نخورده می مانند. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `reminders` (" +
                        "`id` TEXT NOT NULL, " +
                        "`title` TEXT NOT NULL, " +
                        "`notes` TEXT NOT NULL, " +
                        "`dueAt` INTEGER NOT NULL, " +
                        "`localDate` TEXT NOT NULL, " +
                        "`hour` INTEGER NOT NULL, " +
                        "`minute` INTEGER NOT NULL, " +
                        "`level` TEXT NOT NULL, " +
                        "`exact` INTEGER NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`source` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`updatedAt` INTEGER NOT NULL, " +
                        "`deletedAt` INTEGER, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_dueAt` ON `reminders` (`dueAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_reminders_status` ON `reminders` (`status`)")
            }
        }

        /** نسخه 3 به 4: ماژول ساختمان (پروژه، مراحل، گزارش کارگاه) و ستون پروژه روی تراکنش ها. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `projects` (" +
                        "`id` TEXT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`address` TEXT NOT NULL, " +
                        "`landArea` REAL, " +
                        "`builtArea` REAL, " +
                        "`floors` INTEGER, " +
                        "`structureType` TEXT NOT NULL, " +
                        "`initialBudget` INTEGER NOT NULL, " +
                        "`status` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`updatedAt` INTEGER NOT NULL, " +
                        "`deletedAt` INTEGER, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `phases` (" +
                        "`id` TEXT NOT NULL, " +
                        "`projectId` TEXT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`sortOrder` INTEGER NOT NULL, " +
                        "`plannedStart` TEXT, " +
                        "`plannedEnd` TEXT, " +
                        "`actualStart` TEXT, " +
                        "`actualEnd` TEXT, " +
                        "`status` TEXT NOT NULL, " +
                        "`progressPct` INTEGER NOT NULL, " +
                        "`notes` TEXT NOT NULL, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_phases_projectId` ON `phases` (`projectId`)")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `site_reports` (" +
                        "`id` TEXT NOT NULL, " +
                        "`projectId` TEXT NOT NULL, " +
                        "`phaseId` TEXT, " +
                        "`reportDate` TEXT NOT NULL, " +
                        "`text` TEXT NOT NULL, " +
                        "`source` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`deletedAt` INTEGER, " +
                        "PRIMARY KEY(`id`))"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_site_reports_projectId` ON `site_reports` (`projectId`)")
                db.execSQL("ALTER TABLE `transactions` ADD COLUMN `projectId` TEXT")
            }
        }

        /** نسخه 4 به 5: قالب و بازدید چک لیست های نظارتی. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `checklist_templates` (`id` TEXT NOT NULL, `title` TEXT NOT NULL, `phaseKey` TEXT NOT NULL, `sourceNote` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `deletedAt` INTEGER, PRIMARY KEY(`id`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `checklist_template_items` (`id` TEXT NOT NULL, `templateId` TEXT NOT NULL, `sortOrder` INTEGER NOT NULL, `text` TEXT NOT NULL, PRIMARY KEY(`id`))")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_checklist_template_items_templateId` ON `checklist_template_items` (`templateId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `checklist_runs` (`id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `templateId` TEXT, `title` TEXT NOT NULL, `runDate` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `deletedAt` INTEGER, PRIMARY KEY(`id`))")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_checklist_runs_projectId` ON `checklist_runs` (`projectId`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `checklist_results` (`id` TEXT NOT NULL, `runId` TEXT NOT NULL, `sortOrder` INTEGER NOT NULL, `itemText` TEXT NOT NULL, `status` TEXT NOT NULL, `note` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_checklist_results_runId` ON `checklist_results` (`runId`)")
            }
        }

        /** نسخه 5 به 6: منبع کتابخانه برای هر مورد چک لیست. */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `checklist_results` ADD COLUMN `sourceRef` TEXT")
            }
        }

        /** نسخه 6 به 7: عکس های کارگاه. */
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `site_photos` (`id` TEXT NOT NULL, `projectId` TEXT NOT NULL, `refType` TEXT NOT NULL, `refId` TEXT NOT NULL, `relPath` TEXT NOT NULL, `caption` TEXT NOT NULL, `phase` TEXT NOT NULL, `takenAt` INTEGER NOT NULL, `deletedAt` INTEGER, PRIMARY KEY(`id`))")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_site_photos_refId` ON `site_photos` (`refId`)")
            }
        }

        /** نسخه 7 به 8: پیوند سند کتابخانه به پروژه (نسخه حاکم، نقشه مصوب، ...). */
        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `project_documents` (`projectId` TEXT NOT NULL, `docId` TEXT NOT NULL, `role` TEXT NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`projectId`, `docId`))")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_project_documents_docId` ON `project_documents` (`docId`)")
            }
        }

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "navid.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8).build().also { instance = it }
            }
    }
}
