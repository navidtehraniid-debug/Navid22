package ir.navid.app.domain

import ir.navid.app.knowledge.text.PdfTextCleaner

enum class DocRole(val labelFa: String) {
    GOVERNING("نسخه حاکم استاندارد یا مقررات"),
    SPEC("مشخصات فنی پروژه"),
    DRAWING("نقشه مصوب"),
    CONTRACT("قرارداد"),
    OTHER("سایر")
}

object CurrentPhase {
    /** مرحله فعلی: اولین مرحله «در حال انجام» به ترتیب، وگرنه اولین «شروع نشده». */
    fun <T> of(phases: List<T>, order: (T) -> Int, status: (T) -> PhaseStatus): T? {
        val sorted = phases.sortedBy(order)
        return sorted.firstOrNull { status(it) == PhaseStatus.IN_PROGRESS } ?: sorted.firstOrNull { status(it) == PhaseStatus.NOT_STARTED }
    }
}

object PhaseMatch {
    private val splitter = Regex("[,\u060C;\\n]+")

    private fun norm(s: String): String = PdfTextCleaner.cleanRaw(s).replace(" ", "").lowercase()

    /** آیا یکی از مراحل مرتبط سند (با ویرگول) با نام مرحله فعلی پروژه می خواند؟ */
    fun matches(docPhaseKeys: String, phaseName: String?): Boolean {
        if (phaseName.isNullOrBlank() || docPhaseKeys.isBlank()) return false
        val phase = norm(phaseName)
        return splitter.split(docPhaseKeys).map { norm(it) }.filter { it.length >= 3 }.any { phase.contains(it) || it.contains(phase) }
    }
}
