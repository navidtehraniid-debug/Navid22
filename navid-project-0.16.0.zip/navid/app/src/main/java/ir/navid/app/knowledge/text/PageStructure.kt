package ir.navid.app.knowledge.text

/** تشخیص شماره صفحه چاپی و حذف سرصفحه های تکراری (با استخراج نام فصل)، روی متن صفحه یا روی سطرها. */
object PageStructure {
    data class Printed(val offset: Int?, val found: Map<Int, Int>)
    data class Stripped(val pages: List<String>, val chapters: List<String>)
    data class StrippedLines<T>(val pages: List<List<T>>, val chapters: List<String>)

    private val digitsOnly = Regex("\\d{1,4}")

    fun <T> detectPrintedLines(pages: List<List<T>>, text: (T) -> String): Printed {
        val found = LinkedHashMap<Int, Int>()
        pages.forEachIndexed { index, lines ->
            val nonBlank = lines.map { text(it) }.filter { it.isNotBlank() }
            for (l in nonBlank.takeLast(3).asReversed()) {
                if (digitsOnly.matches(l.trim())) {
                    found[index + 1] = l.trim().toInt()
                    break
                }
            }
        }
        if (found.isEmpty()) return Printed(null, found)
        val counts = found.entries.map { it.key - it.value }.groupingBy { it }.eachCount()
        val best = counts.entries.maxByOrNull { it.value } ?: return Printed(null, found)
        return Printed(if (best.value >= 3 && best.value * 2 >= found.size) best.key else null, found)
    }

    fun <T> stripPageNumberLines(pages: List<List<T>>, offset: Int?, text: (T) -> String): List<List<T>> {
        if (offset == null) return pages
        return pages.mapIndexed { index, lines ->
            val mutable = lines.toMutableList()
            val nonBlank = mutable.indices.filter { text(mutable[it]).isNotBlank() }
            for (k in nonBlank.takeLast(3).asReversed()) {
                val s = text(mutable[k]).trim()
                if (digitsOnly.matches(s) && s.toInt() == index + 1 - offset) {
                    mutable.removeAt(k)
                    break
                }
            }
            mutable
        }
    }

    fun <T> detectHeaderLines(pages: List<List<T>>, minSupport: Int = 3, text: (T) -> String): Set<String> {
        val counts = HashMap<String, Int>()
        for (lines in pages) {
            val top = lines.map { text(it).trim() }.filter { it.isNotEmpty() }.take(2).toSet()
            for (l in top) counts[l] = (counts[l] ?: 0) + 1
        }
        return counts.filter { it.value >= minSupport && it.key.length <= 80 }.keys
    }

    fun <T> stripHeaderLines(pages: List<List<T>>, headers: Set<String>, text: (T) -> String): StrippedLines<T> {
        val out = ArrayList<List<T>>()
        val chapters = ArrayList<String>()
        var cur = ""
        for (lines in pages) {
            val kept = ArrayList<T>()
            var seen = 0
            for (l in lines) {
                val s = text(l).trim()
                if (s.isNotEmpty() && seen < 2 && s in headers) {
                    if (s.startsWith("فصل") || s.startsWith("پیوست")) cur = s
                    seen++
                    continue
                }
                if (s.isNotEmpty()) seen++
                kept.add(l)
            }
            chapters.add(cur)
            out.add(kept)
        }
        return StrippedLines(out, chapters)
    }

    // نسخه متنی (مسیر پشتیبان بدون مختصات)
    fun detectPrinted(pages: List<String>): Printed = detectPrintedLines(pages.map { it.split("\n") }) { it }

    fun stripPageNumbers(pages: List<String>, offset: Int?): List<String> {
        if (offset == null) return pages
        return stripPageNumberLines(pages.map { it.split("\n") }, offset) { it }.map { it.joinToString("\n") }
    }

    fun detectHeaders(pages: List<String>, minSupport: Int = 3): Set<String> =
        detectHeaderLines(pages.map { it.split("\n") }, minSupport) { it }

    fun stripHeaders(pages: List<String>, headers: Set<String>): Stripped {
        val r = stripHeaderLines(pages.map { it.split("\n") }, headers) { it }
        return Stripped(r.pages.map { it.joinToString("\n").trim('\n') }, r.chapters)
    }
}
