package ir.navid.app.ai.action

import ir.navid.app.ai.nlu.Intent
import ir.navid.app.ai.nlu.IntentRules
import ir.navid.app.ai.nlu.NOT_LETTER_AFTER
import ir.navid.app.ai.nlu.NOT_LETTER_BEFORE
import ir.navid.app.ai.nlu.ParsedCommand
import ir.navid.app.core.JalaliDate
import ir.navid.app.domain.AccountType
import ir.navid.app.domain.MemoryCategory
import ir.navid.app.domain.TxKind

data class AccountRef(val id: String, val name: String, val type: AccountType)

data class ProjectRef(val id: String, val name: String)

/** پیشنهاد اجرایی که فقط پس از تأیید صریح کاربر ثبت می شود. */
sealed interface Proposal {
    data class Money(
        val kind: TxKind,
        val amount: Long?,
        val amountNeedsCheck: Boolean,
        val date: JalaliDate,
        val dateFromText: Boolean,
        val primaryId: String?,
        val counterId: String?,
        val description: String,
        val alsoSiteReport: Boolean,
        val warnings: List<String>,
        val projectId: String? = null
    ) : Proposal

    data class Note(
        val category: MemoryCategory,
        val title: String,
        val content: String,
        val info: String?
    ) : Proposal

    /** گزارش کارگاه واقعی روی یک پروژه ساختمانی. projectId پیشنهادی است و قابل تغییر. */
    data class SiteReport(val text: String, val projectId: String?) : Proposal

    data class Reminder(
        val title: String,
        val date: JalaliDate?,
        val hour: Int,
        val minute: Int,
        val dateFromText: Boolean,
        val timeFromText: Boolean
    ) : Proposal

    data class Choice(val options: List<Intent>) : Proposal

    /** پرسش فنی: فقط گزیده های مرتبط از کتابخانه با ارجاع نشان داده می شود (بدون مدل و بدون نتیجه گیری). */
    data class Knowledge(val query: String) : Proposal
    data class Unsupported(val reason: String) : Proposal
}

object ReminderTitle {
    private val phrases = Regex("(یادم\\s*بنداز|یادم\\s*باشه|یاد\\s*آوری\\s*کن|یادآوری\\s*کن|به\\s*یادم\\s*بیار|یادم\\s*بیار)")
    private val spaces = Regex("\\s+")

    /** عبارت «یادم بنداز» و علائم اضافه را از عنوان حذف می کند؛ اگر چیزی نماند، خود جمله عنوان است. */
    fun clean(text: String): String {
        val t = spaces.replace(phrases.replace(text, " "), " ").trim().trim('،', ',', '.', '؛', ';', '!', '؟', '?', ' ')
        return t.ifBlank { text.trim() }
    }
}

object CategoryGuesser {
    private val expenseRules: List<Pair<String, Regex>> = listOf(
        "حمل و نقل" to rx("بنزین", "تاکسی", "کرایه", "اسنپ", "مترو", "اتوبوس", "عوارض", "پارکینگ"),
        "خوراک" to rx("نهار", "شام", "صبحانه", "غذا", "رستوران", "میوه", "نان", "سوپر", "خوراک"),
        "قبوض" to rx("قبض", "برق", "گاز", "آب", "اینترنت", "تلفن", "شارژ"),
        "سلامت" to rx("دارو", "دکتر", "درمان", "بیمارستان", "داروخانه", "ویزیت")
    )

    private fun rx(vararg words: String): Regex =
        Regex(NOT_LETTER_BEFORE + "(?:" + words.joinToString("|") + ")" + NOT_LETTER_AFTER)

    fun expenseCategory(norm: String): String? =
        expenseRules.firstOrNull { it.second.containsMatchIn(norm) }?.first

    fun incomeCategory(norm: String): String =
        if (Regex(NOT_LETTER_BEFORE + "(?:حقوق|حقوقم)" + NOT_LETTER_AFTER).containsMatchIn(norm)) "حقوق و دستمزد" else "سایر درآمدها"
}

/**
 * تبدیل نتیجه تحلیل جمله به یک پیشنهاد قابل تأیید. هیچ ثبتی اینجا انجام نمی شود.
 * مبلغ فقط از استخراج با کد می آید؛ اگر چند مبلغ یا مبلغ مشکوک بود، کاربر باید خودش مبلغ را وارد یا تأیید کند.
 */
object ActionPlanner {
    /** نشانه پرسش مالی؛ این پرسش ها به کتابخانه فنی فرستاده نمی شوند. */
    private val financeCue = Regex("خرج|هزینه|درآمد|حقوق|موجود[یي]|مانده|حساب|تومان|ریال|پرداخت|دریافت|بده[یي]|قسط|وام")

    private val defaultChoices = listOf(Intent.EXPENSE, Intent.INCOME, Intent.TRANSFER, Intent.NOTE, Intent.QUESTION)
    private val notePrefix = Regex("^\\s*یادداشت کن( که)?\\s*")

    fun plan(
        parsed: ParsedCommand,
        original: String,
        accounts: List<AccountRef>,
        today: JalaliDate,
        forced: Intent? = null,
        projects: List<ProjectRef> = emptyList()
    ): Proposal {
        val text = original.trim()
        val action: Intent? = forced ?: parsed.intents.firstOrNull { it != Intent.SITE_REPORT }
        val siteAlso = Intent.SITE_REPORT in parsed.intents
        return when (action) {
            Intent.EXPENSE, Intent.INCOME, Intent.TRANSFER -> planMoney(requireNotNull(action), parsed, text, accounts, today, siteAlso, projects)
            Intent.NOTE -> {
                val content = notePrefix.replace(text, "").ifBlank { text }
                Proposal.Note(MemoryCategory.NOTES, "", content, null)
            }
            Intent.REMINDER -> planReminder(parsed, text)
            Intent.QUESTION ->
                if (financeCue.containsMatchIn(text)) Proposal.Unsupported("پاسخ به پرسش های مالی به مدل هوش مصنوعی نیاز دارد که هنوز به برنامه وصل نشده است.")
                else Proposal.Knowledge(text)
            Intent.SITE_REPORT -> siteNote(text, projects)
            null -> when {
                parsed.candidates.isNotEmpty() -> Proposal.Choice(parsed.candidates)
                siteAlso -> siteNote(text, projects)
                else -> Proposal.Choice(defaultChoices)
            }
        }
    }

    /** ساعت پیش فرض وقتی در جمله نباشد؛ همیشه در کارت تأیید دیده می شود و قابل تغییر است. */
    const val DEFAULT_REMINDER_HOUR = 7
    const val DEFAULT_REMINDER_MINUTE = 30

    private fun planReminder(parsed: ParsedCommand, text: String): Proposal.Reminder = Proposal.Reminder(
        title = ReminderTitle.clean(text),
        date = parsed.date.date,
        hour = parsed.date.hour ?: DEFAULT_REMINDER_HOUR,
        minute = parsed.date.minute ?: DEFAULT_REMINDER_MINUTE,
        dateFromText = parsed.date.date != null,
        timeFromText = parsed.date.hasTime
    )

    private fun siteNote(text: String, projects: List<ProjectRef>): Proposal =
        if (projects.isEmpty()) {
            Proposal.Note(
                MemoryCategory.BUILDING,
                "گزارش کارگاه",
                text,
                "پروژه ای ساخته نشده؛ برای ثبت گزارش واقعی ابتدا در تب ساختمان یک پروژه بسازید. فعلاً به صورت یادداشت دسته «ساختمان» ذخیره می شود."
            )
        } else {
            Proposal.SiteReport(text, if (projects.size == 1) projects[0].id else null)
        }

    private fun planMoney(
        kind: Intent,
        parsed: ParsedCommand,
        text: String,
        accounts: List<AccountRef>,
        today: JalaliDate,
        siteAlso: Boolean,
        projects: List<ProjectRef>
    ): Proposal.Money {
        val norm = parsed.normalized
        val assets = accounts.filter { it.type == AccountType.ASSET }
        val mentioned = IntentRules.accountsMentionedOrdered(norm, assets.map { it.name })
            .mapNotNull { n -> assets.firstOrNull { it.name == n } }

        val amounts = parsed.amounts
        val amount = if (amounts.size == 1) amounts[0].value else null
        val needsCheck = amounts.size > 1 || amounts.any { it.flags.isNotEmpty() }

        val warnings = ArrayList<String>(parsed.warnings)
        var primary: AccountRef?
        var counter: AccountRef?
        val txKind: TxKind
        when (kind) {
            Intent.EXPENSE -> {
                txKind = TxKind.EXPENSE
                primary = mentioned.firstOrNull() ?: assets.firstOrNull()
                val expenses = accounts.filter { it.type == AccountType.EXPENSE }
                val guessed = CategoryGuesser.expenseCategory(norm)
                counter = expenses.firstOrNull { it.name == guessed }
                    ?: expenses.firstOrNull { it.name == "سایر هزینه ها" }
                    ?: expenses.firstOrNull()
            }
            Intent.INCOME -> {
                txKind = TxKind.INCOME
                primary = mentioned.firstOrNull() ?: assets.firstOrNull()
                val incomes = accounts.filter { it.type == AccountType.INCOME }
                val guessed = CategoryGuesser.incomeCategory(norm)
                counter = incomes.firstOrNull { it.name == guessed } ?: incomes.firstOrNull()
            }
            else -> {
                txKind = TxKind.TRANSFER
                primary = mentioned.getOrNull(0) ?: assets.firstOrNull()
                counter = mentioned.getOrNull(1) ?: assets.firstOrNull { it.id != primary?.id }
                if (mentioned.size < 2) warnings.add("TRANSFER_ACCOUNTS_UNCERTAIN")
            }
        }
        val description = text.take(200)
        return Proposal.Money(
            kind = txKind,
            amount = amount,
            amountNeedsCheck = needsCheck,
            date = parsed.date.date ?: today,
            dateFromText = parsed.date.date != null,
            primaryId = primary?.id,
            counterId = counter?.id,
            description = description,
            alsoSiteReport = siteAlso,
            warnings = warnings.distinct(),
            projectId = if (txKind == TxKind.EXPENSE && siteAlso && projects.size == 1) projects[0].id else null
        )
    }
}
