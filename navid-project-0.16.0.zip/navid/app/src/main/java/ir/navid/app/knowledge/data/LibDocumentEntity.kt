package ir.navid.app.knowledge.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.navid.app.domain.DocOrigin
import ir.navid.app.domain.DocStatus
import ir.navid.app.domain.DocType
import ir.navid.app.domain.IngestStatus

@Entity(tableName = "lib_documents", indices = [Index("sha256")])
data class LibDocumentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val publisher: String,
    val authors: String,
    val year: Int?,
    val edition: String,
    val docType: DocType,
    val sourceGroup: Int,
    val topic: String,
    val phaseKeys: String,
    val status: DocStatus,
    val statusNote: String,
    val origin: DocOrigin,
    val originUrl: String,
    val fileName: String,
    val relPath: String,
    val mime: String,
    val sha256: String,
    val sizeBytes: Long,
    val pageCount: Int?,
    val ingestStatus: IngestStatus,
    val userNotes: String,
    val projectId: String?,
    val uploadedAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null,
    val ingestInfo: String? = null,
    val printedOffset: Int? = null,
    val clauseReversed: Boolean? = null,
    val pagesWithText: Int? = null,
    val chunkCount: Int? = null,
    val ingestedAt: Long? = null,
    /** اجازه ارسال گزیده های این سند به سرویس بیرونی؛ null یعنی پیش فرض بر اساس گروه منبع. */
    val externalOk: Boolean? = null
)
