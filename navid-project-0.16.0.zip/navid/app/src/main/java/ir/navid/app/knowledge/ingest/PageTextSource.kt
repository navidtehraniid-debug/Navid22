package ir.navid.app.knowledge.ingest

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import ir.navid.app.knowledge.text.Glyph
import java.io.File

class PageGlyphs(val glyphs: List<Glyph>, val height: Float)

interface PageTextSource {
    val pageCount: Int
    fun rawText(pageIndex: Int): String
    /** نویسه ها با مختصات؛ مبنای بازسازی درست ترتیب حروف و کلمه ها در متن فارسی. */
    fun glyphs(pageIndex: Int): PageGlyphs
    fun close()
}

/** استخراج با PdfBox-Android 2.0.27.0 (Apache 2.0). فقط متن و موقعیت نویسه ها گرفته می شود؛ ترتیب را برنامه می سازد. */
class PdfBoxPageTextSource private constructor(private val doc: PDDocument) : PageTextSource {
    private val stripper = PDFTextStripper()

    private class GlyphCollector : PDFTextStripper() {
        val glyphs = ArrayList<Glyph>()

        override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
            if (textPositions == null) return
            for (tp in textPositions) {
                val u = tp.unicode
                if (u.isNullOrEmpty()) continue
                if (tp.dir != 0f) continue // متن چرخیده (سرستون جدول ها) فعلاً کنار گذاشته می شود
                glyphs.add(Glyph(u, tp.xDirAdj, tp.widthDirAdj, tp.yDirAdj, tp.fontSizeInPt))
            }
        }
    }

    override val pageCount: Int get() = doc.numberOfPages

    override fun rawText(pageIndex: Int): String {
        stripper.startPage = pageIndex + 1
        stripper.endPage = pageIndex + 1
        return stripper.getText(doc)
    }

    override fun glyphs(pageIndex: Int): PageGlyphs {
        val collector = GlyphCollector()
        collector.startPage = pageIndex + 1
        collector.endPage = pageIndex + 1
        collector.getText(doc)
        val page = doc.getPage(pageIndex)
        val box = page.cropBox ?: page.mediaBox
        val height = if (page.rotation % 180 == 0) box.height else box.width
        return PageGlyphs(collector.glyphs, height)
    }

    override fun close() {
        doc.close()
    }

    companion object {
        fun open(context: Context, file: File): PdfBoxPageTextSource {
            PDFBoxResourceLoader.init(context.applicationContext)
            return PdfBoxPageTextSource(PDDocument.load(file, MemoryUsageSetting.setupMixed(32L * 1024 * 1024)))
        }
    }
}
