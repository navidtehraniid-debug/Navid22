package ir.navid.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import ir.navid.app.domain.DocRole
import kotlinx.coroutines.flow.Flow

/** پیوند یک سند کتابخانه به پروژه (ارجاع با شناسه؛ کتابخانه دیتابیس جدا دارد). */
@Entity(tableName = "project_documents", primaryKeys = ["projectId", "docId"], indices = [Index("docId")])
data class ProjectDocumentEntity(
    val projectId: String,
    val docId: String,
    val role: DocRole,
    val note: String,
    val createdAt: Long
)

@Dao
interface ProjectDocDao {
    @Query("SELECT * FROM project_documents ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ProjectDocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: ProjectDocumentEntity)

    @Query("DELETE FROM project_documents WHERE projectId = :projectId AND docId = :docId")
    suspend fun remove(projectId: String, docId: String)

    @Query("SELECT docId FROM project_documents WHERE projectId = :projectId AND role = 'GOVERNING'")
    suspend fun governingDocIds(projectId: String): List<String>
}

/** آخرین پروژه ای که کاربر باز کرده؛ زمینه جست وجو (نسخه حاکم و مرحله فعلی) از روی آن ساخته می شود. */
class ActiveProjectStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("active_project", Context.MODE_PRIVATE)
    fun get(): String? = prefs.getString("id", null)
    fun set(id: String?) {
        prefs.edit().putString("id", id).apply()
    }
}
