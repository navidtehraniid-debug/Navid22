package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.navid.app.ai.nlu.AmountFlag
import ir.navid.app.ai.nlu.CommandParser
import ir.navid.app.ai.nlu.Intent
import ir.navid.app.ai.nlu.MissingField
import ir.navid.app.ai.nlu.ParsedCommand
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.formatToman
import ir.navid.app.core.toPersianDigits

internal fun intentLabel(i: Intent): String = when (i) {
    Intent.NOTE -> "یادداشت"
    Intent.REMINDER -> "یادآوری"
    Intent.QUESTION -> "پرسش فنی از کتابخانه"
    Intent.TRANSFER -> "انتقال بین حساب ها"
    Intent.INCOME -> "درآمد"
    Intent.EXPENSE -> "هزینه"
    Intent.SITE_REPORT -> "گزارش کارگاه"
}

private fun flagLabel(f: AmountFlag): String = when (f) {
    AmountFlag.RANGE -> "بازه ای است"
    AmountFlag.APPROX -> "تقریبی است"
    AmountFlag.RELATIVE -> "نسبی است (برابر، درصد)"
    AmountFlag.TRAILING -> "بعد از آن عدد دیگری هست و ممکن است ناقص باشد"
}

/** صفحه آزمایشی: تحلیل جمله فقط با قواعد و استخراج با کد (بدون مدل هوش مصنوعی). */
@Composable
fun NluTestScreen(accountNames: List<String>, onBack: () -> Unit, modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ParsedCommand?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack) { Text("بازگشت") }
        Text("آزمایش تحلیل جمله", style = MaterialTheme.typography.titleLarge)
        Text(
            "بدون مدل هوش مصنوعی: نوع پیام با قواعد، و مبلغ و تاریخ با کد استخراج می شوند. چیزی ثبت نمی شود.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("یک جمله بنویسید") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { result = CommandParser.parse(text, JalaliDate.today(), accountNames) }) {
            Text("تحلیل")
        }
        result?.let { r ->
            SectionCard("نتیجه") {
                val kind = when {
                    r.intents.isNotEmpty() -> r.intents.joinToString(" و ") { intentLabel(it) }
                    r.candidates.isNotEmpty() -> "نامشخص بین: " + r.candidates.joinToString(" یا ") { intentLabel(it) }
                    else -> "نامشخص (مدل یا کاربر باید تصمیم بگیرد)"
                }
                Text("نوع: $kind")
                if (r.amounts.isEmpty()) {
                    Text("مبلغ: پیدا نشد")
                } else {
                    r.amounts.forEach { a ->
                        val flags = if (a.flags.isEmpty()) "" else "  (" + a.flags.joinToString("، ") { flagLabel(it) } + ")"
                        Text("مبلغ: ${a.value.formatToman()}$flags")
                    }
                }
                val d = r.date
                val dateText = d.date?.formatLong() ?: "پیدا نشد"
                val timeText = if (d.hasTime) {
                    "  ساعت " + String.format(java.util.Locale.US, "%02d:%02d", d.hour, d.minute).toPersianDigits()
                } else ""
                Text("تاریخ: $dateText$timeText")
                if (r.accounts.isNotEmpty()) Text("حساب های ذکرشده: " + r.accounts.joinToString("، "))
                if (r.missing.isNotEmpty()) {
                    Text("اطلاعات ناقص: " + r.missing.joinToString("، ") {
                        if (it == MissingField.AMOUNT) "مبلغ" else "تاریخ"
                    })
                }
                if (r.warnings.isNotEmpty()) Text("هشدارها: " + r.warnings.joinToString(", "))
            }
        }
    }
}
