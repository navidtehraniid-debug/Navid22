package ir.navid.app.core

private const val GROUP_SEPARATOR = '٬'

fun String.toPersianDigits(): String {
    val sb = StringBuilder(length)
    for (c in this) {
        if (c in '0'..'9') sb.append('۰' + (c - '0')) else sb.append(c)
    }
    return sb.toString()
}

fun String.toLatinDigits(): String {
    val sb = StringBuilder(length)
    for (c in this) {
        when (c) {
            in '۰'..'۹' -> sb.append('0' + (c - '۰'))
            in '٠'..'٩' -> sb.append('0' + (c - '٠'))
            else -> sb.append(c)
        }
    }
    return sb.toString()
}

/** مبلغ تومان با جداکننده هزارگان و ارقام فارسی، مثلا «۱٬۵۰۰٬۰۰۰ تومان». */
fun Long.formatToman(): String = formatNumber() + " تومان"

fun Long.formatNumber(): String {
    val negative = this < 0
    val digits = if (negative) (-(this + 1)).toString().let { addOne(it) } else this.toString()
    val grouped = StringBuilder()
    digits.reversed().forEachIndexed { index, c ->
        if (index > 0 && index % 3 == 0) grouped.append(GROUP_SEPARATOR)
        grouped.append(c)
    }
    val result = grouped.reverse().toString().toPersianDigits()
    return if (negative) "−$result" else result
}

// کمکی برای نمایش Long.MIN_VALUE بدون سرریز؛ ورودی رشته رقمی نامنفی است.
private fun addOne(s: String): String = (java.math.BigInteger(s) + java.math.BigInteger.ONE).toString()

/**
 * متن واردشده توسط کاربر را به مبلغ تبدیل می کند.
 * ارقام فارسی و عربی، جداکننده های هزارگان و فاصله پذیرفته می شوند.
 * خروجی null یعنی ورودی نامعتبر، خالی، صفر یا بیش از حد بزرگ.
 */
fun parseAmount(text: String): Long? {
    val latin = text.toLatinDigits()
        .replace(",", "")
        .replace("٬", "")
        .replace("،", "")
        .replace(" ", "")
    if (latin.isEmpty() || latin.length > 15) return null
    if (!latin.all { it in '0'..'9' }) return null
    val value = latin.toLongOrNull() ?: return null
    return if (value > 0) value else null
}
