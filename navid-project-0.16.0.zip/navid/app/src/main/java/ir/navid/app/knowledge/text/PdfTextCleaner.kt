package ir.navid.app.knowledge.text

import java.text.Normalizer

/**
 * پاک سازی متن خام استخراج شده از PDF فارسی (مستقل از ابزار استخراج).
 * یافته ها: اشکال نمایشی عربی، نویسه های جهت، کشیده، شماره چسبیده به متن و ویرگول جابه جا شده در فایل واقعی دیده شد
 * (docs/EXTRACTION_FINDINGS.md).
 */
object PdfTextCleaner {
    private val controls = Regex("[\u202A-\u202E\u200E\u200F\u2066-\u2069\u200D\uFEFF]")
    private val marks = Regex("[\u064B-\u0652\u0640]")
    private val spaces = Regex("[ \t]+")
    private val numberGlued = Regex("^(\\d+(?:-\\d+)*)(?=[\u0600-\u06FF])")
    private val commaBeforeWord = Regex(" \u060C(?=\\S)")

    fun cleanRaw(raw: String): String {
        var t = Normalizer.normalize(raw, Normalizer.Form.NFKC)
        t = controls.replace(t, "")
        t = t.replace('\u200C', ' ')
        t = marks.replace(t, "")
        val sb = StringBuilder(t.length)
        for (ch in t) {
            val mapped = when (ch) {
                '\u064A' -> '\u06CC'
                '\u0643' -> '\u06A9'
                '\u06C0' -> '\u0647'
                '\u0629' -> '\u0647'
                '\u0623', '\u0625' -> '\u0627'
                in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                else -> ch
            }
            sb.append(mapped)
        }
        val lines = sb.toString().split("\n").map { ln ->
            var l = spaces.replace(ln, " ").trim()
            l = numberGlued.replace(l, "\$1 ")
            l = commaBeforeWord.replace(l, "\u060C ")
            l
        }
        return lines.joinToString("\n").trim('\n')
    }

    /** نسبت حروف فارسی و عربی به همه نویسه های غیرفاصله؛ نمره کیفیت ساده متن (0 تا 1). */
    fun qualityScore(text: String): Float {
        var letters = 0
        var all = 0
        for (c in text) {
            if (c.isWhitespace()) continue
            all++
            if (c in '\u0600'..'\u06FF') letters++
        }
        return if (all == 0) 0f else letters.toFloat() / all
    }
}
