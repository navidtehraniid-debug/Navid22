package ir.navid.app.ai.ocr

import android.content.Context
import android.graphics.Bitmap
import java.io.File

interface OcrEngine {
    fun recognize(bitmap: Bitmap): String
    fun close()
}

/** داده زبان فارسی Tesseract: files/tesseract/tessdata/fas.traineddata */
object OcrData {
    const val DOWNLOAD_URL = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/fas.traineddata"

    fun dir(context: Context): File = File(context.filesDir, "tesseract")
    fun file(context: Context): File = File(File(dir(context), "tessdata"), "fas.traineddata")
    fun exists(context: Context): Boolean = file(context).let { it.exists() && it.length() > 300_000 }
}

data class OcrCreation(val engine: OcrEngine?, val error: String?)

/**
 * موتور OCR (Tesseract) فقط در ساخت کامل (-Pocr=true) کامپایل می شود تا کتابخانه ساخت پایدار را خراب نکند؛
 * با بازتاب بارگذاری می شود. در APK پایدار isAvailable برابر false است.
 */
object OcrFactory {
    private const val CLASS_NAME = "ir.navid.app.ai.ocr.TesseractOcr"

    fun isAvailable(): Boolean = try {
        Class.forName(CLASS_NAME)
        true
    } catch (e: Throwable) {
        false
    }

    fun create(context: Context): OcrCreation = try {
        val engine = Class.forName(CLASS_NAME).getConstructor(Context::class.java).newInstance(context.applicationContext) as OcrEngine
        OcrCreation(engine, null)
    } catch (e: ClassNotFoundException) {
        OcrCreation(null, "این APK موتور OCR را ندارد (نسخه NAVID-debug-full.apk).")
    } catch (t: Throwable) {
        val cause = t.cause ?: t
        OcrCreation(null, "راه اندازی OCR شکست خورد: ${cause.javaClass.simpleName}: ${(cause.message ?: "").take(160)}")
    }
}
