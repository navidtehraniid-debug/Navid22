package ir.navid.app.domain

import java.security.MessageDigest

enum class MemoryCategory(val labelFa: String) {
    PERSONAL("شخصی"),
    GOALS("اهداف"),
    BUSINESS("کسب و کار"),
    BUILDING("ساختمان"),
    FINANCE("مالی"),
    WORK_HISTORY("سوابق کاری"),
    CONVERSATIONS("مکالمات"),
    NOTES("یادداشت ها")
}

/** نرمال سازی متن برای تشخیص موارد تکراری حافظه. */
object MemoryText {
    fun normalize(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when (ch) {
                '\u064A' -> sb.append('\u06CC') // ي عربی به ی فارسی
                '\u0643' -> sb.append('\u06A9') // ك عربی به ک فارسی
                in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                '\u200C' -> sb.append(' ')
                else -> sb.append(ch.lowercaseChar())
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    fun hash(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(normalize(text).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
