package ir.navid.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.knowledge.data.KnowledgeDatabase
import ir.navid.app.data.ActiveProjectStore
import ir.navid.app.data.AppDatabase
import ir.navid.app.domain.CurrentPhase
import ir.navid.app.knowledge.data.KnowledgeIndex
import ir.navid.app.knowledge.data.SearchContext
import ir.navid.app.knowledge.data.LibDocumentEntity
import ir.navid.app.knowledge.data.LibPageEntity
import ir.navid.app.knowledge.data.SearchHit
import ir.navid.app.knowledge.ingest.IngestRunner
import ir.navid.app.knowledge.library.ImportResult
import ir.navid.app.knowledge.library.LibraryRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class IngestProgress(val docId: String, val done: Int, val total: Int)

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val kdb = KnowledgeDatabase.get(app)
    private val index = KnowledgeIndex(kdb)
    private val repo = LibraryRepository(app, kdb.libDocumentDao(), index)
    private val runner = IngestRunner(app, kdb, index)

    val query = MutableStateFlow("")
    val group = MutableStateFlow(0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val documents: StateFlow<List<LibDocumentEntity>> =
        combine(query, group) { q, g -> Pair(q, g) }
            .flatMapLatest { pair -> repo.documents(pair.first, pair.second) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deleted: StateFlow<List<LibDocumentEntity>> =
        repo.deleted().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalBytes: StateFlow<Long> =
        repo.totalBytes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val importing = MutableStateFlow(false)
    val messages = MutableStateFlow<List<String>>(emptyList())
    val lastImported = MutableStateFlow<LibDocumentEntity?>(null)

    init {
        viewModelScope.launch { repo.purgeExpired() }
    }

    fun fileOf(doc: LibDocumentEntity): File = repo.fileOf(doc)

    fun fileOfPath(relPath: String): File = repo.fileOfPath(relPath)

    // ---- پردازش متن (یک پردازش در هر زمان)
    val ingest = MutableStateFlow<IngestProgress?>(null)
    private var ingestJob: Job? = null

    fun startIngest(doc: LibDocumentEntity) {
        if (ingestJob?.isActive == true) {
            messages.value = listOf("یک پردازش دیگر در حال اجرا است")
            return
        }
        ingestJob = viewModelScope.launch {
            ingest.value = IngestProgress(doc.id, 0, doc.pageCount ?: 0)
            val error = try {
                runner.run(doc.id) { done, total -> ingest.value = IngestProgress(doc.id, done, total) }
            } finally {
                ingest.value = null
            }
            messages.value = listOf(if (error == null) "پردازش متن پایان یافت: ${doc.title}" else "${doc.title}: $error")
        }
    }

    fun cancelIngest() {
        ingestJob?.cancel()
    }

    // ---- جست وجوی متن کتاب ها
    /** پرسش ارسال شده از دستیار؛ صفحه کتابخانه آن را اجرا می کند. */
    val pendingQuery = MutableStateFlow<String?>(null)

    /** جست وجوی مستقل برای دستیار و چک لیست (بدون دست زدن به نتیجه های صفحه کتابخانه). */
    suspend fun ask(query: String, limit: Int = 5): List<SearchHit> =
        try { index.search(query, limit, searchContext()) } catch (e: Exception) { emptyList() }

    /** زمینه پروژه فعال (آخرین پروژه باز شده): نسخه حاکم و مرحله فعلی. */
    private suspend fun searchContext(): SearchContext {
        val projectId = ActiveProjectStore(getApplication()).get() ?: return SearchContext.NONE
        val db = AppDatabase.get(getApplication())
        val gov = db.projectDocDao().governingDocIds(projectId).toSet()
        val phase = CurrentPhase.of(db.buildingDao().phasesOf(projectId), { it.sortOrder }, { it.status })?.name
        return SearchContext(gov, phase)
    }

    val allDocuments: StateFlow<List<LibDocumentEntity>> =
        repo.documents("", 0).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResults = MutableStateFlow<List<SearchHit>?>(null)
    val searching = MutableStateFlow(false)

    fun runSearch(query: String) {
        viewModelScope.launch {
            searching.value = true
            searchResults.value = try {
                index.search(query, 20, searchContext())
            } catch (e: Exception) {
                emptyList()
            }
            searching.value = false
        }
    }

    suspend fun pageText(docId: String, pageNo: Int): LibPageEntity? = repo.pageText(docId, pageNo)

    /** ورود چند فایل به ترتیب. اگر دقیقاً یک فایل موفق شد، فرم مشخصات برای تکمیل باز می شود. */
    fun importAll(uris: List<Uri>) {
        viewModelScope.launch {
            importing.value = true
            val msgs = ArrayList<String>()
            var okCount = 0
            var lastOk: LibDocumentEntity? = null
            for (u in uris) {
                when (val r = repo.importUri(u)) {
                    is ImportResult.Ok -> {
                        okCount++
                        lastOk = r.doc
                        msgs.add("افزوده شد: " + r.doc.title)
                    }
                    is ImportResult.Error -> msgs.add(r.fileName + ": " + r.message)
                }
            }
            messages.value = msgs
            lastImported.value = if (okCount == 1) lastOk else null
            importing.value = false
        }
    }

    fun consumeLastImported() {
        lastImported.value = null
    }

    fun clearMessages() {
        messages.value = emptyList()
    }

    fun update(doc: LibDocumentEntity, onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(repo.update(doc)) }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }

    fun restore(id: String) {
        viewModelScope.launch { repo.restore(id) }
    }

    fun deletePermanently(id: String) {
        viewModelScope.launch { repo.deletePermanently(id) }
    }
}
