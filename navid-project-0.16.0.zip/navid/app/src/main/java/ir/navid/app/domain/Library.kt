package ir.navid.app.domain

enum class DocType(val labelFa: String) {
    REGULATION("مقررات"),
    STANDARD("استاندارد"),
    SPEC("مشخصات فنی"),
    BOOK("کتاب"),
    ARTICLE("مقاله"),
    DRAWING("نقشه"),
    PROJECT_DOC("مدرک پروژه"),
    OTHER("سایر")
}

enum class DocStatus(val labelFa: String) {
    CURRENT("نسخه حاضر"),
    SUPERSEDED("منسوخ"),
    DRAFT("پیش نویس"),
    UNKNOWN("نامشخص")
}

enum class DocOrigin { UPLOAD, WEB }

/** وضعیت پردازش متن سند؛ در مرحله 1 فقط NOT_PROCESSED است و مراحل بعد اضافه می شوند. */
enum class IngestStatus { NOT_PROCESSED, PROCESSING, DONE, FAILED }

object SourceGroups {
    val labels: Map<Int, String> = mapOf(
        1 to "قوانین، مقررات و استانداردهای رسمی",
        2 to "مشخصات فنی، نشریات و دستورالعمل های رسمی",
        3 to "کتاب ها و منابع دانشگاهی",
        4 to "آموزش ها و تجربیات تکمیلی"
    )
    const val DEFAULT = 3
}

data class NameGuess(val title: String, val year: Int?)

object LibraryNaming {
    val supportedExtensions = setOf("pdf", "jpg", "jpeg", "png", "doc", "docx", "xls", "xlsx", "txt")

    fun extensionOf(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        if (dot < 0 || dot == fileName.length - 1) return ""
        val ext = fileName.substring(dot + 1).lowercase()
        return if (ext.length in 1..5 && ext.all { it in 'a'..'z' || it in '0'..'9' }) ext else ""
    }

    fun mimeFor(ext: String): String = when (ext) {
        "pdf" -> "application/pdf"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "txt" -> "text/plain"
        else -> "application/octet-stream"
    }

    private val jalaliYear = Regex("(?<!\\d)(13|14)\\d{2}(?!\\d)")
    private val gregorianYear = Regex("(?<!\\d)(19|20)\\d{2}(?!\\d)")

    /** حدس عنوان و سال از نام فایل؛ فقط پیشنهاد است و کاربر ویرایش می کند. */
    fun guess(fileName: String): NameGuess {
        val dot = fileName.lastIndexOf('.')
        val base = if (dot > 0) fileName.substring(0, dot) else fileName
        val title = base.replace('_', ' ').replace(Regex("\\s+"), " ").trim().ifEmpty { "سند بدون عنوان" }
        val year = (jalaliYear.find(base) ?: gregorianYear.find(base))?.value?.toInt()
        return NameGuess(title, year)
    }
}

object StoragePolicy {
    /** سقف پیش فرض کتابخانه: 6 گیگابایت. */
    const val DEFAULT_CAP_BYTES: Long = 6L * 1024 * 1024 * 1024

    /** حداقل فضای خالی که بعد از ورود فایل باید در گوشی بماند: 300 مگابایت. */
    const val MIN_FREE_BYTES: Long = 300L * 1024 * 1024

    fun allows(usedBytes: Long, incomingBytes: Long, capBytes: Long = DEFAULT_CAP_BYTES): Boolean =
        incomingBytes >= 0 && usedBytes >= 0 && usedBytes + incomingBytes <= capBytes

    fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f گیگابایت", bytes / (1024.0 * 1024 * 1024))
        bytes >= 1024L * 1024 -> String.format(java.util.Locale.US, "%.1f مگابایت", bytes / (1024.0 * 1024))
        bytes >= 1024L -> String.format(java.util.Locale.US, "%d کیلوبایت", bytes / 1024)
        else -> "$bytes بایت"
    }
}

object PageRefs {
    /** شماره صفحه چاپی از فاصله ثابت تشخیص داده شده؛ اگر نامعتبر یا ناشناخته باشد null. */
    fun printed(filePage: Int, offset: Int?): Int? = if (offset == null) null else (filePage - offset).takeIf { it > 0 }

    /** مثلاً «صفحه چاپی 7 (صفحه 20 فایل)» یا اگر شماره چاپی ناشناخته بود «صفحه 20 فایل». */
    fun format(pageFrom: Int, pageTo: Int, offset: Int?): String {
        val pf = printed(pageFrom, offset)
        val pt = printed(pageTo, offset)
        val file = if (pageTo > pageFrom) "$pageFrom تا $pageTo" else "$pageFrom"
        val text = if (pf != null && pt != null) {
            val p = if (pageTo > pageFrom) "$pf تا $pt" else "$pf"
            "صفحه چاپی $p (صفحه $file فایل)"
        } else {
            "صفحه $file فایل"
        }
        return text.replace(Regex("\\d")) { ('\u06F0' + (it.value[0] - '0')).toString() }
    }
}

/** سیاست ارسال گزیده های یک سند به سرویس بیرونی: پیش فرض فقط منابع رسمی (گروه 1 و 2)؛ کتاب ها پیش فرض ممنوع اند. */
object ExternalPolicy {
    fun allowed(externalOk: Boolean?, sourceGroup: Int): Boolean = externalOk ?: (sourceGroup in 1..2)
}
