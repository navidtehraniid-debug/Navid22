package ir.navid.app.ai.nlu

/**
 * تحلیل گر ساده JSON برای خروجی مدل: فقط یک شیء تخت با مقدار رشته، عدد، true/false یا null.
 * متن اطراف (توضیح یا ```json) نادیده گرفته می شود: فقط از اولین { تا آخرین } خوانده می شود.
 * هر خروجی نامعتبر null برمی گرداند. مقدار عددی بدون نقطه و توان Long است، در غیر این صورت Double.
 */
object MiniJson {
    fun parseObject(text: String): Map<String, Any?>? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return try {
            Parser(text.substring(start, end + 1)).parseTopObject()
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    private class Parser(private val s: String) {
        private var i = 0

        private fun fail(): Nothing = throw IllegalArgumentException("invalid json")
        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        private fun skipWs() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        private fun expect(c: Char) {
            if (peek() != c) fail()
            i++
        }

        fun parseTopObject(): Map<String, Any?> {
            val result = LinkedHashMap<String, Any?>()
            skipWs()
            expect('{')
            skipWs()
            if (peek() == '}') {
                i++
            } else {
                while (true) {
                    skipWs()
                    val key = parseString()
                    skipWs()
                    expect(':')
                    skipWs()
                    result[key] = parseValue()
                    skipWs()
                    if (peek() == ',') {
                        i++
                        continue
                    }
                    expect('}')
                    break
                }
            }
            skipWs()
            if (i != s.length) fail()
            return result
        }

        private fun parseValue(): Any? {
            val c = peek()
            return when {
                c == '"' -> parseString()
                c == 'n' -> literal("null", null)
                c == 't' -> literal("true", true)
                c == 'f' -> literal("false", false)
                c == '-' || c.isDigit() -> parseNumber()
                else -> fail()
            }
        }

        private fun literal(word: String, value: Any?): Any? {
            if (!s.startsWith(word, i)) fail()
            i += word.length
            return value
        }

        private fun parseNumber(): Any {
            val start = i
            if (peek() == '-') i++
            if (!peek().isDigit()) fail()
            while (peek().isDigit()) i++
            var isDouble = false
            if (peek() == '.') {
                isDouble = true
                i++
                if (!peek().isDigit()) fail()
                while (peek().isDigit()) i++
            }
            if (peek() == 'e' || peek() == 'E') {
                isDouble = true
                i++
                if (peek() == '+' || peek() == '-') i++
                if (!peek().isDigit()) fail()
                while (peek().isDigit()) i++
            }
            val raw = s.substring(start, i)
            return if (isDouble) raw.toDouble() else raw.toLong()
        }

        private fun parseString(): String {
            expect('"')
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) fail()
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (i >= s.length) fail()
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) fail()
                                sb.append(s.substring(i, i + 4).toInt(16).toChar())
                                i += 4
                            }
                            else -> fail()
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }
    }
}
