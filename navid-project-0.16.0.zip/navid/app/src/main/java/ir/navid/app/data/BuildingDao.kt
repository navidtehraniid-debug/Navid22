package ir.navid.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
abstract class BuildingDao {

    @Query("SELECT * FROM projects WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    abstract fun observeProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    abstract suspend fun projectById(id: String): ProjectEntity?

    @Insert
    abstract suspend fun insertProject(project: ProjectEntity)

    @Insert
    abstract suspend fun insertPhases(phases: List<PhaseEntity>)

    @Transaction
    open suspend fun insertProjectWithPhases(project: ProjectEntity, phases: List<PhaseEntity>) {
        insertProject(project)
        insertPhases(phases)
    }

    @Query("UPDATE projects SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    abstract suspend fun softDeleteProject(id: String, at: Long)

    @Query("SELECT * FROM phases ORDER BY projectId, sortOrder")
    abstract fun observePhases(): Flow<List<PhaseEntity>>

    @Query("SELECT * FROM phases WHERE projectId = :id ORDER BY sortOrder")
    abstract suspend fun phasesOf(id: String): List<PhaseEntity>

    @Query("SELECT * FROM phases WHERE id = :id LIMIT 1")
    abstract suspend fun phaseById(id: String): PhaseEntity?

    @Update
    abstract suspend fun updatePhase(phase: PhaseEntity)

    @Query("SELECT * FROM site_reports WHERE deletedAt IS NULL ORDER BY reportDate DESC, createdAt DESC")
    abstract fun observeReports(): Flow<List<SiteReportEntity>>

    @Insert
    abstract suspend fun insertReport(report: SiteReportEntity)

    @Query("UPDATE site_reports SET deletedAt = :at WHERE id = :id")
    abstract suspend fun softDeleteReport(id: String, at: Long)
}
