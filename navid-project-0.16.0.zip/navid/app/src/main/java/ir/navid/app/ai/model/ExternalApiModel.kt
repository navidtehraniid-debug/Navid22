package ir.navid.app.ai.model

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

enum class ApiFormat(val labelFa: String) {
    ANTHROPIC("Anthropic (Claude)"),
    OPENAI("سازگار با OpenAI")
}

data class ExternalConfig(val format: ApiFormat, val baseUrl: String, val model: String, val apiKey: String)

/** ساخت درخواست و خواندن پاسخ؛ بخش خالص و قابل آزمون (بدون شبکه). */
object ExternalApiProtocol {
    fun endpoint(c: ExternalConfig): String {
        val base = c.baseUrl.trim().trimEnd('/')
        return when (c.format) {
            ApiFormat.ANTHROPIC -> "$base/v1/messages"
            ApiFormat.OPENAI -> if (base.endsWith("/v1")) "$base/chat/completions" else "$base/v1/chat/completions"
        }
    }

    fun headers(c: ExternalConfig): Map<String, String> = when (c.format) {
        ApiFormat.ANTHROPIC -> mapOf("x-api-key" to c.apiKey, "anthropic-version" to "2023-06-01", "content-type" to "application/json")
        ApiFormat.OPENAI ->
            if (c.apiKey.isBlank()) mapOf("content-type" to "application/json")
            else mapOf("Authorization" to "Bearer ${c.apiKey}", "content-type" to "application/json")
    }

    fun jsonString(s: String): String {
        val sb = StringBuilder("\"")
        for (ch in s) {
            when {
                ch == '"' -> sb.append("\\\"")
                ch == '\\' -> sb.append("\\\\")
                ch == '\n' -> sb.append("\\n")
                ch == '\r' -> sb.append("\\r")
                ch == '\t' -> sb.append("\\t")
                ch < ' ' -> sb.append(String.format("\\u%04x", ch.code))
                else -> sb.append(ch)
            }
        }
        return sb.append('"').toString()
    }

    fun requestBody(c: ExternalConfig, r: ModelRequest): String = when (c.format) {
        ApiFormat.ANTHROPIC ->
            "{\"model\":${jsonString(c.model)},\"max_tokens\":${r.maxTokens},\"temperature\":${r.temperature}," +
                "\"system\":${jsonString(r.system)},\"messages\":[{\"role\":\"user\",\"content\":${jsonString(r.user)}}]}"
        ApiFormat.OPENAI ->
            "{\"model\":${jsonString(c.model)},\"max_tokens\":${r.maxTokens},\"temperature\":${r.temperature}," +
                "\"messages\":[{\"role\":\"system\",\"content\":${jsonString(r.system)}},{\"role\":\"user\",\"content\":${jsonString(r.user)}}]}"
    }

    /** اولین مقدار رشته ای یک کلید در متن JSON (با برگرداندن escape ها)؛ برای خواندن پاسخ بدون وابستگی. */
    fun firstString(body: String, key: String): String? {
        var from = 0
        val needle = "\"$key\""
        while (true) {
            val k = body.indexOf(needle, from)
            if (k < 0) return null
            var i = k + needle.length
            while (i < body.length && body[i].isWhitespace()) i++
            if (i < body.length && body[i] == ':') {
                i++
                while (i < body.length && body[i].isWhitespace()) i++
                if (i < body.length && body[i] == '"') return readString(body, i + 1)
            }
            from = k + needle.length
        }
    }

    private fun readString(s: String, start: Int): String {
        val sb = StringBuilder()
        var i = start
        while (i < s.length) {
            val c = s[i]
            if (c == '"') break
            if (c == '\\' && i + 1 < s.length) {
                i++
                when (val e = s[i]) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    'r' -> sb.append('\r')
                    'b' -> sb.append('\b')
                    'f' -> sb.append('\u000C')
                    'u' -> {
                        if (i + 4 < s.length) {
                            sb.append(s.substring(i + 1, i + 5).toInt(16).toChar())
                            i += 4
                        }
                    }
                    else -> sb.append(e)
                }
            } else {
                sb.append(c)
            }
            i++
        }
        return sb.toString()
    }

    fun parseResponse(format: ApiFormat, body: String): String? = when (format) {
        ApiFormat.ANTHROPIC -> firstString(body, "text")
        ApiFormat.OPENAI -> firstString(body, "content")
    }
}

class ExternalApiModel(private val config: ExternalConfig) : LanguageModel {
    override val name: String get() = "${config.format.labelFa} • ${config.model}"

    override suspend fun generate(request: ModelRequest): ModelResult = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        try {
            val conn = URL(ExternalApiProtocol.endpoint(config)).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            ExternalApiProtocol.headers(config).forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(ExternalApiProtocol.requestBody(config, request).toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            conn.disconnect()
            if (code !in 200..299) {
                val detail = ExternalApiProtocol.firstString(text, "message")?.take(200) ?: ""
                return@withContext ModelResult.Error("خطای سرویس (کد $code) $detail".trim())
            }
            val answer = ExternalApiProtocol.parseResponse(config.format, text)
                ?: return@withContext ModelResult.Error("پاسخ سرویس قابل خواندن نبود")
            ModelResult.Ok(answer, System.currentTimeMillis() - started)
        } catch (e: Exception) {
            ModelResult.Error("اتصال ناموفق: " + (e.message ?: e.javaClass.simpleName).take(160))
        }
    }
}
