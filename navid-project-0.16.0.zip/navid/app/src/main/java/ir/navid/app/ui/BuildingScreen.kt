package ir.navid.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import ir.navid.app.domain.CurrentPhase
import ir.navid.app.data.ActiveProjectStore
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.formatToman
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.PhaseEntity
import ir.navid.app.data.ProjectEntity
import ir.navid.app.data.SiteReportEntity
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.domain.PhaseStatus
import java.time.LocalDate

private fun isoToJalali(iso: String?): String =
    if (iso == null) "-" else try {
        JalaliDate.from(LocalDate.parse(iso)).format().toPersianDigits()
    } catch (e: Exception) {
        iso
    }

@Composable
fun BuildingScreen(
    vm: BuildingViewModel,
    finVm: FinanceViewModel,
    checklistVm: ChecklistViewModel,
    onAddExpense: (String) -> Unit,
    onTxClick: (TransactionWithLines) -> Unit,
    modifier: Modifier = Modifier
) {
    val projects by vm.projects.collectAsState()
    val summaries by vm.summaries.collectAsState()
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    val project = projects.firstOrNull { it.id == selectedId }

    BackHandler(enabled = project != null) { selectedId = null }

    if (project == null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("ساختمان", style = MaterialTheme.typography.headlineSmall)
            if (projects.isEmpty()) {
                Text("هنوز پروژه ای نساخته اید. با «پروژه جدید» شروع کنید؛ ۱۴ مرحله ساخت از تخریب تا پایان کار خودکار ساخته می شود.")
            }
            projects.forEach { p ->
                val s = summaries[p.id]
                SectionCard(p.name) {
                    if (s != null) {
                        Text("پیشرفت: ${s.progress}٪".toPersianDigits())
                        Text("هزینه تا امروز: ${s.cost.formatToman()}")
                        if (p.initialBudget > 0) Text("بودجه: ${p.initialBudget.formatToman()}")
                    }
                    OutlinedButton(onClick = { selectedId = p.id }, modifier = Modifier.fillMaxWidth()) { Text("باز کردن") }
                }
            }
            Button(onClick = { showCreate = true }, modifier = Modifier.fillMaxWidth()) { Text("پروژه جدید") }
        }
    } else {
        ProjectDetail(project, summaries[project.id], vm, finVm, checklistVm, onAddExpense, onTxClick, { selectedId = null }, modifier)
    }

    if (showCreate) {
        ProjectCreateDialog(vm) { showCreate = false }
    }
}

@Composable
private fun ProjectDetail(
    project: ProjectEntity,
    summary: ProjectSummary?,
    vm: BuildingViewModel,
    finVm: FinanceViewModel,
    checklistVm: ChecklistViewModel,
    onAddExpense: (String) -> Unit,
    onTxClick: (TransactionWithLines) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier
) {
    val allPhases by vm.phases.collectAsState()
    val allReports by vm.reports.collectAsState()
    val recent by finVm.recent.collectAsState()
    val accounts by finVm.accounts.collectAsState()
    val names = accounts.associate { it.id to it.name }
    val phases = allPhases.filter { it.projectId == project.id }
    val reports = allReports.filter { it.projectId == project.id }
    val currentPhase = CurrentPhase.of(phases, { it.sortOrder }, { it.status })?.name
    val appContext = LocalContext.current
    LaunchedEffect(project.id) { ActiveProjectStore(appContext).set(project.id) }
    val payments = recent.filter { it.tx.projectId == project.id }
    var editPhase by remember { mutableStateOf<PhaseEntity?>(null) }
    var showReport by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack) { Text("بازگشت به پروژه ها") }
        Text(project.name, style = MaterialTheme.typography.headlineSmall)
        if (project.address.isNotBlank()) Text(project.address, style = MaterialTheme.typography.bodyMedium)
        val facts = listOfNotNull(
            project.landArea?.let { "زمین ${it} متر" },
            project.builtArea?.let { "زیربنا ${it} متر" },
            project.floors?.let { "$it طبقه" },
            project.structureType.takeIf { it.isNotBlank() }
        )
        if (facts.isNotEmpty()) Text(facts.joinToString("  •  ").toPersianDigits(), style = MaterialTheme.typography.bodySmall)

        if (summary != null) {
            SectionCard("وضعیت") {
                Text("پیشرفت کل (میانگین مراحل): ${summary.progress}٪".toPersianDigits())
                if (project.initialBudget > 0) LabeledAmount("بودجه اولیه", project.initialBudget)
                LabeledAmount("هزینه واقعی تا امروز", summary.cost)
                if (project.initialBudget > 0) {
                    LabeledAmount("بودجه باقی مانده", summary.remaining)
                    summary.usedPercent?.let { Text("مصرف بودجه: ${it}٪".toPersianDigits()) }
                    if (summary.remaining < 0) {
                        Text("هشدار: هزینه از بودجه گذشته است.", color = MaterialTheme.colorScheme.error)
                    }
                } else {
                    Text("بودجه تعریف نشده است.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Button(onClick = { onAddExpense(project.id) }, modifier = Modifier.fillMaxWidth()) { Text("ثبت هزینه برای این پروژه") }

        SectionCard("مراحل ساخت") {
            phases.forEach { ph ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ph.name, style = MaterialTheme.typography.bodyMedium)
                        val dates = if (ph.actualStart != null) {
                            "  از ${isoToJalali(ph.actualStart)}" + if (ph.actualEnd != null) " تا ${isoToJalali(ph.actualEnd)}" else ""
                        } else ""
                        Text(
                            "${ph.status.labelFa} • ${ph.progressPct}٪$dates".toPersianDigits(),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    TextButton(onClick = { editPhase = ph }) { Text("ویرایش") }
                }
            }
            Text("وابستگی بین مراحل و تاریخ برنامه ای هنوز ساخته نشده است.", style = MaterialTheme.typography.bodySmall)
        }

        ProjectDocsSection(project.id, currentPhase)

        ChecklistSection(project.id, checklistVm, currentPhase)

        SectionCard("عکس های پروژه (قبل و بعد)") {
            PhotoStrip(project.id, "PROJECT", project.id)
        }

        SectionCard("گزارش های کارگاه") {
            if (reports.isEmpty()) Text("هنوز گزارشی ثبت نشده است.")
            reports.take(30).forEach { r -> ReportRow(r, phases, vm) }
            Button(onClick = { showReport = true }, modifier = Modifier.fillMaxWidth()) { Text("گزارش جدید") }
        }

        SectionCard("پرداخت های اخیر این پروژه") {
            if (payments.isEmpty()) Text("هزینه ای به این پروژه متصل نشده است.")
            payments.take(10).forEach { TransactionRow(it, names, onClick = { onTxClick(it) }) }
        }

        TextButton(onClick = { confirmDelete = true }) {
            Text("حذف پروژه", color = MaterialTheme.colorScheme.error)
        }
    }

    editPhase?.let { PhaseDialog(it, vm) { editPhase = null } }
    if (showReport) ReportDialog(project, phases, vm) { showReport = false }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف پروژه؟") },
            text = { Text("پروژه از فهرست حذف می شود. هزینه های ثبت شده برای آن در دفتر مالی می مانند.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteProject(project.id)
                    confirmDelete = false
                    onBack()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun ReportRow(r: SiteReportEntity, phases: List<PhaseEntity>, vm: BuildingViewModel) {
    val phaseName = phases.firstOrNull { it.id == r.phaseId }?.name
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(r.text, style = MaterialTheme.typography.bodyMedium)
        Text(
            isoToJalali(r.reportDate) + (if (phaseName != null) "  •  $phaseName" else ""),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
        TextButton(onClick = { vm.deleteReport(r.id) }) { Text("حذف گزارش") }
    }
}

@Composable
private fun PhaseDialog(phase: PhaseEntity, vm: BuildingViewModel, onDismiss: () -> Unit) {
    var status by remember { mutableStateOf(phase.status) }
    var progress by remember { mutableStateOf(if (phase.status == PhaseStatus.IN_PROGRESS) phase.progressPct.toString() else "50") }
    var notes by remember { mutableStateOf(phase.notes) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(phase.name) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PhaseStatus.values().forEach { s -> AccountChoice(s.labelFa, status == s) { status = s; error = null } }
                if (status == PhaseStatus.IN_PROGRESS) {
                    OutlinedTextField(
                        value = progress,
                        onValueChange = { progress = it; error = null },
                        label = { Text("درصد پیشرفت (1 تا 99)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("یادداشت مرحله (اختیاری)") },
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.updatePhase(phase.id, status, progress, notes) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun ReportDialog(project: ProjectEntity, phases: List<PhaseEntity>, vm: BuildingViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var dateText by remember { mutableStateOf(JalaliDate.today().format()) }
    var phaseId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("گزارش کارگاه: ${project.name}") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; error = null },
                    label = { Text("متن گزارش") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it; error = null },
                    label = { Text("تاریخ شمسی") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("مرحله (اختیاری)", style = MaterialTheme.typography.labelLarge)
                AccountChoice("بدون مرحله", phaseId == null) { phaseId = null }
                phases.forEach { ph -> AccountChoice(ph.name, phaseId == ph.id) { phaseId = ph.id } }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.addReport(project.id, phaseId, dateText, text) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("ثبت") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun ProjectCreateDialog(vm: BuildingViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var land by remember { mutableStateOf("") }
    var built by remember { mutableStateOf("") }
    var floors by remember { mutableStateOf("") }
    var structure by remember { mutableStateOf("") }
    var budget by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پروژه جدید") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it; error = null }, label = { Text("نام پروژه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("آدرس (اختیاری)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = land, onValueChange = { land = it; error = null }, label = { Text("متراژ زمین (متر مربع، اختیاری)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = built, onValueChange = { built = it; error = null }, label = { Text("زیربنا (متر مربع، اختیاری)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = floors, onValueChange = { floors = it; error = null }, label = { Text("تعداد طبقات (اختیاری)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = structure, onValueChange = { structure = it }, label = { Text("نوع سازه (اختیاری)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = budget, onValueChange = { budget = it; error = null }, label = { Text("بودجه اولیه (تومان، اختیاری)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.createProject(name, address, land, built, floors, structure, budget) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("ساخت پروژه") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
