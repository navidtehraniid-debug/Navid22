package ir.navid.app.knowledge.library

import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.provider.OpenableColumns
import ir.navid.app.domain.DocOrigin
import ir.navid.app.domain.DocStatus
import ir.navid.app.domain.DocType
import ir.navid.app.domain.IngestStatus
import ir.navid.app.domain.LibraryNaming
import ir.navid.app.domain.SourceGroups
import ir.navid.app.domain.StoragePolicy
import ir.navid.app.domain.Trash
import ir.navid.app.knowledge.data.LibDocumentDao
import ir.navid.app.knowledge.data.KnowledgeIndex
import ir.navid.app.knowledge.data.LibDocumentEntity
import ir.navid.app.knowledge.data.LibPageEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

sealed interface ImportResult {
    data class Ok(val doc: LibDocumentEntity) : ImportResult
    data class Error(val fileName: String, val message: String) : ImportResult
}

class LibraryRepository(
    context: Context,
    private val dao: LibDocumentDao,
    private val index: KnowledgeIndex
) {

    private val appContext = context.applicationContext

    fun documents(query: String, group: Int): Flow<List<LibDocumentEntity>> = dao.observe(query.trim(), group)
    fun deleted(): Flow<List<LibDocumentEntity>> = dao.observeDeleted()
    fun totalBytes(): Flow<Long> = dao.observeTotalBytes()

    fun fileOf(doc: LibDocumentEntity): File = File(appContext.filesDir, doc.relPath)

    fun fileOfPath(relPath: String): File = File(appContext.filesDir, relPath)

    suspend fun pageText(docId: String, pageNo: Int): LibPageEntity? = dao.page(docId, pageNo)

    /** کپی استریمی فایل انتخاب شده به پوشه خصوصی برنامه، با محاسبه sha256 هم زمان، و ثبت سند. */
    suspend fun importUri(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            doImport(uri)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ImportResult.Error("فایل", ("خطا در ورود فایل: " + (e.message ?: e.javaClass.simpleName)).take(160))
        }
    }

    private suspend fun doImport(uri: Uri): ImportResult {
        val resolver = appContext.contentResolver
        var name = "document"
        var size = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        val ext = LibraryNaming.extensionOf(name)
        if (ext !in LibraryNaming.supportedExtensions) {
            return ImportResult.Error(name, "فرمت این فایل پشتیبانی نمی شود (فرمت های مجاز: PDF، عکس، Word، Excel، متن)")
        }
        val used = dao.totalBytesNow()
        if (size >= 0 && !StoragePolicy.allows(used, size)) {
            return ImportResult.Error(name, "سقف فضای کتابخانه (${StoragePolicy.formatSize(StoragePolicy.DEFAULT_CAP_BYTES)}) پر می شود")
        }
        val free = StatFs(appContext.filesDir.path).availableBytes
        if (size >= 0 && free < size + StoragePolicy.MIN_FREE_BYTES) {
            return ImportResult.Error(name, "فضای خالی گوشی کافی نیست")
        }

        val id = UUID.randomUUID().toString()
        val dir = File(appContext.filesDir, "library/$id")
        dir.mkdirs()
        val target = File(dir, "original.$ext")
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        try {
            val input = resolver.openInputStream(uri) ?: run {
                dir.deleteRecursively()
                return ImportResult.Error(name, "فایل خوانده نشد")
            }
            input.use { ins ->
                FileOutputStream(target).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buffer)
                        if (n < 0) break
                        digest.update(buffer, 0, n)
                        out.write(buffer, 0, n)
                        total += n
                    }
                }
            }
            if (!StoragePolicy.allows(used, total)) {
                dir.deleteRecursively()
                return ImportResult.Error(name, "سقف فضای کتابخانه پر می شود")
            }
            val hash = digest.digest().joinToString("") { "%02x".format(it) }
            val existing = dao.findByHashAny(hash)
            if (existing != null) {
                dir.deleteRecursively()
                val where = if (existing.deletedAt != null) "در سطل بازیافت است" else "قبلاً در کتابخانه هست"
                return ImportResult.Error(name, "این فایل $where: «${existing.title}»")
            }

            var pages: Int? = null
            if (ext == "pdf") {
                var pfd: ParcelFileDescriptor? = null
                var renderer: PdfRenderer? = null
                try {
                    pfd = ParcelFileDescriptor.open(target, ParcelFileDescriptor.MODE_READ_ONLY)
                    renderer = PdfRenderer(pfd)
                    pages = renderer.pageCount
                } catch (e: SecurityException) {
                    dir.deleteRecursively()
                    return ImportResult.Error(name, "این PDF رمزدار است و باز نمی شود")
                } catch (e: IOException) {
                    dir.deleteRecursively()
                    return ImportResult.Error(name, "فایل PDF معتبر نیست یا خراب است")
                } finally {
                    renderer?.close()
                    pfd?.close()
                }
            }

            val guess = LibraryNaming.guess(name)
            val now = System.currentTimeMillis()
            val doc = LibDocumentEntity(
                id = id,
                title = guess.title,
                publisher = "",
                authors = "",
                year = guess.year,
                edition = "",
                docType = if (ext == "pdf" || ext == "doc" || ext == "docx") DocType.BOOK else DocType.OTHER,
                sourceGroup = SourceGroups.DEFAULT,
                topic = "",
                phaseKeys = "",
                status = DocStatus.UNKNOWN,
                statusNote = "",
                origin = DocOrigin.UPLOAD,
                originUrl = "",
                fileName = name,
                relPath = "library/$id/original.$ext",
                mime = LibraryNaming.mimeFor(ext),
                sha256 = hash,
                sizeBytes = total,
                pageCount = pages,
                ingestStatus = IngestStatus.NOT_PROCESSED,
                userNotes = "",
                projectId = null,
                uploadedAt = now,
                updatedAt = now
            )
            dao.insert(doc)
            return ImportResult.Ok(doc)
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
    }

    /** ذخیره ویرایش مشخصات؛ null یعنی موفق. */
    suspend fun update(doc: LibDocumentEntity): String? {
        if (doc.title.isBlank()) return "عنوان سند را وارد کنید"
        if (doc.year != null && doc.year !in 1200..2100) return "سال انتشار نامعتبر است"
        if (doc.sourceGroup !in 1..4) return "گروه منبع نامعتبر است"
        dao.update(doc.copy(title = doc.title.trim(), updatedAt = System.currentTimeMillis()))
        return null
    }

    suspend fun delete(id: String) = dao.softDelete(id, System.currentTimeMillis())
    suspend fun restore(id: String) = dao.restore(id, System.currentTimeMillis())

    suspend fun deletePermanently(id: String) = withContext(Dispatchers.IO) {
        val doc = dao.byId(id)
        if (doc != null) File(appContext.filesDir, "library/${doc.id}").deleteRecursively()
        index.clear(id)
        dao.hardDelete(id)
    }

    /** اسناد داخل سطل بازیافت که بیش از 30 روز گذشته اند برای همیشه پاک می شوند. */
    suspend fun purgeExpired() {
        val old = dao.expired(Trash.purgeCutoff(System.currentTimeMillis()))
        old.forEach { deletePermanently(it.id) }
    }
}
