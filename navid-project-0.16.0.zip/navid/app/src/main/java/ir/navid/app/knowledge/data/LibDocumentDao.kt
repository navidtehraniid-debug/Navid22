package ir.navid.app.knowledge.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LibDocumentDao {

    @Query(
        "SELECT * FROM lib_documents WHERE deletedAt IS NULL " +
            "AND (:group = 0 OR sourceGroup = :group) " +
            "AND (:q = '' OR title LIKE '%' || :q || '%' OR publisher LIKE '%' || :q || '%' " +
            "OR authors LIKE '%' || :q || '%' OR topic LIKE '%' || :q || '%') " +
            "ORDER BY uploadedAt DESC"
    )
    fun observe(q: String, group: Int): Flow<List<LibDocumentEntity>>

    @Query("SELECT * FROM lib_documents WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    fun observeDeleted(): Flow<List<LibDocumentEntity>>

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM lib_documents")
    fun observeTotalBytes(): Flow<Long>

    @Query("SELECT COALESCE(SUM(sizeBytes), 0) FROM lib_documents")
    suspend fun totalBytesNow(): Long

    @Query("SELECT * FROM lib_documents WHERE sha256 = :hash LIMIT 1")
    suspend fun findByHashAny(hash: String): LibDocumentEntity?

    @Query("SELECT * FROM lib_documents WHERE id = :id LIMIT 1")
    suspend fun byId(id: String): LibDocumentEntity?

    @Query("SELECT * FROM lib_documents WHERE deletedAt IS NOT NULL AND deletedAt < :before")
    suspend fun expired(before: Long): List<LibDocumentEntity>

    @Insert
    suspend fun insert(doc: LibDocumentEntity)

    @Update
    suspend fun update(doc: LibDocumentEntity)

    @Query("UPDATE lib_documents SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    suspend fun softDelete(id: String, at: Long)

    @Query("UPDATE lib_documents SET deletedAt = NULL, updatedAt = :at WHERE id = :id")
    suspend fun restore(id: String, at: Long)

    @Query("DELETE FROM lib_documents WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Insert
    suspend fun insertPages(pages: List<LibPageEntity>)

    @Insert
    suspend fun insertChunks(chunks: List<LibChunkEntity>): List<Long>

    @Query("DELETE FROM lib_pages WHERE docId = :docId")
    suspend fun deletePages(docId: String)

    @Query("DELETE FROM lib_chunks WHERE docId = :docId")
    suspend fun deleteChunks(docId: String)

    @Query("SELECT * FROM lib_pages WHERE docId = :docId AND pageNo = :pageNo LIMIT 1")
    suspend fun page(docId: String, pageNo: Int): LibPageEntity?
}
