package ir.navid.app.core

import java.time.ZoneId
import java.time.ZonedDateTime

/** زمان یادآوری همیشه به وقت تهران (UTC+3:30 بدون ساعت تابستانی) محاسبه می شود. */
object ReminderTime {
    val zone: ZoneId = ZoneId.of("Asia/Tehran")

    fun dueAtMillis(date: JalaliDate, hour: Int, minute: Int): Long {
        val g = date.toLocalDate()
        return ZonedDateTime.of(g.year, g.monthValue, g.dayOfMonth, hour, minute, 0, 0, zone)
            .toInstant().toEpochMilli()
    }
}
