package ir.navid.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.navid.app.core.toLatinDigits
import ir.navid.app.core.toPersianDigits
import ir.navid.app.domain.DocStatus
import ir.navid.app.domain.IngestStatus
import ir.navid.app.domain.PageRefs
import ir.navid.app.domain.DocType
import ir.navid.app.domain.LibraryNaming
import ir.navid.app.domain.SourceGroups
import ir.navid.app.domain.StoragePolicy
import ir.navid.app.domain.Trash
import ir.navid.app.knowledge.data.LibDocumentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class ViewTarget(
    val title: String,
    val file: File,
    val page: Int,
    val printedOffset: Int? = null,
    val bandTop: Float? = null,
    val bandBottom: Float? = null,
    val caption: String? = null
)

private val pickerTypes = arrayOf(
    "application/pdf",
    "image/*",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "text/plain"
)

@Composable
fun LibraryScreen(vm: LibraryViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val docs by vm.documents.collectAsState()
    val query by vm.query.collectAsState()
    val group by vm.group.collectAsState()
    val total by vm.totalBytes.collectAsState()
    val importing by vm.importing.collectAsState()
    val messages by vm.messages.collectAsState()
    val last by vm.lastImported.collectAsState()
    val ingest by vm.ingest.collectAsState()
    val results by vm.searchResults.collectAsState()
    val searching by vm.searching.collectAsState()
    var searchText by remember { mutableStateOf("") }
    var diag by remember { mutableStateOf<LibDocumentEntity?>(null) }
    val pending by vm.pendingQuery.collectAsState()
    LaunchedEffect(pending) {
        val q = pending
        if (q != null) {
            searchText = q
            vm.runSearch(q)
            vm.pendingQuery.value = null
        }
    }

    var viewing by remember { mutableStateOf<ViewTarget?>(null) }
    var editing by remember { mutableStateOf<LibDocumentEntity?>(null) }
    var showTrash by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importAll(uris)
    }

    LaunchedEffect(last) {
        if (last != null) {
            editing = last
            vm.consumeLastImported()
        }
    }

    BackHandler(enabled = viewing != null) { viewing = null }

    val viewed = viewing
    if (viewed != null) {
        DocumentViewer(viewed, { viewing = null }, modifier)
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onBack) { Text("بازگشت") }
                TextButton(onClick = { showTrash = true }) { Text("سطل بازیافت") }
            }
            Text("کتابخانه منابع", style = MaterialTheme.typography.headlineSmall)
            Text(
                "فضای مصرفی: ${StoragePolicy.formatSize(total)} از ${StoragePolicy.formatSize(StoragePolicy.DEFAULT_CAP_BYTES)}".toPersianDigits(),
                style = MaterialTheme.typography.bodySmall
            )
            SectionCard("جست وجو در متن کتاب ها") {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    label = { Text("مثلاً: دامنه کاربرد، یا شماره بند 4-1-5-1") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { vm.runSearch(searchText) },
                    enabled = searchText.isNotBlank() && !searching,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (searching) "در حال جست وجو..." else "جست وجو") }
                val res = results
                if (res != null && res.isEmpty()) {
                    Text("نتیجه ای پیدا نشد. اگر کتاب را تازه اضافه کرده اید، اول «استخراج متن» را بزنید.", style = MaterialTheme.typography.bodySmall)
                }
                res?.forEach { h ->
                    Divider()
                    Text(h.title, style = MaterialTheme.typography.titleSmall)
                    val meta = listOfNotNull(
                        h.publisher.takeIf { it.isNotBlank() },
                        h.year?.toString(),
                        "گروه ${h.sourceGroup}",
                        h.status.labelFa
                    ).joinToString("  •  ")
                    Text(meta.toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                    val where = listOfNotNull(
                        h.clause.takeIf { it.isNotEmpty() }?.let { "بند $it" },
                        h.chapter.takeIf { it.isNotEmpty() }
                    ).joinToString("  •  ")
                    if (where.isNotEmpty()) Text(where.toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                    if (h.heading.isNotEmpty()) Text(h.heading.toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                    Text(PageRefs.format(h.pageFrom, h.pageTo, h.printedOffset), style = MaterialTheme.typography.bodySmall)
                    val badges = listOfNotNull(if (h.governing) "نسخه حاکم پروژه" else null, if (h.phaseMatch) "مرتبط با مرحله فعلی" else null)
                    if (badges.isNotEmpty()) Text(badges.joinToString("  •  "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(h.snippet, style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = {
                        val caption = "نتیجه جست وجو: " + listOfNotNull(
                            h.clause.takeIf { it.isNotEmpty() }?.let { "بند $it" },
                            PageRefs.format(h.pageFrom, h.pageTo, h.printedOffset)
                        ).joinToString("  •  ")
                        viewing = ViewTarget(h.title, vm.fileOfPath(h.relPath), h.pageFrom - 1, h.printedOffset, h.hlTop, h.hlBottom, caption)
                    }) {
                        Text("باز کردن همین صفحه")
                    }
                }
            }
            Button(
                onClick = { picker.launch(pickerTypes) },
                enabled = !importing,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (importing) "در حال ورود فایل ها..." else "افزودن فایل (PDF، عکس، Word، Excel)") }

            messages.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            if (messages.isNotEmpty()) TextButton(onClick = { vm.clearMessages() }) { Text("پاک کردن پیام ها") }

            OutlinedTextField(
                value = query,
                onValueChange = { vm.query.value = it },
                label = { Text("جست وجو در عنوان، ناشر، نویسنده و موضوع") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("این کادر فقط فهرست اسناد را فیلتر می کند؛ جست وجو در متن کتاب ها در کادر بالاتر است.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterButton("همه", group == 0) { vm.group.value = 0 }
                (1..4).forEach { g -> FilterButton("گروه $g".toPersianDigits(), group == g) { vm.group.value = g } }
            }

            if (docs.isEmpty()) {
                Text("هنوز سندی در کتابخانه نیست. با دکمه بالا اولین کتاب یا مبحث را اضافه کنید.")
            }
            docs.forEach { d ->
                SectionCard(d.title) {
                    val meta = listOfNotNull(
                        d.publisher.takeIf { it.isNotBlank() },
                        d.year?.toString(),
                        d.edition.takeIf { it.isNotBlank() }
                    ).joinToString("  •  ")
                    if (meta.isNotEmpty()) Text(meta.toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                    Text(
                        "${d.docType.labelFa}  •  گروه ${d.sourceGroup}  •  ${d.status.labelFa}".toPersianDigits(),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        (StoragePolicy.formatSize(d.sizeBytes) + (d.pageCount?.let { "  •  $it صفحه" } ?: "")).toPersianDigits(),
                        style = MaterialTheme.typography.bodySmall
                    )
                    val progress = ingest
                    if (LibraryNaming.extensionOf(d.fileName) == "pdf") {
                        val statusText = when {
                            progress != null && progress.docId == d.id -> "در حال استخراج متن: صفحه ${progress.done} از ${progress.total}"
                            d.ingestStatus == IngestStatus.DONE && d.ingestInfo?.contains("موقعیت حروف") != true ->
                                "متن با روش قدیمی استخراج شده؛ «پردازش مجدد» ترتیب کلمه ها و محل نتیجه را درست می کند"
                            d.ingestStatus == IngestStatus.DONE -> "متن استخراج شده: ${d.chunkCount ?: 0} تکه قابل جست وجو"
                            d.ingestStatus == IngestStatus.FAILED -> "پردازش ناموفق: " + (d.ingestInfo ?: "").take(120)
                            d.ingestStatus == IngestStatus.PROCESSING -> "در حال پردازش یا ناتمام مانده است"
                            else -> "متن هنوز استخراج نشده است"
                        }
                        Text(statusText.toPersianDigits(), style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (progress != null && progress.docId == d.id) {
                                OutlinedButton(onClick = { vm.cancelIngest() }) { Text("توقف") }
                            } else {
                                Button(onClick = { vm.startIngest(d) }, enabled = progress == null) {
                                    Text(if (d.ingestStatus == IngestStatus.DONE) "پردازش مجدد" else "استخراج متن")
                                }
                            }
                            if (d.ingestInfo != null) TextButton(onClick = { diag = d }) { Text("آمار پردازش") }
                        }
                    } else {
                        Text("استخراج متن برای این فرمت هنوز ساخته نشده است.", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(onClick = { viewing = ViewTarget(d.title, vm.fileOf(d), 0) }) { Text("باز کردن") }
                        TextButton(onClick = { editing = d }) { Text("مشخصات") }
                        TextButton(onClick = { vm.delete(d.id) }) { Text("حذف") }
                    }
                }
            }
        }
    }

    editing?.let { d -> DocumentEditDialog(d, vm) { editing = null } }
    diag?.let { d -> DiagnosticsDialog(d, vm) { diag = null } }
    if (showTrash) LibraryTrashDialog(vm) { showTrash = false }
}

@Composable
private fun FilterButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(label) } else OutlinedButton(onClick = onClick) { Text(label) }
}

@Composable
private fun DocumentEditDialog(doc: LibDocumentEntity, vm: LibraryViewModel, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf(doc.title) }
    var publisher by remember { mutableStateOf(doc.publisher) }
    var authors by remember { mutableStateOf(doc.authors) }
    var yearText by remember { mutableStateOf(doc.year?.toString() ?: "") }
    var edition by remember { mutableStateOf(doc.edition) }
    var type by remember { mutableStateOf(doc.docType) }
    var group by remember { mutableStateOf(doc.sourceGroup) }
    var status by remember { mutableStateOf(doc.status) }
    var topic by remember { mutableStateOf(doc.topic) }
    var notes by remember { mutableStateOf(doc.userNotes) }
    var ext by remember { mutableStateOf(doc.externalOk) }
    var phaseKeys by remember { mutableStateOf(doc.phaseKeys) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مشخصات سند") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("مقادیر حدسی از نام فایل گرفته شده اند؛ لطفاً تصحیح کنید.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = title, onValueChange = { title = it; error = null }, label = { Text("عنوان") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = publisher, onValueChange = { publisher = it }, label = { Text("ناشر") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = authors, onValueChange = { authors = it }, label = { Text("نویسنده یا تهیه کننده") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = yearText,
                    onValueChange = { yearText = it; error = null },
                    label = { Text("سال انتشار (مثلاً 1396)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(value = edition, onValueChange = { edition = it }, label = { Text("شماره ویرایش یا نسخه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("نوع سند", style = MaterialTheme.typography.labelLarge)
                DocType.values().forEach { t -> AccountChoice(t.labelFa, type == t) { type = t } }
                Text("گروه منبع", style = MaterialTheme.typography.labelLarge)
                SourceGroups.labels.forEach { (g, label) -> AccountChoice("${g.toString().toPersianDigits()}. $label", group == g) { group = g } }
                Text("وضعیت اعتبار", style = MaterialTheme.typography.labelLarge)
                DocStatus.values().forEach { s -> AccountChoice(s.labelFa, status == s) { status = s } }
                OutlinedTextField(value = phaseKeys, onValueChange = { phaseKeys = it }, label = { Text("مراحل مرتبط (با ویرگول، مثل: فونداسیون، اسکلت)") }, modifier = Modifier.fillMaxWidth())
                Text("ارسال گزیده های این سند به سرویس بیرونی هوش مصنوعی", style = MaterialTheme.typography.labelLarge)
                AccountChoice("پیش فرض (منابع رسمی گروه 1 و 2 مجاز، کتاب ها ممنوع)", ext == null) { ext = null }
                AccountChoice("همیشه مجاز", ext == true) { ext = true }
                AccountChoice("هرگز ارسال نشود", ext == false) { ext = false }
                OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("موضوع") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("توضیحات شما") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val clean = yearText.toLatinDigits().trim()
                val year = if (clean.isEmpty()) null else clean.toIntOrNull()
                if (clean.isNotEmpty() && year == null) {
                    error = "سال انتشار نامعتبر است"
                } else {
                    vm.update(
                        doc.copy(
                            title = title,
                            publisher = publisher.trim(),
                            authors = authors.trim(),
                            year = year,
                            edition = edition.trim(),
                            docType = type,
                            sourceGroup = group,
                            status = status,
                            topic = topic.trim(),
                            userNotes = notes.trim(),
                            externalOk = ext,
                            phaseKeys = phaseKeys.trim()
                        )
                    ) { result -> if (result == null) onDismiss() else error = result }
                }
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun LibraryTrashDialog(vm: LibraryViewModel, onDismiss: () -> Unit) {
    val deleted by vm.deleted.collectAsState()
    var confirmId by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سطل بازیافت کتابخانه") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "اسناد بعد از ${Trash.RETENTION_DAYS.toString().toPersianDigits()} روز همراه فایل شان برای همیشه پاک می شوند.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (deleted.isEmpty()) Text("سطل بازیافت خالی است.")
                deleted.forEach { d ->
                    Text(d.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.restore(d.id) }) { Text("بازیابی") }
                        TextButton(onClick = { confirmId = d.id }) { Text("حذف دائمی") }
                    }
                    Divider()
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
    confirmId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmId = null },
            title = { Text("حذف دائمی؟") },
            text = { Text("فایل و مشخصات سند برای همیشه پاک می شود و قابل بازگشت نیست.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePermanently(id)
                    confirmId = null
                }) { Text("حذف دائمی") }
            },
            dismissButton = { TextButton(onClick = { confirmId = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun DocumentViewer(target: ViewTarget, onBack: () -> Unit, modifier: Modifier) {
    Column(modifier = modifier.fillMaxSize().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("بازگشت") }
            Text(target.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
        }
        when (LibraryNaming.extensionOf(target.file.name)) {
            "pdf" -> PdfPages(target.file, target)
            "jpg", "jpeg", "png" -> ImagePage(target.file)
            else -> Text(
                "نمایش داخلی این فرمت هنوز ساخته نشده است؛ فایل در کتابخانه نگهداری می شود.",
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

/** نگهدارنده PdfRenderer؛ رندر و بستن با قفل هم زمان نمی شوند تا فرو ریختن برنامه پیش نیاید. */
private class PdfHolder private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer
) {
    @Volatile private var closed = false
    val pageCount: Int get() = renderer.pageCount

    fun render(index: Int, widthPx: Int): Bitmap? = synchronized(this) {
        if (closed || index !in 0 until renderer.pageCount) return null
        val page = renderer.openPage(index)
        try {
            val h = (widthPx * page.height.toFloat() / page.width.toFloat()).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AndroidColor.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() {
        synchronized(this) {
            if (!closed) {
                closed = true
                try {
                    renderer.close()
                } catch (e: Exception) {
                    // نادیده گرفته می شود
                }
                try {
                    pfd.close()
                } catch (e: Exception) {
                    // نادیده گرفته می شود
                }
            }
        }
    }

    companion object {
        fun open(file: File): PdfHolder? = try {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                PdfHolder(pfd, PdfRenderer(pfd))
            } catch (e: Exception) {
                pfd.close()
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}

private val zoomSteps = listOf(1f, 1.5f, 2f, 3f)

@Composable
private fun ColumnScope.PdfPages(file: File, target: ViewTarget) {
    val holder = remember(file.path) { PdfHolder.open(file) }
    DisposableEffect(file.path) { onDispose { holder?.close() } }
    if (holder == null) {
        Text("این PDF باز نشد.", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        return
    }
    val pageCount = holder.pageCount
    var pageIndex by remember(target) { mutableStateOf(target.page.coerceIn(0, maxOf(0, pageCount - 1))) }
    var zoom by remember(target) { mutableStateOf(1f) }
    var showBand by remember(target) { mutableStateOf(true) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var jump by remember { mutableStateOf("") }
    var jumpPrinted by remember { mutableStateOf(false) }
    var viewportW by remember { mutableStateOf(0) }
    var viewportH by remember { mutableStateOf(0) }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()

    LaunchedEffect(pageIndex, zoom) {
        error = null
        val width = (1100 * zoom).toInt().coerceIn(800, 2600)
        try {
            bitmap = withContext(Dispatchers.Default) { holder.render(pageIndex, width) }
        } catch (e: Exception) {
            error = "نمایش این صفحه ممکن نشد"
        }
    }

    val top = target.bandTop
    val bottom = target.bandBottom
    val hasBand = top != null && bottom != null && bottom > top
    val band: Pair<Float, Float>? =
        if (showBand && hasBand && pageIndex == target.page && top != null && bottom != null) Pair(top, bottom) else null
    val bmp = bitmap

    // بعد از آماده شدن تصویر، به محل نتیجه اسکرول می شود (یا بالای صفحه)
    LaunchedEffect(bmp, band, zoom, viewportW, viewportH) {
        if (bmp == null || viewportW == 0) return@LaunchedEffect
        val imageHeight = viewportW * zoom * bmp.height / bmp.width
        val y = if (band != null) (band.first * imageHeight - viewportH * 0.15f).toInt().coerceAtLeast(0) else 0
        vScroll.scrollTo(y)
        if (zoom == 1f) hScroll.scrollTo(0)
    }

    target.caption?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(enabled = pageIndex > 0, onClick = { pageIndex-- }) { Text("صفحه قبل") }
        val printed = PageRefs.printed(pageIndex + 1, target.printedOffset)
        Text(
            ("صفحه ${pageIndex + 1} از $pageCount" + (printed?.let { "  (چاپی $it)" } ?: "")).toPersianDigits(),
            style = MaterialTheme.typography.bodyMedium
        )
        TextButton(enabled = pageIndex < pageCount - 1, onClick = { pageIndex++ }) { Text("صفحه بعد") }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(enabled = zoom > zoomSteps.first(), onClick = { zoom = zoomSteps.last { it < zoom } }) { Text("−") }
        Text("${(zoom * 100).toInt()}٪".toPersianDigits(), style = MaterialTheme.typography.bodyMedium)
        TextButton(enabled = zoom < zoomSteps.last(), onClick = { zoom = zoomSteps.first { it > zoom } }) { Text("+") }
        if (hasBand) {
            TextButton(onClick = { showBand = !showBand }) { Text(if (showBand) "پنهان کردن ناحیه" else "نمایش ناحیه نتیجه") }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = jump,
            onValueChange = { jump = it },
            label = { Text(if (jumpPrinted) "برو به صفحه چاپی" else "برو به صفحه فایل") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f)
        )
        if (target.printedOffset != null) {
            TextButton(onClick = { jumpPrinted = !jumpPrinted }) { Text(if (jumpPrinted) "چاپی" else "فایل") }
        }
        Button(onClick = {
            val n = jump.toLatinDigits().trim().toIntOrNull()
            if (n != null) {
                val filePage = if (jumpPrinted && target.printedOffset != null) n + target.printedOffset else n
                if (filePage in 1..pageCount) pageIndex = filePage - 1
            }
        }) { Text("برو") }
    }
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .clipToBounds()
            .onSizeChanged {
                viewportW = it.width
                viewportH = it.height
            }
    ) {
        if (bmp != null && viewportW > 0) {
            val pageWidth = with(LocalDensity.current) { (viewportW * zoom).toDp() }
            Box(modifier = Modifier.fillMaxSize().verticalScroll(vScroll).horizontalScroll(hScroll)) {
                Box(modifier = Modifier.width(pageWidth)) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (band != null) {
                        Canvas(modifier = Modifier.matchParentSize()) {
                            drawRect(
                                color = Color(0x66FFC107),
                                topLeft = Offset(0f, size.height * band.first),
                                size = Size(size.width, size.height * (band.second - band.first))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.ImagePage(file: File) {
    var bitmap by remember(file.path) { mutableStateOf<Bitmap?>(null) }
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(file.path) {
        bitmap = withContext(Dispatchers.IO) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.path, opts)
        }
    }
    val bmp = bitmap
    if (bmp == null) {
        Text("در حال بارگذاری تصویر...", modifier = Modifier.padding(16.dp))
    } else {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.FillWidth,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clipToBounds()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        offset = if (scale <= 1f) Offset.Zero else offset + pan
                    }
                }
                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
        )
    }
}

@Composable
private fun DiagnosticsDialog(doc: LibDocumentEntity, vm: LibraryViewModel, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var pageInput by remember { mutableStateOf("20") }
    var pageText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("آمار پردازش متن") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(doc.ingestInfo ?: "هنوز پردازش نشده است.", style = MaterialTheme.typography.bodyMedium)
                Divider()
                Text("بررسی متن استخراج شده یک صفحه (برای مقایسه با خود فایل):", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = pageInput,
                    onValueChange = { pageInput = it },
                    label = { Text("شماره صفحه فایل") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    val n = pageInput.toLatinDigits().trim().toIntOrNull()
                    if (n != null) {
                        scope.launch {
                            val p = vm.pageText(doc.id, n)
                            pageText = if (p == null) {
                                "صفحه ای با این شماره ذخیره نشده است."
                            } else {
                                ("صفحه چاپی: " + (p.printedPage?.toString() ?: "نامشخص") +
                                    "  •  کیفیت متن: ${(p.quality * 100).toInt()}٪\n\n" + p.text.take(1500)).toPersianDigits()
                            }
                        }
                    }
                }) { Text("نمایش متن این صفحه") }
                if (pageText.isNotEmpty()) Text(pageText, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}
