package ir.navid.app.core

/** تبدیل متن ساعت واردشده کاربر به (ساعت، دقیقه): «10»، «10:30»، «۱۰:۳۰». نامعتبر یعنی null. */
object TimeText {
    private val pattern = Regex("^(\\d{1,2})(?::(\\d{2}))?$")

    fun parse(text: String): Pair<Int, Int>? {
        val m = pattern.matchEntire(text.toLatinDigits().trim()) ?: return null
        val h = m.groupValues[1].toInt()
        val min = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        if (h !in 0..23 || min !in 0..59) return null
        return Pair(h, min)
    }

    fun format(hour: Int, minute: Int): String = String.format(java.util.Locale.US, "%02d:%02d", hour, minute)
}
