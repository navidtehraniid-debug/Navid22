package ir.navid.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.MemoryEntity
import ir.navid.app.data.MemoryRepository
import ir.navid.app.domain.MemoryCategory
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MemoryViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = MemoryRepository(AppDatabase.get(app).memoryDao())

    val query = MutableStateFlow("")
    val category = MutableStateFlow<MemoryCategory?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val items: StateFlow<List<MemoryEntity>> =
        combine(query, category) { q, c -> Pair(q, c) }
            .flatMapLatest { pair -> repo.search(pair.first, pair.second) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deleted: StateFlow<List<MemoryEntity>> =
        repo.deleted().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch { repo.purgeExpired() }
    }

    fun save(
        editId: String?,
        category: MemoryCategory,
        title: String,
        content: String,
        onResult: (String?) -> Unit
    ) {
        viewModelScope.launch { onResult(repo.save(editId, category, title, content)) }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }

    fun restore(id: String) {
        viewModelScope.launch { repo.restore(id) }
    }

    fun deletePermanently(id: String) {
        viewModelScope.launch { repo.deletePermanently(id) }
    }
}
