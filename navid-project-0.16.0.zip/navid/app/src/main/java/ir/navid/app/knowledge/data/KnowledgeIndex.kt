package ir.navid.app.knowledge.data

import androidx.room.withTransaction
import androidx.sqlite.db.SupportSQLiteDatabase
import ir.navid.app.domain.DocStatus
import ir.navid.app.domain.ExternalPolicy
import ir.navid.app.domain.PhaseMatch
import ir.navid.app.knowledge.text.RankInput
import ir.navid.app.knowledge.text.Ranking
import ir.navid.app.knowledge.text.SearchText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** زمینه پروژه برای اولویت دهی: سند های نسخه حاکم و نام مرحله فعلی. */
data class SearchContext(val governingDocIds: Set<String>, val phaseName: String?) {
    companion object {
        val NONE = SearchContext(emptySet(), null)
    }
}

data class SearchHit(
    val chunkId: Long,
    val docId: String,
    val title: String,
    val publisher: String,
    val year: Int?,
    val edition: String,
    val sourceGroup: Int,
    val status: DocStatus,
    val relPath: String,
    val chapter: String,
    val clause: String,
    val heading: String,
    val pageFrom: Int,
    val pageTo: Int,
    val printedOffset: Int?,
    val snippet: String,
    /** متن کامل تکه؛ برای ساخت منبع پرسش از مدل. */
    val text: String,
    val hlTop: Float?,
    val hlBottom: Float?,
    /** آیا گزیده این سند اجازه ارسال به سرویس بیرونی دارد (قفل سند یا پیش فرض گروه منبع). */
    val externalAllowed: Boolean,
    /** سند نسخه حاکم پروژه فعال است. */
    val governing: Boolean,
    /** مراحل مرتبط سند با مرحله فعلی پروژه می خواند. */
    val phaseMatch: Boolean,
    val score: Double
)

/** ایندکس متنی FTS4 و جست وجو. FTS5 در اندروید در دسترس نیست؛ نامزدها با FTS4 می آیند و رتبه بندی با BM25 در Kotlin است. */
class KnowledgeIndex(private val db: KnowledgeDatabase) {

    private val dao = db.libDocumentDao()

    private class Row(
        val id: Long,
        val docId: String,
        val pageFrom: Int,
        val pageTo: Int,
        val chapter: String,
        val clause: String,
        val heading: String,
        val text: String,
        val title: String,
        val publisher: String,
        val year: Int?,
        val edition: String,
        val sourceGroup: Int,
        val status: DocStatus,
        val relPath: String,
        val printedOffset: Int?,
        val frontMatter: Boolean,
        val hlTop: Float?,
        val hlBottom: Float?,
        val externalOk: Boolean?,
        val phaseKeys: String
    )

    suspend fun replaceContent(
        docId: String,
        pages: List<LibPageEntity>,
        chunks: List<LibChunkEntity>,
        indexTexts: List<String>
    ) {
        db.withTransaction {
            clearInternal(docId)
            dao.insertPages(pages)
            val ids = dao.insertChunks(chunks)
            val sdb = db.openHelper.writableDatabase
            ids.forEachIndexed { i, id ->
                sdb.execSQL("INSERT INTO lib_chunks_fts(docid, text_search) VALUES (?, ?)", arrayOf<Any?>(id, indexTexts[i]))
            }
        }
    }

    suspend fun clear(docId: String) {
        db.withTransaction { clearInternal(docId) }
    }

    private suspend fun clearInternal(docId: String) {
        val sdb = db.openHelper.writableDatabase
        sdb.execSQL(
            "DELETE FROM lib_chunks_fts WHERE docid IN (SELECT id FROM lib_chunks WHERE docId = ?)",
            arrayOf<Any?>(docId)
        )
        dao.deleteChunks(docId)
        dao.deletePages(docId)
    }

    private fun rows(sdb: SupportSQLiteDatabase, cond: String, args: Array<Any>, limit: Int): List<Row> {
        val sql = "SELECT c.id, c.docId, c.pageFrom, c.pageTo, c.chapter, c.clause, c.heading, c.text, " +
            "d.title, d.publisher, d.year, d.edition, d.sourceGroup, d.status, d.relPath, d.printedOffset, " +
            "CASE WHEN c.chapter = '' AND EXISTS (SELECT 1 FROM lib_chunks x WHERE x.docId = c.docId AND x.chapter <> '') " +
            "THEN 1 ELSE 0 END, c.hlTop, c.hlBottom, d.externalOk, d.phaseKeys " +
            "FROM lib_chunks c JOIN lib_documents d ON d.id = c.docId " +
            "WHERE d.deletedAt IS NULL AND ($cond) " +
            "ORDER BY CASE WHEN c.chapter = '' THEN 1 ELSE 0 END, c.id LIMIT $limit"
        val out = ArrayList<Row>()
        sdb.query(sql, args).use { c ->
            while (c.moveToNext()) {
                val status = try {
                    DocStatus.valueOf(c.getString(13))
                } catch (e: IllegalArgumentException) {
                    DocStatus.UNKNOWN
                }
                out.add(
                    Row(
                        id = c.getLong(0),
                        docId = c.getString(1),
                        pageFrom = c.getInt(2),
                        pageTo = c.getInt(3),
                        chapter = c.getString(4),
                        clause = c.getString(5),
                        heading = c.getString(6),
                        text = c.getString(7),
                        title = c.getString(8),
                        publisher = c.getString(9),
                        year = if (c.isNull(10)) null else c.getInt(10),
                        edition = c.getString(11),
                        sourceGroup = c.getInt(12),
                        status = status,
                        relPath = c.getString(14),
                        printedOffset = if (c.isNull(15)) null else c.getInt(15),
                        frontMatter = c.getInt(16) == 1,
                        hlTop = if (c.isNull(17)) null else c.getFloat(17),
                        hlBottom = if (c.isNull(18)) null else c.getFloat(18),
                        externalOk = if (c.isNull(19)) null else c.getInt(19) == 1,
                        phaseKeys = c.getString(20) ?: ""
                    )
                )
            }
        }
        return out
    }

    private fun corpusStats(sdb: SupportSQLiteDatabase): Pair<Int, Double> {
        sdb.query(
            "SELECT COUNT(*), COALESCE(AVG(c.tokenCount), 1.0) FROM lib_chunks c " +
                "JOIN lib_documents d ON d.id = c.docId WHERE d.deletedAt IS NULL"
        ).use { c ->
            return if (c.moveToFirst()) Pair(c.getInt(0), c.getDouble(1)) else Pair(0, 1.0)
        }
    }

    private fun matchCount(sdb: SupportSQLiteDatabase, expr: String): Int {
        sdb.query("SELECT COUNT(*) FROM lib_chunks_fts WHERE lib_chunks_fts MATCH ?", arrayOf<Any>(expr)).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    private fun toHit(r: Row, tokens: List<String>, score: Double, ctx: SearchContext) = SearchHit(
        chunkId = r.id,
        docId = r.docId,
        title = r.title,
        publisher = r.publisher,
        year = r.year,
        edition = r.edition,
        sourceGroup = r.sourceGroup,
        status = r.status,
        relPath = r.relPath,
        chapter = r.chapter,
        clause = r.clause,
        heading = r.heading,
        pageFrom = r.pageFrom,
        pageTo = r.pageTo,
        printedOffset = r.printedOffset,
        snippet = Ranking.snippet(r.text, tokens),
        text = r.text,
        hlTop = r.hlTop,
        hlBottom = r.hlBottom,
        externalAllowed = ExternalPolicy.allowed(r.externalOk, r.sourceGroup),
        governing = r.docId in ctx.governingDocIds,
        phaseMatch = PhaseMatch.matches(r.phaseKeys, ctx.phaseName),
        score = score
    )

    suspend fun search(query: String, limit: Int = 20, ctx: SearchContext = SearchContext.NONE): List<SearchHit> = withContext(Dispatchers.IO) {
        val parsed = SearchText.parse(query)
        val sdb = db.openHelper.readableDatabase
        val ordered = LinkedHashMap<Long, SearchHit>()

        // شماره بند: ترتیب اصلی، سپس ترتیب برعکس (کپی از نمایش دیداری)، سپس بندهای ناقص
        val clause = parsed.clause
        if (clause != null) {
            val variants = listOfNotNull(clause, parsed.clauseAlt)
            val exactFound = HashSet<String>()
            variants.forEachIndexed { index, cl ->
                for (r in rows(sdb, "c.clause = ?", arrayOf(cl), 20).sortedByDescending { it.docId in ctx.governingDocIds }) {
                    exactFound.add(cl)
                    if (r.id !in ordered) ordered[r.id] = toHit(r, parsed.tokens, if (index == 0) 99.0 else 90.0, ctx)
                }
            }
            variants.forEachIndexed { index, cl ->
                if (index == 0 || cl in exactFound) {
                    for (r in rows(sdb, "c.clause LIKE ?", arrayOf("$cl-%"), 10)) {
                        if (r.id !in ordered) ordered[r.id] = toHit(r, parsed.tokens, if (index == 0) 50.0 else 45.0, ctx)
                    }
                }
            }
            if (exactFound.isEmpty()) {
                for (r in rows(sdb, "c.clause LIKE ?", arrayOf("%-$clause"), 10)) {
                    if (r.id !in ordered) ordered[r.id] = toHit(r, parsed.tokens, 40.0, ctx)
                }
            }
        }

        val andExpr = parsed.andExpr
        val orExpr = parsed.orExpr
        if (andExpr != null && orExpr != null) {
            val matchCond = "c.id IN (SELECT docid FROM lib_chunks_fts WHERE lib_chunks_fts MATCH ?)"
            var candidates = rows(sdb, matchCond, arrayOf(andExpr), 200)
            if (candidates.size < 20) candidates = rows(sdb, matchCond, arrayOf(orExpr), 500)
            if (candidates.isNotEmpty()) {
                val (n, avg) = corpusStats(sdb)
                val df = parsed.tokens.toSet().associateWith { t -> matchCount(sdb, "$t*") }
                val scored = candidates.map { r ->
                    val tokens = SearchText.tokens(r.text + " " + r.heading + " " + r.chapter)
                    val input = RankInput(tokens, r.clause.isNotEmpty(), r.frontMatter, r.sourceGroup, r.status)
                    var score = Ranking.bm25(parsed.tokens, input, n, avg, df)
                    if (r.docId in ctx.governingDocIds) score *= 1.5
                    if (PhaseMatch.matches(r.phaseKeys, ctx.phaseName)) score *= 1.3
                    Pair(r, score)
                }.sortedByDescending { it.second }
                for ((r, s) in scored) {
                    if (ordered.size >= limit) break
                    if (r.id !in ordered) ordered[r.id] = toHit(r, parsed.tokens, s, ctx)
                }
            }
        }
        ordered.values.take(limit)
    }
}
