package ir.navid.app.ai.rag

import ir.navid.app.ai.model.ModelRequest
import ir.navid.app.domain.PageRefs
import ir.navid.app.knowledge.data.SearchHit
import ir.navid.app.knowledge.text.PdfTextCleaner

data class RagSource(val id: String, val reference: String, val text: String)

/** ساخت درخواست مدل از روی گزیده های کتابخانه. مدل فقط از همین منابع حق پاسخ دارد. */
object RagPrompt {
    const val NO_ANSWER = "در منابع موجود پاسخی پیدا نشد."

    val system: String = listOf(
        "تو دستیار فنی ساختمان به نام NAVID هستی. فقط و فقط از «منابع» داده شده پاسخ بده.",
        "قواعد:",
        "1. هر جمله پاسخ باید در پایان شناسه منبع مثل [S1] داشته باشد (اگر از چند منبع است مثل [S1][S2]).",
        "2. هیچ عدد، ابعاد، مقدار، شماره بند یا نقل قولی که در منابع نیامده ننویس.",
        "3. اگر منابع پاسخ را ندارند فقط همین جمله را بنویس: $NO_ANSWER",
        "4. اگر منابع با هم تعارض دارند، تعارض را صریح بگو و هر دو را با شناسه بیاور؛ خودت انتخاب نکن.",
        "5. پاسخ کوتاه، فارسی ساده، با فاصله معمولی (بدون نیم فاصله) و حداکثر 6 جمله باشد.",
        "6. تصمیم فنی نهایی با مهندس مسئول است؛ دستور اجرایی خاص پروژه نده."
    ).joinToString("\n")

    fun sourcesFrom(hits: List<SearchHit>, maxPerSource: Int = 1200, maxTotal: Int = 6000): List<RagSource> {
        val out = ArrayList<RagSource>()
        var total = 0
        for (h in hits) {
            val ref = listOfNotNull(
                h.title,
                h.clause.takeIf { it.isNotEmpty() }?.let { "بند $it" },
                PageRefs.format(h.pageFrom, h.pageTo, h.printedOffset)
            ).joinToString(" • ")
            val text = h.text.take(maxPerSource)
            if (total + text.length > maxTotal && out.isNotEmpty()) break
            out.add(RagSource("S${out.size + 1}", ref, text))
            total += text.length
        }
        return out
    }

    fun build(question: String, sources: List<RagSource>): ModelRequest {
        val user = buildString {
            append("پرسش: ").append(question.trim()).append("\n\nمنابع:\n")
            for (s in sources) append("[").append(s.id).append("] ").append(s.reference).append("\n").append(s.text).append("\n\n")
        }
        return ModelRequest(system = system, user = user.trim(), maxTokens = 600, temperature = 0.0)
    }
}

data class AnswerSentence(val text: String, val citations: List<String>, val supported: Boolean, val problem: String?)

data class ValidatedAnswer(val sentences: List<AnswerSentence>, val noAnswer: Boolean, val usedSourceIds: List<String>) {
    val hasProblems: Boolean get() = sentences.any { !it.supported }
}

/**
 * اعتبارسنج پاسخ مدل (کد تصمیم می گیرد، نه مدل): هر جمله باید ارجاع معتبر داشته باشد و هر عدد جمله باید عیناً
 * در منبع ارجاع شده باشد. جمله های ناموفق «تأیید نشده در منابع» علامت می خورند و پنهان نمی شوند.
 */
object AnswerValidator {
    private val cite = Regex("\\[S(\\d+)\\]")
    private val number = Regex("\\d+(?:[./]\\d+)?")
    private val listMarker = Regex("(?m)^\\s*\\d{1,2}\\s*[-.)]\\s+")
    private val splitter = Regex("(?<=[.!?\u061F])\\s+|\\n+")

    private fun numbersOf(text: String): Set<String> =
        number.findAll(text).map { it.value.replace('/', '.') }.toSet()

    fun validate(answer: String, sources: List<RagSource>): ValidatedAnswer {
        val byId = sources.associateBy { it.id }
        val sourceNumbers = sources.associate { it.id to numbersOf(PdfTextCleaner.cleanRaw(it.text)) }
        val cleaned = listMarker.replace(PdfTextCleaner.cleanRaw(answer), "")
        val sentences = ArrayList<AnswerSentence>()
        val used = LinkedHashSet<String>()
        for (raw in splitter.split(cleaned)) {
            val s = raw.trim()
            if (s.isEmpty()) continue
            val ids = cite.findAll(s).map { "S" + it.groupValues[1] }.distinct().toList()
            val body = cite.replace(s, "").trim()
            if (body.contains("پاسخی پیدا نشد")) {
                sentences.add(AnswerSentence(body, emptyList(), true, null))
                continue
            }
            var problem: String? = null
            if (ids.isEmpty()) problem = "بدون ارجاع به منبع"
            else if (ids.any { it !in byId }) problem = "ارجاع نامعتبر"
            else {
                val allowed = ids.flatMap { sourceNumbers[it] ?: emptySet() }.toSet()
                val missing = numbersOf(body).filter { it !in allowed }
                if (missing.isNotEmpty()) problem = "عدد بدون پشتوانه در منبع: " + missing.joinToString("، ")
            }
            if (problem == null) used.addAll(ids)
            sentences.add(AnswerSentence(body, ids, problem == null, problem))
        }
        val noAnswer = sentences.isEmpty() || sentences.all { it.citations.isEmpty() && it.supported }
        return ValidatedAnswer(sentences, noAnswer, used.toList())
    }
}
