package ir.navid.app.reminder

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import ir.navid.app.MainActivity
import ir.navid.app.domain.ReminderLevel

object NotificationHelper {
    private fun channelId(level: ReminderLevel) = "navid_" + level.name.lowercase()

    /** سه کانال اعلان: فوری (بالا)، مهم (متوسط)، عادی (کم). */
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(channelId(ReminderLevel.URGENT), "یادآوری فوری", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(channelId(ReminderLevel.IMPORTANT), "یادآوری مهم", NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(channelId(ReminderLevel.NORMAL), "یادآوری عادی", NotificationManager.IMPORTANCE_LOW)
        )
    }

    @SuppressLint("MissingPermission")
    fun show(context: Context, id: String, title: String, level: ReminderLevel) {
        ensureChannels(context)
        val manager = NotificationManagerCompat.from(context)
        if (!manager.areNotificationsEnabled()) return
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val priority = when (level) {
            ReminderLevel.URGENT -> NotificationCompat.PRIORITY_HIGH
            ReminderLevel.IMPORTANT -> NotificationCompat.PRIORITY_DEFAULT
            ReminderLevel.NORMAL -> NotificationCompat.PRIORITY_LOW
        }
        val notification = NotificationCompat.Builder(context, channelId(level))
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("یادآوری " + level.labelFa)
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(title))
            .setPriority(priority)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        manager.notify(id.hashCode(), notification)
    }
}
