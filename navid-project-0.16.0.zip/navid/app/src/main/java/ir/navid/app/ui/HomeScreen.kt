package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.weekdayNameFa
import ir.navid.app.data.TransactionWithLines
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun HomeScreen(
    vm: FinanceViewModel,
    onTxClick: (TransactionWithLines) -> Unit,
    modifier: Modifier = Modifier
) {
    val summary by vm.monthSummary.collectAsState()
    val recent by vm.recent.collectAsState()
    val accounts by vm.accounts.collectAsState()
    val names = accounts.associate { it.id to it.name }

    val now = LocalDate.now(ZoneId.of("Asia/Tehran"))
    val today = JalaliDate.from(now)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("NAVID", style = MaterialTheme.typography.headlineMedium)
        Text(
            "${weekdayNameFa(now.dayOfWeek)}، ${today.formatLong()}",
            style = MaterialTheme.typography.bodyLarge
        )

        SectionCard("خلاصه مالی ${vm.monthTitle}") {
            LabeledAmount("درآمد", summary.income)
            LabeledAmount("هزینه", summary.expense)
            LabeledAmount("خالص", summary.net)
        }

        SectionCard("آخرین فعالیت ها") {
            if (recent.isEmpty()) {
                Text("هنوز تراکنشی ثبت نشده است. با دکمه شناور ＋ یک هزینه یا درآمد ثبت کنید.")
            } else {
                recent.take(5).forEach { item -> TransactionRow(item, names, onClick = { onTxClick(item) }) }
            }
        }

        SectionCard("وضعیت دستیار هوشمند") {
            Text("مدل محلی نصب نشده است. دستیار در مراحل بعدی ساخته می شود.")
        }
    }
}
