package ir.navid.app.knowledge.text

data class TextChunk(
    val clause: String,
    val chapter: String,
    val pageFrom: Int,
    val pageTo: Int,
    val heading: String,
    val text: String,
    /** نوار برجسته سازی روی صفحه pageFrom (کسری از ارتفاع صفحه)؛ null یعنی نامعلوم. */
    val hlTop: Float? = null,
    val hlBottom: Float? = null
)

/** تکه بندی ساختاری: هر بند شماره دار (مثل 4-1-3-4) یک تکه است؛ متن بدون شماره به بند قبلی می چسبد. */
object Chunker {
    private val clauseStart = Regex("^(\\d+(?:-\\d+){1,4})(?=\\s|$)")
    private val sentenceBreak = Regex("(?<=[.!?\u061F])\\s+")

    internal class Piece(val text: String, val top: Float?, val bottom: Float?)

    private class Builder(val clause: String, val chapter: String, val pageFrom: Int) {
        var pageTo: Int = pageFrom
        val lines = ArrayList<String>()
        var top: Float? = null
        var bottom: Float? = null

        fun addGeometry(page: Int, t: Float?, b: Float?) {
            if (page != pageFrom || t == null || b == null) return
            top = top?.let { minOf(it, t) } ?: t
            bottom = bottom?.let { maxOf(it, b) } ?: b
        }
    }

    fun chunk(pages: List<String>, chapters: List<String>, maxLen: Int = 1200): List<TextChunk> =
        collect(pages.map { p -> p.split("\n").map { Piece(it, null, null) } }, chapters, emptyList(), maxLen)

    fun chunkLines(pages: List<List<TextLine>>, chapters: List<String>, heights: List<Float>, maxLen: Int = 1200): List<TextChunk> =
        collect(
            pages.map { p -> p.map { Piece(it.text, if (it.hasGeometry) it.top else null, if (it.hasGeometry) it.bottom else null) } },
            chapters, heights, maxLen
        )

    private fun collect(pages: List<List<Piece>>, chapters: List<String>, heights: List<Float>, maxLen: Int): List<TextChunk> {
        val raw = ArrayList<TextChunk>()
        var cur: Builder? = null

        fun flush() {
            val b = cur
            if (b != null) {
                val text = b.lines.joinToString(" ").trim()
                if (text.isNotEmpty()) {
                    val h = heights.getOrNull(b.pageFrom - 1) ?: 0f
                    val t = b.top
                    val bt = b.bottom
                    var hlTop: Float? = null
                    var hlBottom: Float? = null
                    if (t != null && bt != null && h > 0f) {
                        hlTop = (t / h).coerceIn(0f, 1f)
                        hlBottom = (bt / h).coerceIn(0f, 1f)
                    }
                    raw.add(TextChunk(b.clause, b.chapter, b.pageFrom, b.pageTo, "", text, hlTop, hlBottom))
                }
            }
            cur = null
        }

        pages.forEachIndexed { index, pieces ->
            val pageNo = index + 1
            val chapter = chapters.getOrElse(index) { "" }
            for (piece in pieces) {
                val s = piece.text.trim()
                if (s.isEmpty()) continue
                val m = clauseStart.find(s)
                if (m != null) {
                    flush()
                    val b = Builder(m.groupValues[1], chapter, pageNo)
                    b.lines.add(s)
                    b.addGeometry(pageNo, piece.top, piece.bottom)
                    cur = b
                } else {
                    val b = cur ?: Builder("", chapter, pageNo).also { cur = it }
                    b.lines.add(s)
                    b.pageTo = pageNo
                    b.addGeometry(pageNo, piece.top, piece.bottom)
                }
            }
        }
        flush()
        return finish(raw, maxLen)
    }

    /** تقسیم تکه های بلند و افزودن عنوان بند والد. */
    private fun finish(raw: List<TextChunk>, maxLen: Int): List<TextChunk> {

        // تقسیم تکه های بلند: اول با مرز جمله، بعد با مرز کلمه
        val split = ArrayList<TextChunk>()
        for (c in raw) {
            if (c.text.length <= maxLen) {
                split.add(c)
                continue
            }
            var buf = StringBuilder()
            for (s in sentenceBreak.split(c.text)) {
                if (buf.length + s.length > maxLen && buf.isNotEmpty()) {
                    split.add(c.copy(text = buf.toString().trim()))
                    buf = StringBuilder()
                }
                buf.append(s).append(' ')
            }
            if (buf.toString().isNotBlank()) split.add(c.copy(text = buf.toString().trim()))
        }
        val finalList = ArrayList<TextChunk>()
        for (c in split) {
            var t = c.text
            while (t.length > 1500) {
                var cut = t.lastIndexOf(' ', 1199)
                if (cut < 600) cut = 1200
                finalList.add(c.copy(text = t.substring(0, cut).trim()))
                t = t.substring(cut).trim()
            }
            if (t.isNotEmpty()) finalList.add(c.copy(text = t))
        }

        // عنوان بند والد (مثلاً «4-1-3 دامنه کاربرد») برای هر تکه
        val titles = HashMap<String, String>()
        for (c in finalList) {
            if (c.clause.isNotEmpty() && c.text.length <= 110 && c.text.startsWith(c.clause) && c.clause !in titles) {
                titles[c.clause] = c.text.substring(c.clause.length).trim()
            }
        }
        return finalList.map { c ->
            var heading = ""
            if (c.clause.isNotEmpty()) {
                val parts = c.clause.split("-")
                for (k in parts.size - 1 downTo 1) {
                    val key = parts.take(k).joinToString("-")
                    val title = titles[key]
                    if (title != null) {
                        heading = "$key $title"
                        break
                    }
                }
            }
            c.copy(heading = heading)
        }
    }
}
