package ir.navid.app.domain

object Trash {
    const val RETENTION_DAYS = 30
    private const val DAY_MS = 24L * 60 * 60 * 1000

    /** هر مورد حذف شده قبل از این زمان باید برای همیشه پاک شود. */
    fun purgeCutoff(nowMillis: Long): Long = nowMillis - RETENTION_DAYS * DAY_MS
}
