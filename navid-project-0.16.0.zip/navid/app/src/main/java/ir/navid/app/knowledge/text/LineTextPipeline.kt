package ir.navid.app.knowledge.text

/** خط لوله سطری: سطرهای بازسازی شده از موقعیت نویسه ها با مختصات؛ خروجی همان TextPipeline.Result. */
object LineTextPipeline {
    data class PageInput(val lines: List<TextLine>, val height: Float)

    fun process(inputs: List<PageInput>): TextPipeline.Result {
        var pages: List<List<TextLine>> = inputs.map { pg ->
            pg.lines.map { it.copy(text = PdfTextCleaner.cleanRaw(it.text).trim()) }.filter { it.text.isNotEmpty() }
        }
        // آزمون خود سازگاری شماره بندها همچنان اجرا می شود؛ برای متن مبتنی بر موقعیت وارونگی لازم نیست
        val orientation = ClauseOrientation.decide(pages.map { p -> p.joinToString("\n") { it.text } })
        if (orientation.reversed) pages = pages.map { p -> p.map { it.copy(text = ClauseOrientation.fixRuns(it.text)) } }
        val printed = PageStructure.detectPrintedLines(pages) { it.text }
        pages = PageStructure.stripPageNumberLines(pages, printed.offset) { it.text }
        val headers = PageStructure.detectHeaderLines(pages) { it.text }
        val stripped = PageStructure.stripHeaderLines(pages, headers) { it.text }
        val chunks = Chunker.chunkLines(stripped.pages, stripped.chapters, inputs.map { it.height })
        return TextPipeline.Result(
            pages = stripped.pages.map { p -> p.joinToString("\n") { it.text } },
            chapters = stripped.chapters,
            chunks = chunks,
            orientation = orientation,
            printedOffset = printed.offset,
            headerCount = headers.size
        )
    }
}
