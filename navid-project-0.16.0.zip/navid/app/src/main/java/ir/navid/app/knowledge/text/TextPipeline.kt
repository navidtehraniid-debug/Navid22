package ir.navid.app.knowledge.text

/** خط لوله کامل پس از استخراج: پاک سازی، جهت شماره بندها، شماره صفحه چاپی، سرصفحه، تکه بندی. کد خالص و قابل آزمون. */
object TextPipeline {
    data class Result(
        val pages: List<String>,
        val chapters: List<String>,
        val chunks: List<TextChunk>,
        val orientation: ClauseOrientation.Decision,
        val printedOffset: Int?,
        val headerCount: Int
    )

    fun process(rawPages: List<String>): Result {
        var pages = rawPages.map { PdfTextCleaner.cleanRaw(it) }
        val orientation = ClauseOrientation.decide(pages)
        if (orientation.reversed) pages = pages.map { ClauseOrientation.fixRuns(it) }
        val printed = PageStructure.detectPrinted(pages)
        pages = PageStructure.stripPageNumbers(pages, printed.offset)
        val headers = PageStructure.detectHeaders(pages)
        val stripped = PageStructure.stripHeaders(pages, headers)
        val chunks = Chunker.chunk(stripped.pages, stripped.chapters)
        return Result(stripped.pages, stripped.chapters, chunks, orientation, printed.offset, headers.size)
    }
}
