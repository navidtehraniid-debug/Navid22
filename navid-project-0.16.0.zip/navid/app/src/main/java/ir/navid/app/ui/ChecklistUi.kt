package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import ir.navid.app.knowledge.data.SearchHit
import ir.navid.app.domain.PageRefs
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.ChecklistResultEntity
import ir.navid.app.domain.CheckStatus
import ir.navid.app.domain.ChecklistMath
import ir.navid.app.domain.PhaseMatch
import java.time.LocalDate

private fun summaryText(results: List<ChecklistResultEntity>): String {
    val s = ChecklistMath.summarize(results.map { it.status })
    return ("${s.approved} تأیید • ${s.rejected} عدم تأیید • ${s.needsReview} نیازمند بررسی • " +
        "${s.notApplicable} قابل اجرا نیست • ${s.pending} بررسی نشده  (${s.checkedPercent}٪ بررسی شده)").toPersianDigits()
}

/** بخش چک لیست های نظارتی یک پروژه: شروع بازدید با قالب، ثبت وضعیت هر مورد، و مدیریت قالب ها. */
@Composable
fun ChecklistSection(projectId: String, vm: ChecklistViewModel, currentPhase: String? = null) {
    val allRuns by vm.runs.collectAsState()
    val allResults by vm.results.collectAsState()
    val runs = allRuns.filter { it.projectId == projectId }
    var showStart by remember { mutableStateOf(false) }
    var showTemplates by remember { mutableStateOf(false) }
    var openRunId by remember { mutableStateOf<String?>(null) }

    SectionCard("چک لیست های نظارت") {
        if (runs.isEmpty()) Text("هنوز بازدیدی با چک لیست ثبت نشده است.")
        runs.forEach { r ->
            val res = allResults.filter { it.runId == r.id }
            val date = try {
                JalaliDate.from(LocalDate.parse(r.runDate)).formatLong()
            } catch (e: Exception) {
                r.runDate
            }
            Text(r.title, style = MaterialTheme.typography.titleSmall)
            Text(date + "\n" + summaryText(res), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(onClick = { openRunId = r.id }) { Text("باز کردن") }
                TextButton(onClick = { vm.deleteRun(r.id) }) { Text("حذف") }
            }
            Divider()
        }
        Button(onClick = { showStart = true }, modifier = Modifier.fillMaxWidth()) { Text("شروع بازدید با چک لیست") }
        TextButton(onClick = { showTemplates = true }) { Text("مدیریت قالب ها") }
    }

    if (showStart) StartRunDialog(projectId, vm, currentPhase) { showStart = false }
    if (showTemplates) TemplatesDialog(vm) { showTemplates = false }
    openRunId?.let { id ->
        val run = allRuns.firstOrNull { it.id == id }
        if (run != null) {
            RunDialog(run.title, projectId, allResults.filter { it.runId == id }, vm) { openRunId = null }
        }
    }
}

@Composable
private fun StartRunDialog(projectId: String, vm: ChecklistViewModel, currentPhase: String?, onDismiss: () -> Unit) {
    val templates by vm.templates.collectAsState()
    var selected by remember { mutableStateOf<String?>(null) }
    var dateText by remember { mutableStateOf(JalaliDate.today().format()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("شروع بازدید") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("قالب چک لیست", style = MaterialTheme.typography.labelLarge)
                if (templates.isEmpty()) Text("قالبی نیست؛ از «مدیریت قالب ها» یکی بسازید.")
                templates.sortedByDescending { PhaseMatch.matches(it.phaseKey, currentPhase) }.forEach { t ->
                    val match = PhaseMatch.matches(t.phaseKey, currentPhase)
                    AccountChoice(t.title + if (match) " (مرحله فعلی)" else "", selected == t.id) { selected = t.id; error = null }
                }
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it; error = null },
                    label = { Text("تاریخ شمسی بازدید") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val id = selected
                if (id == null) {
                    error = "یک قالب انتخاب کنید"
                } else {
                    vm.startRun(projectId, id, dateText) { result -> if (result == null) onDismiss() else error = result }
                }
            }) { Text("شروع") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun TemplatesDialog(vm: ChecklistViewModel, onDismiss: () -> Unit) {
    val templates by vm.templates.collectAsState()
    val items by vm.templateItems.collectAsState()
    var title by remember { mutableStateOf("") }
    var phase by remember { mutableStateOf("") }
    var itemsText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("قالب های چک لیست") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                templates.forEach { t ->
                    Text(t.title, style = MaterialTheme.typography.titleSmall)
                    val count = items.count { it.templateId == t.id }
                    Text(
                        ("$count مورد" + (t.phaseKey.takeIf { it.isNotBlank() }?.let { " • $it" } ?: "")).toPersianDigits(),
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (t.sourceNote.isNotBlank()) Text(t.sourceNote, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.deleteTemplate(t.id) }) { Text("حذف قالب") }
                    Divider()
                }
                Text("قالب جدید", style = MaterialTheme.typography.labelLarge)
                OutlinedTextField(value = title, onValueChange = { title = it; error = null }, label = { Text("عنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phase, onValueChange = { phase = it }, label = { Text("مرحله ساخت (اختیاری)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = itemsText,
                    onValueChange = { itemsText = it; error = null },
                    label = { Text("موارد (هر مورد در یک خط)") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Button(onClick = {
                    vm.createTemplate(title, phase, itemsText) { result ->
                        if (result == null) {
                            title = ""
                            phase = ""
                            itemsText = ""
                        } else {
                            error = result
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("افزودن قالب") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}

@Composable
private fun RunDialog(title: String, projectId: String, results: List<ChecklistResultEntity>, vm: ChecklistViewModel, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("بستن") }
                }
                Text(summaryText(results), style = MaterialTheme.typography.bodySmall)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(results, key = { it.id }) { r -> ResultItem(r, projectId, vm) }
                }
            }
        }
    }
}

@Composable
private fun StatusButton(status: CheckStatus, current: CheckStatus, modifier: Modifier, onClick: () -> Unit) {
    if (status == current) Button(onClick = onClick, modifier = modifier) { Text(status.labelFa) }
    else OutlinedButton(onClick = onClick, modifier = modifier) { Text(status.labelFa) }
}

@Composable
private fun ResultItem(r: ChecklistResultEntity, projectId: String, vm: ChecklistViewModel) {
    var note by remember(r.id, r.note) { mutableStateOf(r.note) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text((r.sortOrder + 1).toString().toPersianDigits() + ". " + r.itemText, style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            StatusButton(CheckStatus.APPROVED, r.status, Modifier.weight(1f)) { vm.setResult(r.id, CheckStatus.APPROVED, note) }
            StatusButton(CheckStatus.REJECTED, r.status, Modifier.weight(1f)) { vm.setResult(r.id, CheckStatus.REJECTED, note) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            StatusButton(CheckStatus.NEEDS_REVIEW, r.status, Modifier.weight(1f)) { vm.setResult(r.id, CheckStatus.NEEDS_REVIEW, note) }
            StatusButton(CheckStatus.NOT_APPLICABLE, r.status, Modifier.weight(1f)) { vm.setResult(r.id, CheckStatus.NOT_APPLICABLE, note) }
        }
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("یادداشت این مورد") },
            modifier = Modifier.fillMaxWidth()
        )
        if (note != r.note) TextButton(onClick = { vm.setResult(r.id, r.status, note) }) { Text("ذخیره یادداشت") }
        PhotoStrip(projectId, "CHECK_RESULT", r.id)
        var showPicker by remember { mutableStateOf(false) }
        val source = r.sourceRef
        if (source != null) {
            Text("منبع: $source", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { vm.setSource(r.id, null) }) { Text("حذف منبع") }
        } else {
            TextButton(onClick = { showPicker = true }) { Text("یافتن منبع در کتابخانه") }
        }
        if (showPicker) {
            SourcePickerDialog(r.itemText, { ref -> vm.setSource(r.id, ref); showPicker = false }) { showPicker = false }
        }
        Divider()
    }
}

private fun referenceOf(h: SearchHit): String = listOfNotNull(
    h.title,
    h.clause.takeIf { it.isNotEmpty() }?.let { "بند $it" },
    PageRefs.format(h.pageFrom, h.pageTo, h.printedOffset)
).joinToString(" • ").toPersianDigits()

/** انتخاب منبع برای یک مورد چک لیست از نتیجه های کتابخانه؛ فقط با انتخاب خود کاربر ثبت می شود. */
@Composable
private fun SourcePickerDialog(initialQuery: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val libraryVm: LibraryViewModel = viewModel()
    var query by remember { mutableStateOf(initialQuery) }
    var runQuery by remember { mutableStateOf(initialQuery) }
    var hits by remember { mutableStateOf<List<SearchHit>?>(null) }
    LaunchedEffect(runQuery) {
        hits = null
        hits = libraryVm.ask(runQuery, 5)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("منبع این مورد") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("عبارت جست وجو") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = { runQuery = query }, modifier = Modifier.fillMaxWidth()) { Text("جست وجو") }
                val list = hits
                if (list == null) Text("در حال جست وجو...")
                else if (list.isEmpty()) Text("منبعی پیدا نشد. عبارت را تغییر دهید یا کتاب مرتبط را به کتابخانه اضافه کنید.")
                list?.forEach { h ->
                    Divider()
                    Text(referenceOf(h), style = MaterialTheme.typography.bodySmall)
                    Text(h.snippet, style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { onPick(referenceOf(h)) }) { Text("انتخاب این منبع") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}
