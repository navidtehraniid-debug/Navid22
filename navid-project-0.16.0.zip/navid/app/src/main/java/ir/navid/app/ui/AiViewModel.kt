package ir.navid.app.ui

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.ai.model.AiSettings
import ir.navid.app.ai.model.AiSettingsStore
import ir.navid.app.ai.model.ApiFormat
import ir.navid.app.ai.model.ExternalApiModel
import ir.navid.app.ai.model.ExternalConfig
import ir.navid.app.ai.model.LanguageModel
import ir.navid.app.ai.model.LocalModelFactory
import ir.navid.app.ai.model.ModelProvider
import ir.navid.app.ai.model.ModelRequest
import ir.navid.app.ai.model.ModelResult
import ir.navid.app.ai.model.UrlPolicy
import ir.navid.app.ai.ocr.OcrData
import ir.navid.app.ai.ocr.OcrFactory
import ir.navid.app.ai.rag.AnswerValidator
import ir.navid.app.ai.rag.RagPrompt
import ir.navid.app.ai.rag.RagSource
import ir.navid.app.ai.rag.ValidatedAnswer
import ir.navid.app.domain.StoragePolicy
import ir.navid.app.knowledge.data.SearchHit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

sealed interface AnswerResult {
    data class Done(
        val validated: ValidatedAnswer,
        val sources: List<RagSource>,
        val modelName: String,
        val millis: Long
    ) : AnswerResult

    data class Error(val message: String) : AnswerResult
}

class AiViewModel(app: Application) : AndroidViewModel(app) {
    private val appContext = app
    private val store = AiSettingsStore(app)
    private var localModel: LanguageModel? = null
    private var localPath: String? = null

    val settings = MutableStateFlow(store.load())
    val hasKey = MutableStateFlow(store.hasApiKey())
    val busy = MutableStateFlow(false)
    val status = MutableStateFlow<String?>(null)
    val lastError = MutableStateFlow<String?>(null)
    val ocrReady = MutableStateFlow(OcrData.exists(app))
    val localAvailable: Boolean = LocalModelFactory.isAvailable()
    val ocrAvailable: Boolean = OcrFactory.isAvailable()

    fun update(s: AiSettings) {
        store.save(s)
        settings.value = s
    }

    fun saveKey(key: String?) {
        store.saveApiKey(key)
        hasKey.value = store.hasApiKey()
    }

    /** مدل فعال؛ هر شکست به صورت متن در lastError می ماند (برای عیب یابی) و برنامه را از کار نمی اندازد. */
    private fun activeModel(): LanguageModel? {
        lastError.value = null
        val s = settings.value
        return try {
            when (s.provider) {
                ModelProvider.NONE -> null
                ModelProvider.EXTERNAL -> store.externalConfig()?.let { ExternalApiModel(it) }
                    ?: run { lastError.value = "کلید، آدرس یا نام مدل سرویس بیرونی کامل نیست."; null }
                ModelProvider.LOCAL_SERVER -> {
                    if (!UrlPolicy.isLoopback(s.localServerUrl)) {
                        lastError.value = "آدرس سرور محلی باید روی همین گوشی باشد (127.0.0.1 یا localhost)؛ آدرس شبکه یعنی خروج داده از گوشی."
                        null
                    } else {
                        ExternalApiModel(ExternalConfig(ApiFormat.OPENAI, s.localServerUrl, s.localServerModel.ifBlank { "local" }, ""))
                    }
                }
                ModelProvider.LOCAL -> {
                    val path = s.localModelPath
                    if (path == null || !File(path).exists()) {
                        lastError.value = "فایل مدل محلی انتخاب نشده یا پاک شده است."
                        null
                    } else {
                        if (localModel == null || localPath != path) {
                            localModel?.close()
                            val created = LocalModelFactory.create(appContext, path)
                            localModel = created.model
                            localPath = path
                            lastError.value = created.error
                        }
                        localModel
                    }
                }
            }
        } catch (t: Throwable) {
            lastError.value = "${t.javaClass.simpleName}: ${(t.message ?: "").take(200)}"
            null
        }
    }

    /** آزمون کوتاه؛ فقط یک جمله بی ربط به پروژه (مثل «آماده؟») فرستاده می شود. */
    fun testActive() {
        viewModelScope.launch {
            busy.value = true
            status.value = "در حال آزمون (بارگذاری مدل محلی می تواند چند ده ثانیه طول بکشد)..."
            val model = activeModel()
            status.value = if (model == null) {
                lastError.value ?: "مدل فعال تنظیم نشده است (نوع مدل را انتخاب کنید)."
            } else {
                try {
                    when (val r = model.generate(ModelRequest("فقط بنویس: آماده", "آماده؟", maxTokens = 20))) {
                        is ModelResult.Ok -> "پاسخ مدل: ${r.text.take(80)}  (${r.millis} میلی ثانیه)"
                        is ModelResult.Error -> {
                            lastError.value = r.message
                            r.message
                        }
                    }
                } catch (t: Throwable) {
                    val m = "${t.javaClass.simpleName}: ${(t.message ?: "").take(200)}"
                    lastError.value = m
                    m
                }
            }
            busy.value = false
        }
    }

    fun importLocalModel(uri: Uri) {
        viewModelScope.launch {
            busy.value = true
            status.value = "در حال کپی فایل مدل (چند دقیقه طول می کشد)..."
            status.value = withContext(Dispatchers.IO) {
                try {
                    var name = "model"
                    var size = -1L
                    appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            if (!c.isNull(0)) name = c.getString(0)
                            if (!c.isNull(1)) size = c.getLong(1)
                        }
                    }
                    if (name.endsWith(".gguf", ignoreCase = true)) {
                        return@withContext "فرمت GGUF (مثل مدل های PocketPal) با LiteRT-LM سازگار نیست. یا مدل .litertlm بگیرید، یا مدل GGUF را با llama.cpp server روی همین گوشی (Termux) اجرا کنید و نوع «سرور محلی» را انتخاب کنید."
                    }
                    if (!name.endsWith(".litertlm", ignoreCase = true)) {
                        return@withContext "فایل باید پسوند .litertlm داشته باشد (مدل های LiteRT Community در HuggingFace)."
                    }
                    val dir = File(appContext.filesDir, "models").also { it.mkdirs() }
                    val free = StatFs(dir.path).availableBytes
                    if (size >= 0 && free < size + StoragePolicy.MIN_FREE_BYTES) return@withContext "فضای خالی گوشی کافی نیست."
                    val target = File(dir, "model.litertlm")
                    val tmp = File(dir, "model.litertlm.part")
                    localModel?.close()
                    localModel = null
                    appContext.contentResolver.openInputStream(uri)?.use { ins ->
                        FileOutputStream(tmp).use { out -> ins.copyTo(out, 256 * 1024) }
                    } ?: return@withContext "فایل خوانده نشد."
                    target.delete()
                    tmp.renameTo(target)
                    update(settings.value.copy(localModelPath = target.path, provider = ModelProvider.LOCAL))
                    "مدل ذخیره شد و «مدل محلی» انتخاب شد: $name (${StoragePolicy.formatSize(target.length())}). حالا «آزمون کوتاه» را بزنید."
                } catch (e: Exception) {
                    "خطا در کپی مدل: " + (e.message ?: e.javaClass.simpleName).take(120)
                }
            }
            busy.value = false
        }
    }

    /** داده فارسی OCR (fas.traineddata از tessdata_fast) را دانلود می کند. */
    fun downloadOcrData() {
        viewModelScope.launch {
            busy.value = true
            status.value = "در حال دریافت داده فارسی OCR..."
            status.value = withContext(Dispatchers.IO) {
                try {
                    val target = OcrData.file(appContext)
                    target.parentFile?.mkdirs()
                    val tmp = File(target.path + ".part")
                    val conn = URL(OcrData.DOWNLOAD_URL).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15_000
                    conn.readTimeout = 60_000
                    if (conn.responseCode !in 200..299) return@withContext "دریافت ناموفق (کد ${conn.responseCode}). فایل fas.traineddata را دستی انتخاب کنید."
                    conn.inputStream.use { ins -> FileOutputStream(tmp).use { out -> ins.copyTo(out, 64 * 1024) } }
                    conn.disconnect()
                    if (tmp.length() < 300_000) {
                        tmp.delete()
                        return@withContext "فایل دریافت شده ناقص است."
                    }
                    target.delete()
                    tmp.renameTo(target)
                    ocrReady.value = true
                    "داده فارسی OCR ذخیره شد (${StoragePolicy.formatSize(target.length())})."
                } catch (e: Exception) {
                    "خطا در دریافت: " + (e.message ?: e.javaClass.simpleName).take(120)
                }
            }
            busy.value = false
        }
    }

    fun importOcrData(uri: Uri) {
        viewModelScope.launch {
            busy.value = true
            status.value = withContext(Dispatchers.IO) {
                try {
                    val target = OcrData.file(appContext)
                    target.parentFile?.mkdirs()
                    appContext.contentResolver.openInputStream(uri)?.use { ins ->
                        FileOutputStream(target).use { out -> ins.copyTo(out, 64 * 1024) }
                    } ?: return@withContext "فایل خوانده نشد."
                    if (!OcrData.exists(appContext)) {
                        target.delete()
                        return@withContext "فایل انتخاب شده fas.traineddata معتبر نیست."
                    }
                    ocrReady.value = true
                    "داده فارسی OCR ذخیره شد."
                } catch (e: Exception) {
                    "خطا: " + (e.message ?: e.javaClass.simpleName).take(120)
                }
            }
            busy.value = false
        }
    }

    /** خلاصه وضعیت برای عیب یابی؛ کاربر می تواند کپی کند و بفرستد. */
    fun diagnostics(): String {
        val s = settings.value
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val path = s.localModelPath
        val file = path?.let { File(it) }
        return listOf(
            "نوع APK: " + (if (localAvailable) "دارای LiteRT-LM" else "بدون LiteRT-LM (پایدار)") + " | " + (if (ocrAvailable) "دارای OCR" else "بدون OCR"),
            "معماری: " + Build.SUPPORTED_ABIS.joinToString(",") + " | اندروید " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")",
            "حافظه: آزاد " + mem.availMem / (1024 * 1024) + " از " + mem.totalMem / (1024 * 1024) + " مگابایت",
            "نوع مدل انتخاب شده: " + s.provider.labelFa,
            "فایل مدل محلی: " + (if (file != null && file.exists()) "${file.name} (${file.length() / (1024 * 1024)} مگابایت)" else "ندارد"),
            "سرور محلی: " + s.localServerUrl + (if (UrlPolicy.isLoopback(s.localServerUrl)) " (loopback)" else " (نامعتبر برای حالت محلی)"),
            "داده OCR فارسی: " + (if (ocrReady.value) "هست" else "ندارد"),
            "آخرین خطا: " + (lastError.value ?: "ندارد")
        ).joinToString("\n")
    }

    /** پاسخ از روی گزیده های کتابخانه؛ خروجی مدل همیشه با اعتبارسنج بررسی می شود. */
    suspend fun answer(question: String, hits: List<SearchHit>): AnswerResult {
        val model = activeModel() ?: return AnswerResult.Error(lastError.value ?: "مدل فعال تنظیم نشده است.")
        val usable = if (settings.value.provider == ModelProvider.EXTERNAL) hits.filter { it.externalAllowed } else hits
        if (usable.isEmpty()) return AnswerResult.Error("هیچ یک از منبع های پیدا شده اجازه ارسال به سرویس بیرونی ندارند (در مشخصات سند فعال کنید).")
        val sources = RagPrompt.sourcesFrom(usable)
        if (sources.isEmpty()) return AnswerResult.Error("منبعی برای پاسخ نیست.")
        return try {
            when (val r = model.generate(RagPrompt.build(question, sources))) {
                is ModelResult.Ok -> AnswerResult.Done(AnswerValidator.validate(r.text, sources), sources, model.name, r.millis)
                is ModelResult.Error -> {
                    lastError.value = r.message
                    AnswerResult.Error(r.message)
                }
            }
        } catch (t: Throwable) {
            val m = "${t.javaClass.simpleName}: ${(t.message ?: "").take(200)}"
            lastError.value = m
            AnswerResult.Error(m)
        }
    }

    fun modelDescription(): String = settings.value.let { s ->
        when (s.provider) {
            ModelProvider.EXTERNAL -> "${s.format.labelFa} • ${s.model}"
            ModelProvider.LOCAL -> "مدل محلی روی گوشی"
            ModelProvider.LOCAL_SERVER -> "سرور محلی روی گوشی"
            ModelProvider.NONE -> "بدون مدل"
        }
    }
}
