package ir.navid.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.navid.app.domain.PhaseStatus
import ir.navid.app.domain.ProjectStatus

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val landArea: Double?,
    val builtArea: Double?,
    val floors: Int?,
    val structureType: String,
    val initialBudget: Long,
    val status: ProjectStatus,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "phases", indices = [Index("projectId")])
data class PhaseEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val name: String,
    val sortOrder: Int,
    val plannedStart: String?,
    val plannedEnd: String?,
    val actualStart: String?,
    val actualEnd: String?,
    val status: PhaseStatus,
    val progressPct: Int,
    val notes: String
)

@Entity(tableName = "site_reports", indices = [Index("projectId")])
data class SiteReportEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val phaseId: String?,
    val reportDate: String,
    val text: String,
    val source: String,
    val createdAt: Long,
    val deletedAt: Long? = null
)

data class ProjectCost(val projectId: String, val cost: Long)
