package ir.navid.app.core

/** تبدیل عدد به حروف فارسی برای نمایش مبلغ در کارت تأیید، مثلاً 400000 به «چهارصد هزار». */
object PersianNumberWords {
    private val ones = listOf("", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه")
    private val teens = listOf("ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده")
    private val tens = listOf("", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود")
    private val hundreds = listOf("", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد")

    private fun groupWords(n: Int): String {
        val parts = ArrayList<String>()
        val h = n / 100
        val r = n % 100
        if (h > 0) parts.add(hundreds[h])
        if (r >= 20) {
            parts.add(tens[r / 10])
            if (r % 10 > 0) parts.add(ones[r % 10])
        } else if (r >= 10) {
            parts.add(teens[r - 10])
        } else if (r > 0) {
            parts.add(ones[r])
        }
        return parts.joinToString(" و ")
    }

    fun toWords(n: Long): String {
        if (n == 0L) return "صفر"
        if (n < 0L) return "منفی " + toWords(-n)
        if (n >= 1_000_000_000L) {
            val b = n / 1_000_000_000L
            val rest = n % 1_000_000_000L
            return toWords(b) + " میلیارد" + (if (rest > 0) " و " + toWords(rest) else "")
        }
        val parts = ArrayList<String>()
        val m = (n / 1_000_000L).toInt()
        val rest = n % 1_000_000L
        val t = (rest / 1000L).toInt()
        val u = (rest % 1000L).toInt()
        if (m > 0) parts.add(groupWords(m) + " میلیون")
        if (t > 0) parts.add(if (t == 1) "هزار" else groupWords(t) + " هزار")
        if (u > 0) parts.add(groupWords(u))
        return parts.joinToString(" و ")
    }
}
