package ir.navid.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.navid.app.ai.action.ProjectRef
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.formatToman
import ir.navid.app.core.parseAmount
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.data.amount
import ir.navid.app.data.counterAccountId
import ir.navid.app.data.primaryAccountId
import ir.navid.app.domain.AccountType
import ir.navid.app.domain.TxKind
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAddSheet(onDismiss: () -> Unit, onPick: (TxKind) -> Unit, onNote: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("ثبت سریع", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { onPick(TxKind.EXPENSE) }, modifier = Modifier.fillMaxWidth()) {
                Text("ثبت هزینه", modifier = Modifier.fillMaxWidth())
            }
            TextButton(onClick = { onPick(TxKind.INCOME) }, modifier = Modifier.fillMaxWidth()) {
                Text("ثبت درآمد", modifier = Modifier.fillMaxWidth())
            }
            TextButton(onClick = { onPick(TxKind.TRANSFER) }, modifier = Modifier.fillMaxWidth()) {
                Text("انتقال بین حساب ها", modifier = Modifier.fillMaxWidth())
            }
            TextButton(onClick = onNote, modifier = Modifier.fillMaxWidth()) {
                Text("یادداشت", modifier = Modifier.fillMaxWidth())
            }
            listOf("گزارش کارگاه", "قرار و یادآوری", "سند و تصویر", "ثبت صوتی").forEach { label ->
                TextButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
                    Text("$label (هنوز پیاده سازی نشده)", modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

/** فرم ثبت یا ویرایش. اگر editing خالی نباشد، همان تراکنش ویرایش می شود. */
@Composable
fun TransactionDialog(
    kind: TxKind,
    editing: TransactionWithLines?,
    vm: FinanceViewModel,
    onDismiss: () -> Unit,
    projects: List<ProjectRef> = emptyList(),
    defaultProjectId: String? = null
) {
    val accounts by vm.accounts.collectAsState()
    val assets = accounts.filter { it.type == AccountType.ASSET }

    var amountText by remember { mutableStateOf(editing?.amount()?.toString() ?: "") }
    var dateText by remember {
        mutableStateOf(
            if (editing != null) JalaliDate.from(LocalDate.parse(editing.tx.localDate)).format()
            else JalaliDate.today().format()
        )
    }
    var description by remember { mutableStateOf(editing?.tx?.description ?: "") }
    var primaryId by remember(assets.map { it.id }) {
        mutableStateOf(editing?.primaryAccountId() ?: assets.firstOrNull()?.id)
    }

    val counterList = when (kind) {
        TxKind.EXPENSE -> accounts.filter { it.type == AccountType.EXPENSE }
        TxKind.INCOME -> accounts.filter { it.type == AccountType.INCOME }
        TxKind.TRANSFER -> assets.filter { it.id != primaryId }
    }
    var counterId by remember(counterList.map { it.id }) {
        val preferred = editing?.counterAccountId()
        mutableStateOf(
            if (preferred != null && counterList.any { it.id == preferred }) preferred
            else counterList.firstOrNull()?.id
        )
    }
    var projectId by remember { mutableStateOf(editing?.tx?.projectId ?: defaultProjectId) }
    var error by remember { mutableStateOf<String?>(null) }

    val base = when (kind) {
        TxKind.EXPENSE -> "هزینه"
        TxKind.INCOME -> "درآمد"
        TxKind.TRANSFER -> "انتقال"
    }
    val title = if (editing != null) "ویرایش $base" else "ثبت $base"
    val primaryLabel = when (kind) {
        TxKind.EXPENSE -> "پرداخت از"
        TxKind.INCOME -> "واریز به"
        TxKind.TRANSFER -> "از حساب"
    }
    val counterLabel = when (kind) {
        TxKind.EXPENSE -> "دسته بندی هزینه"
        TxKind.INCOME -> "نوع درآمد"
        TxKind.TRANSFER -> "به حساب"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it; error = null },
                    label = { Text("مبلغ (تومان)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                parseAmount(amountText)?.let {
                    Text(it.formatToman(), style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it; error = null },
                    label = { Text("تاریخ شمسی (سال/ماه/روز)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("توضیحات (اختیاری)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(primaryLabel, style = MaterialTheme.typography.labelLarge)
                assets.forEach { acc ->
                    AccountChoice(acc.name, primaryId == acc.id) { primaryId = acc.id }
                }
                Text(counterLabel, style = MaterialTheme.typography.labelLarge)
                counterList.forEach { acc ->
                    AccountChoice(acc.name, counterId == acc.id) { counterId = acc.id }
                }
                if (kind == TxKind.EXPENSE && projects.isNotEmpty()) {
                    Text("پروژه ساختمانی (اختیاری)", style = MaterialTheme.typography.labelLarge)
                    AccountChoice("بدون پروژه", projectId == null) { projectId = null }
                    projects.forEach { pr -> AccountChoice(pr.name, projectId == pr.id) { projectId = pr.id } }
                }
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.save(
                    kind = kind,
                    primaryAccountId = primaryId,
                    counterAccountId = counterId,
                    amountText = amountText,
                    dateText = dateText,
                    description = description,
                    editId = editing?.tx?.id,
                    projectId = projectId
                ) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text(if (editing != null) "ذخیره تغییرات" else "ثبت") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
internal fun AccountChoice(name: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onSelect)
        Text(name)
    }
}
