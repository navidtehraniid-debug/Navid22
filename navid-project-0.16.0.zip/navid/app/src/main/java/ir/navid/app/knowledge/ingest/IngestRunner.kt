package ir.navid.app.knowledge.ingest

import android.content.Context
import ir.navid.app.ai.ocr.OcrData
import ir.navid.app.ai.ocr.OcrFactory
import ir.navid.app.core.toPersianDigits
import ir.navid.app.domain.IngestStatus
import ir.navid.app.domain.LibraryNaming
import ir.navid.app.domain.PageRefs
import ir.navid.app.knowledge.data.KnowledgeDatabase
import ir.navid.app.knowledge.data.KnowledgeIndex
import ir.navid.app.knowledge.data.LibChunkEntity
import ir.navid.app.knowledge.data.LibPageEntity
import ir.navid.app.knowledge.text.GlyphLineBuilder
import ir.navid.app.knowledge.text.LineTextPipeline
import ir.navid.app.knowledge.text.PdfTextCleaner
import ir.navid.app.knowledge.text.TextLine
import ir.navid.app.knowledge.text.SearchText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext

/** استخراج متن، پاک سازی، تکه بندی و ایندکس یک سند PDF. وضعیت هر مرحله در دیتابیس ثبت می شود. */
class IngestRunner(
    context: Context,
    private val db: KnowledgeDatabase,
    private val index: KnowledgeIndex
) {
    private val appContext = context.applicationContext
    private val dao = db.libDocumentDao()

    /** خروجی null یعنی موفق، در غیر این صورت پیام خطا. */
    suspend fun run(docId: String, onProgress: (Int, Int) -> Unit): String? = withContext(Dispatchers.Default) {
        val doc = dao.byId(docId) ?: return@withContext "سند پیدا نشد"
        if (LibraryNaming.extensionOf(doc.fileName) != "pdf") {
            return@withContext "پردازش متن فعلاً فقط برای PDF ممکن است"
        }
        dao.update(doc.copy(ingestStatus = IngestStatus.PROCESSING, ingestInfo = null, updatedAt = System.currentTimeMillis()))
        try {
            val inputs = ArrayList<LineTextPipeline.PageInput>()
            val methods = ArrayList<String>()
            val pdfFile = File(appContext.filesDir, doc.relPath)
            val source = PdfBoxPageTextSource.open(appContext, pdfFile)
            val ocr = if (OcrFactory.isAvailable() && OcrData.exists(appContext)) OcrFactory.create(appContext).engine else null
            val bitmaps = if (ocr != null) PdfPageBitmaps.open(pdfFile) else null
            try {
                val total = source.pageCount
                for (i in 0 until total) {
                    coroutineContext.ensureActive()
                    var input: LineTextPipeline.PageInput? = null
                    try {
                        val pg = source.glyphs(i)
                        if (pg.glyphs.isNotEmpty()) {
                            input = LineTextPipeline.PageInput(GlyphLineBuilder.build(pg.glyphs), pg.height)
                            methods.add("PDF_GLYPHS")
                        }
                    } catch (e: Exception) {
                        input = null
                    }
                    if (input == null && ocr != null && bitmaps != null) {
                        try {
                            val bmp = bitmaps.render(i, 1700)
                            val text = try { ocr.recognize(bmp) } finally { bmp.recycle() }
                            if (text.isNotBlank()) {
                                input = LineTextPipeline.PageInput(text.split("\n").map { TextLine(it, 0f, 0f) }, 1f)
                                methods.add("OCR")
                            }
                        } catch (e: Exception) {
                            input = null
                        }
                    }
                    if (input == null) {
                        val raw = try { source.rawText(i) } catch (e: Exception) { "" }
                        input = LineTextPipeline.PageInput(raw.split("\n").map { TextLine(it, 0f, 0f) }, 1f)
                        methods.add("PDF_TEXT")
                    }
                    inputs.add(input)
                    onProgress(i + 1, total)
                }
            } finally {
                source.close()
                bitmaps?.close()
                ocr?.close()
            }

            val result = LineTextPipeline.process(inputs)
            val pages = result.pages.mapIndexed { i, text ->
                LibPageEntity(
                    docId = docId,
                    pageNo = i + 1,
                    text = text,
                    printedPage = PageRefs.printed(i + 1, result.printedOffset),
                    quality = PdfTextCleaner.qualityScore(text),
                    method = methods.getOrElse(i) { "PDF_TEXT" }
                )
            }
            val withText = pages.count { it.text.length >= 40 && it.quality >= 0.5f }
            val latest = dao.byId(docId) ?: return@withContext "سند پیدا نشد"

            if (withText == 0) {
                dao.update(
                    latest.copy(
                        ingestStatus = IngestStatus.FAILED,
                        ingestInfo = if (ocr == null) "لایه متنی پیدا نشد؛ این PDF اسکن است. برای خواندن اسکن، نسخه NAVID-debug-full.apk را نصب و در «مدل هوش مصنوعی و OCR» داده فارسی را دریافت کنید." else "لایه متنی نبود و OCR هم متنی نخواند؛ کیفیت اسکن را بررسی کنید.",
                        pagesWithText = 0,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                return@withContext "لایه متنی پیدا نشد (احتمالاً اسکن)"
            }

            val chunks = result.chunks.map {
                LibChunkEntity(
                    docId = docId,
                    pageFrom = it.pageFrom,
                    pageTo = it.pageTo,
                    chapter = it.chapter,
                    clause = it.clause,
                    heading = it.heading,
                    text = it.text,
                    tokenCount = SearchText.tokens(it.text).size,
                    hlTop = it.hlTop,
                    hlBottom = it.hlBottom
                )
            }
            val indexTexts = result.chunks.map { SearchText.tokens(it.text + " " + it.heading + " " + it.chapter).joinToString(" ") }
            index.replaceContent(docId, pages, chunks, indexTexts)

            val o = result.orientation
            val orientationText = when {
                o.reversed -> "وارونه تشخیص داده شد و اصلاح شد (${o.revOk} از ${o.revTotal} جفت بند صعودی)"
                o.rawTotal > 0 -> "درست (${o.rawOk} از ${o.rawTotal} جفت بند صعودی)"
                else -> "بند شماره داری پیدا نشد"
            }
            val info = listOf(
                "صفحه ها: ${pages.size} | صفحه های دارای متن: $withText | تکه ها: ${chunks.size} | بندهای شماره دار: ${chunks.count { it.clause.isNotEmpty() }}",
                "جهت شماره بندها: $orientationText",
                "شماره صفحه چاپی: " + (result.printedOffset?.let { "فاصله ثابت $it (صفحه چاپی = صفحه فایل منهای $it)" } ?: "تشخیص داده نشد"),
                "سرصفحه های تکراری حذف شده: ${result.headerCount}",
                "روش استخراج: مبتنی بر موقعیت حروف (ترتیب راست به چپ از روی مختصات) روی ${methods.count { it == "PDF_GLYPHS" }} صفحه؛ متن خام روی ${methods.count { it == "PDF_TEXT" }} صفحه؛ OCR روی ${methods.count { it == "OCR" }} صفحه"
            ).joinToString("\n").toPersianDigits()

            dao.update(
                latest.copy(
                    ingestStatus = IngestStatus.DONE,
                    ingestInfo = info,
                    printedOffset = result.printedOffset,
                    clauseReversed = result.orientation.reversed,
                    pagesWithText = withText,
                    chunkCount = chunks.size,
                    ingestedAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
            )
            null
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                dao.byId(docId)?.let { dao.update(it.copy(ingestStatus = IngestStatus.NOT_PROCESSED, ingestInfo = "پردازش متوقف شد", updatedAt = System.currentTimeMillis())) }
            }
            throw e
        } catch (e: Exception) {
            val message = ("خطا در پردازش: " + (e.message ?: e.javaClass.simpleName)).take(200)
            dao.byId(docId)?.let { dao.update(it.copy(ingestStatus = IngestStatus.FAILED, ingestInfo = message, updatedAt = System.currentTimeMillis())) }
            message
        }
    }
}
