package ir.navid.app.ai.model

import android.content.Context

enum class ModelProvider(val labelFa: String) {
    NONE("بدون مدل"),
    LOCAL("مدل محلی روی گوشی"),
    EXTERNAL("سرویس بیرونی (با اجازه شما)"),
    LOCAL_SERVER("سرور محلی روی همین گوشی (llama.cpp، سازگار با OpenAI)")
}

data class ModelRequest(
    val system: String,
    val user: String,
    val maxTokens: Int = 700,
    val temperature: Double = 0.0
)

sealed interface ModelResult {
    data class Ok(val text: String, val millis: Long) : ModelResult
    data class Error(val message: String) : ModelResult
}

/** رابط مشترک همه مدل ها؛ برنامه به هیچ مدل مشخصی وابسته نیست و کتابخانه منابع مستقل از آن است. */
interface LanguageModel {
    val name: String
    suspend fun generate(request: ModelRequest): ModelResult
    fun close() {}
}

/**
 * مدل محلی (LiteRT-LM) فقط در APK آزمایشی (با پارامتر -PlocalModel=true) کامپایل می شود تا کتابخانه ناشناخته
 * ساخت پایدار را خراب نکند؛ بنابراین با بازتاب بارگذاری می شود. در APK پایدار نتیجه null است.
 */
data class LocalModelCreation(val model: LanguageModel?, val error: String?)

object LocalModelFactory {
    private const val CLASS_NAME = "ir.navid.app.ai.model.LiteRtLocalModel"

    fun isAvailable(): Boolean = try {
        Class.forName(CLASS_NAME)
        true
    } catch (e: Throwable) {
        false
    }

    /** هیچ خطایی بیرون نمی دهد؛ علت شکست (کتابخانه، فایل، حافظه) به صورت متن برمی گردد. */
    fun create(context: Context, modelPath: String): LocalModelCreation = try {
        val cls = Class.forName(CLASS_NAME)
        val model = cls.getConstructor(String::class.java, String::class.java)
            .newInstance(modelPath, context.cacheDir.path) as LanguageModel
        LocalModelCreation(model, null)
    } catch (e: ClassNotFoundException) {
        LocalModelCreation(null, "این APK کتابخانه مدل محلی (LiteRT-LM) را ندارد؛ نسخه NAVID-debug-full.apk یا NAVID-debug-local.apk را نصب کنید.")
    } catch (t: Throwable) {
        val cause = t.cause ?: t
        LocalModelCreation(null, "راه اندازی مدل محلی شکست خورد: ${cause.javaClass.simpleName}: ${(cause.message ?: "").take(200)}")
    }
}

/** سرور محلی فقط وقتی «روی همین گوشی» حساب می شود که آدرسش loopback باشد؛ وگرنه داده از گوشی خارج می شود. */
object UrlPolicy {
    fun isLoopback(url: String): Boolean {
        val host = try {
            java.net.URI(url.trim()).host?.lowercase()
        } catch (e: Exception) {
            null
        }
        return host == "127.0.0.1" || host == "localhost" || host == "[::1]" || host == "::1"
    }
}
