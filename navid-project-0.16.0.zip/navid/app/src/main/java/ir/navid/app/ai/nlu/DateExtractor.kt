package ir.navid.app.ai.nlu

import ir.navid.app.core.JalaliDate
import java.time.DayOfWeek

data class DateMatch(val date: JalaliDate?, val hour: Int?, val minute: Int?) {
    val hasTime: Boolean get() = hour != null && minute != null
}

/**
 * استخراج تاریخ و ساعت از متن فارسی با کد.
 * پشتیبانی: امروز، فردا، دیروز، پس فردا، پریروز، نام روز هفته (نزدیک ترین روز بعد از امروز)،
 * تاریخ کامل 1405/08/09، «15 آذر» با سال اختیاری، «N روز دیگر/پیش»، و ساعت (رقمی یا حروفی با صبح/ظهر/عصر/شب).
 * پشتیبانی نشده (خروجی خالی): «هفته بعد»، «N هفته دیگر»، «ماه بعد».
 */
object DateExtractor {
    private val months = mapOf(
        "فروردین" to 1, "اردیبهشت" to 2, "خرداد" to 3, "تیر" to 4, "مرداد" to 5, "شهریور" to 6,
        "مهر" to 7, "آبان" to 8, "آذر" to 9, "دی" to 10, "بهمن" to 11, "اسفند" to 12
    )

    // ترتیب مهم است: نام های بلندتر اول.
    private val weekdays: List<Pair<String, DayOfWeek>> = listOf(
        "یکشنبه" to DayOfWeek.SUNDAY, "یک شنبه" to DayOfWeek.SUNDAY,
        "دوشنبه" to DayOfWeek.MONDAY, "دو شنبه" to DayOfWeek.MONDAY,
        "سه شنبه" to DayOfWeek.TUESDAY,
        "چهارشنبه" to DayOfWeek.WEDNESDAY, "چهار شنبه" to DayOfWeek.WEDNESDAY,
        "پنجشنبه" to DayOfWeek.THURSDAY, "پنج شنبه" to DayOfWeek.THURSDAY,
        "جمعه" to DayOfWeek.FRIDAY,
        "شنبه" to DayOfWeek.SATURDAY
    )

    private val smallWords = linkedMapOf(
        "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5,
        "شش" to 6, "هفت" to 7, "هشت" to 8, "نه" to 9, "ده" to 10
    )

    private fun word(alts: List<String>): Regex =
        Regex(NOT_LETTER_BEFORE + "(?:" + alts.joinToString("|") + ")" + NOT_LETTER_AFTER)

    private fun validJalali(y: Int, m: Int, d: Int): Boolean =
        y in 1200..1600 && m in 1..12 && d >= 1 && d <= JalaliDate.daysInMonth(y, m)

    private fun plusDays(j: JalaliDate, n: Long): JalaliDate =
        JalaliDate.from(j.toLocalDate().plusDays(n))

    private val explicitRegex = Regex(NOT_LETTER_BEFORE + "(\\d{4})[/-](\\d{1,2})[/-](\\d{1,2})" + NOT_LETTER_AFTER)
    private val monthAlt = months.keys.sortedByDescending { it.length }.joinToString("|")
    private val dayMonthRegex = Regex(NOT_LETTER_BEFORE + "(\\d{1,2}) (" + monthAlt + ")(?: (\\d{4}))?" + NOT_LETTER_AFTER)
    private val relativeWords = listOf("پس ?فردا" to 2L, "پریروز" to -2L, "امروز" to 0L, "دیروز" to -1L, "فردا" to 1L)
    private val relativeRegexes = relativeWords.map { word(listOf(it.first)) to it.second }
    private val daysOffsetRegex = Regex(
        NOT_LETTER_BEFORE + "(" + (smallWords.keys.toList() + listOf("\\d{1,3}")).joinToString("|") +
            ") روز (دیگر|بعد|آینده|پیش|قبل)" + NOT_LETTER_AFTER
    )
    private val weekdayRegex = word(weekdays.map { it.first })
    private val periodAlt = "صبح|ظهر|عصر|شب|بعد ?از ?ظهر"
    private val timeDigitsRegex = Regex(
        NOT_LETTER_BEFORE + "ساعت (\\d{1,2})(?::(\\d{2}))?(?: (و نیم|و ربع))?(?: ($periodAlt))?" + NOT_LETTER_AFTER
    )
    private val hourWords = smallWords.keys.sortedByDescending { it.length } + listOf("یازده", "دوازده")
    private val timeWordsRegex = Regex(
        NOT_LETTER_BEFORE + "ساعت (" + hourWords.joinToString("|") + ")(?: (و نیم|و ربع))?(?: ($periodAlt))?" + NOT_LETTER_AFTER
    )

    fun extract(norm: String, today: JalaliDate): DateMatch {
        var date: JalaliDate? = null

        explicitRegex.find(norm)?.let { m ->
            val y = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            val d = m.groupValues[3].toInt()
            if (validJalali(y, mo, d)) date = JalaliDate(y, mo, d)
        }

        if (date == null) {
            dayMonthRegex.find(norm)?.let { m ->
                val y = if (m.groupValues[3].isNotEmpty()) m.groupValues[3].toInt() else today.year
                val d = m.groupValues[1].toInt()
                val mo = months.getValue(m.groupValues[2])
                if (validJalali(y, mo, d)) date = JalaliDate(y, mo, d)
            }
        }

        if (date == null) {
            var bestStart = -1
            var bestOffset = 0L
            for ((regex, offset) in relativeRegexes) {
                val mm = regex.find(norm)
                if (mm != null && (bestStart < 0 || mm.range.first < bestStart)) {
                    bestStart = mm.range.first
                    bestOffset = offset
                }
            }
            if (bestStart >= 0) date = plusDays(today, bestOffset)
        }

        if (date == null) {
            daysOffsetRegex.find(norm)?.let { m ->
                val raw = m.groupValues[1]
                val n = (smallWords[raw] ?: raw.toInt()).toLong()
                val sign = if (m.groupValues[2] in listOf("دیگر", "بعد", "آینده")) 1L else -1L
                date = plusDays(today, sign * n)
            }
        }

        if (date == null) {
            weekdayRegex.find(norm)?.let { m ->
                val target = weekdays.first { it.first == m.value }.second
                var delta = (target.value - today.toLocalDate().dayOfWeek.value + 7) % 7
                if (delta == 0) delta = 7
                date = plusDays(today, delta.toLong())
            }
        }

        // ساعت
        var hour: Int? = null
        var minute = 0
        var extra: String? = null
        var period: String? = null
        val md = timeDigitsRegex.find(norm)
        if (md != null) {
            hour = md.groupValues[1].toInt()
            if (md.groupValues[2].isNotEmpty()) minute = md.groupValues[2].toInt()
            extra = md.groupValues[3].ifEmpty { null }
            period = md.groupValues[4].ifEmpty { null }
        } else {
            val mw = timeWordsRegex.find(norm)
            if (mw != null) {
                val wd = mw.groupValues[1]
                hour = when (wd) {
                    "یازده" -> 11
                    "دوازده" -> 12
                    else -> smallWords.getValue(wd)
                }
                extra = mw.groupValues[2].ifEmpty { null }
                period = mw.groupValues[3].ifEmpty { null }
            }
        }
        var time: Pair<Int, Int>? = null
        if (hour != null) {
            var h: Int = hour
            if (extra == "و نیم") minute = 30 else if (extra == "و ربع") minute = 15
            if (period != null) {
                val p = period.replace(" ", "")
                if ((p == "عصر" || p == "بعدازظهر") && h in 1..11) {
                    h += 12
                } else if (p == "شب") {
                    if (h in 6..11) h += 12 else if (h == 12) h = 0
                } else if (p == "ظهر" && h in 1..4) {
                    h += 12
                }
            }
            if (h in 0..23 && minute in 0..59) time = Pair(h, minute)
        }
        return DateMatch(date, time?.first, time?.second)
    }

    /** قالب مقایسه برای مجموعه آزمون. */
    fun toGoldenString(norm: String, today: JalaliDate): String {
        val m = extract(norm, today)
        if (m.date == null && !m.hasTime) return "none"
        val ds = m.date?.format() ?: "-"
        val ts = if (m.hasTime) String.format(java.util.Locale.US, " %02d:%02d", m.hour, m.minute) else ""
        return ds + ts
    }
}
