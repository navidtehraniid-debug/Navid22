package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.navid.app.data.TransactionWithLines
import ir.navid.app.domain.AccountType

@Composable
fun FinanceScreen(
    vm: FinanceViewModel,
    onTxClick: (TransactionWithLines) -> Unit,
    onOpenTrash: () -> Unit,
    onManageAccounts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val summary by vm.monthSummary.collectAsState()
    val recent by vm.recent.collectAsState()
    val accounts by vm.accounts.collectAsState()
    val balances by vm.balances.collectAsState()
    val names = accounts.associate { it.id to it.name }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionCard("حساب ها") {
                accounts.filter { it.type == AccountType.ASSET }.forEach { acc ->
                    LabeledAmount(acc.name, balances[acc.id] ?: 0)
                }
                TextButton(onClick = onManageAccounts) { Text("مدیریت حساب ها") }
            }
        }
        item {
            SectionCard("خلاصه ${vm.monthTitle}") {
                LabeledAmount("درآمد", summary.income)
                LabeledAmount("هزینه", summary.expense)
                LabeledAmount("خالص", summary.net)
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("تراکنش ها (برای ویرایش یا حذف لمس کنید)")
                TextButton(onClick = onOpenTrash) { Text("سطل بازیافت") }
            }
        }
        if (recent.isEmpty()) {
            item { Text("هنوز تراکنشی ثبت نشده است.") }
        } else {
            items(recent, key = { it.tx.id }) { item -> TransactionRow(item, names, onClick = { onTxClick(item) }) }
        }
    }
}
