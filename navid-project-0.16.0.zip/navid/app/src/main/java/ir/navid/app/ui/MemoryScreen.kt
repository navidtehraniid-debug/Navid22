package ir.navid.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.toPersianDigits
import ir.navid.app.data.MemoryEntity
import ir.navid.app.domain.MemoryCategory
import ir.navid.app.domain.Trash
import java.time.Instant
import java.time.ZoneId

private fun dateOf(millis: Long): String =
    JalaliDate.from(Instant.ofEpochMilli(millis).atZone(ZoneId.of("Asia/Tehran")).toLocalDate())
        .format().toPersianDigits()

@Composable
fun MemoryScreen(
    vm: MemoryViewModel,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (MemoryEntity) -> Unit,
    onOpenTrash: () -> Unit,
    modifier: Modifier = Modifier
) {
    val items by vm.items.collectAsState()
    val query by vm.query.collectAsState()
    val category by vm.category.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("بازگشت") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onOpenTrash) { Text("سطل بازیافت") }
                Button(onClick = onAdd) { Text("افزودن") }
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { vm.query.value = it },
            label = { Text("جست وجو در عنوان و متن") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CategoryButton("همه", category == null) { vm.category.value = null }
            MemoryCategory.values().forEach { c ->
                CategoryButton(c.labelFa, category == c) { vm.category.value = c }
            }
        }
        if (items.isEmpty()) {
            Text("موردی پیدا نشد. با دکمه «افزودن» یک یادداشت یا حافظه جدید بسازید.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { m -> MemoryCard(m) { onEdit(m) } }
            }
        }
    }
}

@Composable
private fun CategoryButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

@Composable
private fun MemoryCard(m: MemoryEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(m.title, style = MaterialTheme.typography.titleSmall)
            Text(m.content, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            Text(
                "${m.category.labelFa}  •  ${dateOf(m.updatedAt)}  •  منبع: ثبت دستی",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
fun MemoryDialog(
    editing: MemoryEntity?,
    defaultCategory: MemoryCategory,
    vm: MemoryViewModel,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(editing?.title ?: "") }
    var content by remember { mutableStateOf(editing?.content ?: "") }
    var category by remember { mutableStateOf(editing?.category ?: defaultCategory) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing != null) "ویرایش" else "مورد جدید") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان (اختیاری)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it; error = null },
                    label = { Text("متن") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("دسته", style = MaterialTheme.typography.labelLarge)
                MemoryCategory.values().forEach { c ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { category = c },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = category == c, onClick = { category = c })
                        Text(c.labelFa)
                    }
                }
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.save(editing?.id, category, title, content) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("ذخیره") }
        },
        dismissButton = {
            Row {
                if (editing != null) {
                    TextButton(onClick = {
                        vm.delete(editing.id)
                        onDismiss()
                    }) { Text("سطل بازیافت") }
                }
                TextButton(onClick = onDismiss) { Text("انصراف") }
            }
        }
    )
}

@Composable
fun MemoryTrashDialog(vm: MemoryViewModel, onDismiss: () -> Unit) {
    val deleted by vm.deleted.collectAsState()
    var confirmId by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سطل بازیافت حافظه") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "موارد بعد از ${Trash.RETENTION_DAYS.toString().toPersianDigits()} روز برای همیشه پاک می شوند.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (deleted.isEmpty()) {
                    Text("سطل بازیافت خالی است.")
                } else {
                    deleted.forEach { m ->
                        Text(m.title, style = MaterialTheme.typography.titleSmall)
                        Text(m.content, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { vm.restore(m.id) }) { Text("بازیابی") }
                            TextButton(onClick = { confirmId = m.id }) { Text("حذف دائمی") }
                        }
                        Divider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )

    confirmId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmId = null },
            title = { Text("حذف دائمی؟") },
            text = { Text("این مورد برای همیشه پاک می شود و قابل بازگشت نیست.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePermanently(id)
                    confirmId = null
                }) { Text("حذف دائمی") }
            },
            dismissButton = { TextButton(onClick = { confirmId = null }) { Text("انصراف") } }
        )
    }
}
