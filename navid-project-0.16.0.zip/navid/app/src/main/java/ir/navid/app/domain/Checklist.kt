package ir.navid.app.domain

enum class CheckStatus(val labelFa: String) {
    PENDING("بررسی نشده"),
    APPROVED("تأیید"),
    REJECTED("عدم تأیید"),
    NEEDS_REVIEW("نیازمند بررسی"),
    NOT_APPLICABLE("قابل اجرا نیست")
}

data class ChecklistSummary(
    val total: Int,
    val approved: Int,
    val rejected: Int,
    val needsReview: Int,
    val notApplicable: Int,
    val pending: Int
) {
    /** درصد موارد بررسی شده (هر وضعیتی جز «بررسی نشده»). */
    val checkedPercent: Int get() = if (total == 0) 0 else Math.round((total - pending) * 100f / total)
}

object ChecklistMath {
    fun summarize(statuses: List<CheckStatus>): ChecklistSummary = ChecklistSummary(
        total = statuses.size,
        approved = statuses.count { it == CheckStatus.APPROVED },
        rejected = statuses.count { it == CheckStatus.REJECTED },
        needsReview = statuses.count { it == CheckStatus.NEEDS_REVIEW },
        notApplicable = statuses.count { it == CheckStatus.NOT_APPLICABLE },
        pending = statuses.count { it == CheckStatus.PENDING }
    )
}

object ChecklistParser {
    private val bullet = Regex("^\\s*(?:[-\u2022*\u00B7]+|[0-9\u06F0-\u06F9]+\\s*[-.)\u060C:])\\s*")

    /** هر خط یک مورد؛ نشانه فهرست (- • *) و شماره ابتدای خط (1. یا ۱-) حذف می شود. */
    fun parseItems(text: String, maxItems: Int = 200, maxLen: Int = 300): List<String> {
        val out = ArrayList<String>()
        for (raw in text.split("\n")) {
            val t = bullet.replace(raw, "").trim()
            if (t.isEmpty()) continue
            out.add(t.take(maxLen))
            if (out.size >= maxItems) break
        }
        return out
    }
}

/** قالب نمونه فقط از فهرست خود کاربر ساخته شده؛ بدون عدد و حد مجاز، و هنوز به منبع کتابخانه وصل نشده است. */
object SampleChecklists {
    const val CONCRETE_TITLE = "بتن ریزی (نمونه شما)"
    val concretePouring: List<String> = listOf(
        "بررسی مجوز و شرایط شروع عملیات",
        "کنترل آماده بودن قالب ها",
        "کنترل آرماتورها و اسپیسرها",
        "کنترل تمیزی محل بتن ریزی",
        "بررسی مشخصات بتن سفارش داده شده",
        "کنترل مدارک و نتایج آزمایش",
        "کنترل نحوه بتن ریزی و تراکم",
        "کنترل عمل آوری",
        "ثبت حجم بتن مصرفی"
    )
}
