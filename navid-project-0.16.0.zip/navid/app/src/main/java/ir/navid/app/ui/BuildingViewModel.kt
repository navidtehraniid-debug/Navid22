package ir.navid.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.navid.app.core.JalaliDate
import ir.navid.app.core.parseAmount
import ir.navid.app.core.toLatinDigits
import ir.navid.app.data.AppDatabase
import ir.navid.app.data.BuildingRepository
import ir.navid.app.data.PhaseEntity
import ir.navid.app.data.ProjectEntity
import ir.navid.app.data.SiteReportEntity
import ir.navid.app.domain.PhaseStatus
import ir.navid.app.domain.ProjectMath
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProjectSummary(
    val progress: Int,
    val cost: Long,
    val remaining: Long,
    val usedPercent: Int?
)

class BuildingViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    private val repo = BuildingRepository(db.buildingDao())

    val projects: StateFlow<List<ProjectEntity>> =
        repo.projects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val phases: StateFlow<List<PhaseEntity>> =
        repo.phases().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<SiteReportEntity>> =
        repo.reports().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** خلاصه هر پروژه: پیشرفت (میانگین مراحل)، هزینه واقعی از تراکنش های متصل به پروژه، بودجه باقی مانده. */
    val summaries: StateFlow<Map<String, ProjectSummary>> =
        combine(repo.projects(), repo.phases(), db.financeDao().observeProjectCosts()) { projectList, phaseList, costs ->
            projectList.associate { p ->
                val cost = costs.firstOrNull { it.projectId == p.id }?.cost ?: 0L
                val progress = ProjectMath.progress(phaseList.filter { it.projectId == p.id }.map { it.progressPct })
                p.id to ProjectSummary(
                    progress = progress,
                    cost = cost,
                    remaining = ProjectMath.remaining(p.initialBudget, cost),
                    usedPercent = ProjectMath.usedPercent(p.initialBudget, cost)
                )
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    private fun optionalDouble(text: String): Pair<Double?, Boolean> {
        val t = text.toLatinDigits().trim()
        if (t.isEmpty()) return Pair(null, true)
        val v = t.toDoubleOrNull()
        return if (v == null || v <= 0.0 || v > 1_000_000.0) Pair(null, false) else Pair(v, true)
    }

    fun createProject(
        name: String,
        address: String,
        landText: String,
        builtText: String,
        floorsText: String,
        structure: String,
        budgetText: String,
        onResult: (String?) -> Unit
    ) {
        val (land, landOk) = optionalDouble(landText)
        if (!landOk) {
            onResult("متراژ زمین نامعتبر است")
            return
        }
        val (built, builtOk) = optionalDouble(builtText)
        if (!builtOk) {
            onResult("زیربنا نامعتبر است")
            return
        }
        val floorsClean = floorsText.toLatinDigits().trim()
        val floors = if (floorsClean.isEmpty()) null else floorsClean.toIntOrNull()
        if (floorsClean.isNotEmpty() && floors == null) {
            onResult("تعداد طبقات نامعتبر است")
            return
        }
        val budgetClean = budgetText.toLatinDigits().trim()
        val budget: Long = when {
            budgetClean.isEmpty() || budgetClean == "0" -> 0L
            else -> parseAmount(budgetText) ?: run {
                onResult("بودجه نامعتبر است")
                return
            }
        }
        viewModelScope.launch {
            onResult(repo.createProject(name, address, land, built, floors, structure, budget))
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch { repo.deleteProject(id) }
    }

    fun updatePhase(phaseId: String, status: PhaseStatus, progressText: String, notes: String, onResult: (String?) -> Unit) {
        val parsed = progressText.toLatinDigits().trim().toIntOrNull()
        if (status == PhaseStatus.IN_PROGRESS && (parsed == null || parsed !in 1..99)) {
            onResult("درصد پیشرفت را بین 1 تا 99 وارد کنید")
            return
        }
        viewModelScope.launch { onResult(repo.updatePhase(phaseId, status, parsed ?: 0, notes)) }
    }

    fun addReport(projectId: String, phaseId: String?, dateText: String, text: String, onResult: (String?) -> Unit) {
        val date = JalaliDate.parse(dateText)
        if (date == null) {
            onResult("تاریخ شمسی را به شکل 1405/08/09 وارد کنید")
            return
        }
        viewModelScope.launch { onResult(repo.addReport(projectId, phaseId, date, text)) }
    }

    fun deleteReport(id: String) {
        viewModelScope.launch { repo.deleteReport(id) }
    }
}
