package ir.navid.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {

    @Query(
        "SELECT * FROM memories WHERE deletedAt IS NULL " +
            "AND (:category IS NULL OR category = :category) " +
            "AND (:query = '' OR title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%') " +
            "ORDER BY updatedAt DESC"
    )
    fun search(query: String, category: String?): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    fun observeDeleted(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE id = :id LIMIT 1")
    suspend fun byId(id: String): MemoryEntity?

    @Query("SELECT * FROM memories WHERE dedupeHash = :hash AND deletedAt IS NULL LIMIT 1")
    suspend fun findByHash(hash: String): MemoryEntity?

    @Insert
    suspend fun insert(memory: MemoryEntity)

    @Update
    suspend fun update(memory: MemoryEntity)

    @Query("UPDATE memories SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    suspend fun softDelete(id: String, at: Long)

    @Query("UPDATE memories SET deletedAt = NULL, updatedAt = :at WHERE id = :id")
    suspend fun restore(id: String, at: Long)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun hardDelete(id: String)

    @Query("DELETE FROM memories WHERE deletedAt IS NOT NULL AND deletedAt < :before")
    suspend fun purgeDeletedBefore(before: Long)
}
