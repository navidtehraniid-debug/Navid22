package ir.navid.app.knowledge.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** دیتابیس کتابخانه منابع؛ مستقل از دیتابیس اصلی (navid.db) تا بازسازی و پشتیبان گیری جدا باشد. */
@Database(
    entities = [LibDocumentEntity::class, LibPageEntity::class, LibChunkEntity::class],
    version = 4,
    exportSchema = false
)
abstract class KnowledgeDatabase : RoomDatabase() {
    abstract fun libDocumentDao(): LibDocumentDao

    companion object {
        @Volatile
        private var instance: KnowledgeDatabase? = null

        /** نسخه 1 به 2: ستون های پردازش متن، جدول صفحه ها و تکه ها. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `ingestInfo` TEXT")
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `printedOffset` INTEGER")
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `clauseReversed` INTEGER")
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `pagesWithText` INTEGER")
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `chunkCount` INTEGER")
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `ingestedAt` INTEGER")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `lib_pages` (" +
                        "`docId` TEXT NOT NULL, " +
                        "`pageNo` INTEGER NOT NULL, " +
                        "`text` TEXT NOT NULL, " +
                        "`printedPage` INTEGER, " +
                        "`quality` REAL NOT NULL, " +
                        "`method` TEXT NOT NULL, " +
                        "PRIMARY KEY(`docId`, `pageNo`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `lib_chunks` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`docId` TEXT NOT NULL, " +
                        "`pageFrom` INTEGER NOT NULL, " +
                        "`pageTo` INTEGER NOT NULL, " +
                        "`chapter` TEXT NOT NULL, " +
                        "`clause` TEXT NOT NULL, " +
                        "`heading` TEXT NOT NULL, " +
                        "`text` TEXT NOT NULL, " +
                        "`tokenCount` INTEGER NOT NULL)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_lib_chunks_docId` ON `lib_chunks` (`docId`)")
            }
        }

        /** نسخه 2 به 3: مختصات نوار برجسته سازی هر تکه. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `lib_chunks` ADD COLUMN `hlTop` REAL")
                db.execSQL("ALTER TABLE `lib_chunks` ADD COLUMN `hlBottom` REAL")
            }
        }

        /** نسخه 3 به 4: اجازه ارسال هر سند به سرویس بیرونی. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `lib_documents` ADD COLUMN `externalOk` INTEGER")
            }
        }

        /** جدول FTS4 دستی (خارج از Room) است تا اعتبارسنجی ساختار Room با آن درگیر نشود؛ ایندکس قابل بازسازی است. */
        private val callback = object : RoomDatabase.Callback() {
            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS lib_chunks_fts USING fts4(text_search, tokenize=unicode61)")
            }
        }

        fun get(context: Context): KnowledgeDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    KnowledgeDatabase::class.java,
                    "navid_knowledge.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).addCallback(callback).build().also { instance = it }
            }
    }
}
