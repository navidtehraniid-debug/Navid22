package ir.navid.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class FinanceDao {

    @Query("SELECT COUNT(*) FROM accounts")
    abstract suspend fun accountCount(): Int

    @Insert
    abstract suspend fun insertAccounts(accounts: List<AccountEntity>)

    @Query("SELECT * FROM accounts WHERE deletedAt IS NULL AND archived = 0 ORDER BY sortOrder")
    abstract fun observeAccounts(): Flow<List<AccountEntity>>

    @Insert
    abstract suspend fun insertAccount(account: AccountEntity)

    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM accounts")
    abstract suspend fun maxSortOrder(): Int

    @Query("SELECT COUNT(*) FROM accounts WHERE type = :type AND name = :name AND deletedAt IS NULL")
    abstract suspend fun countByName(type: String, name: String): Int

    @Query("UPDATE accounts SET name = :name WHERE id = :id")
    abstract suspend fun renameAccount(id: String, name: String)

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    abstract suspend fun accountById(id: String): AccountEntity?

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    abstract suspend fun txById(id: String): TransactionEntity?

    @Insert
    abstract suspend fun insertTransaction(tx: TransactionEntity)

    @Insert
    abstract suspend fun insertLines(lines: List<LineEntity>)

    @Transaction
    open suspend fun insertTransactionWithLines(tx: TransactionEntity, lines: List<LineEntity>) {
        insertTransaction(tx)
        insertLines(lines)
    }

    @Query("DELETE FROM transaction_lines WHERE transactionId = :txId")
    abstract suspend fun deleteLines(txId: String)

    @Query("UPDATE transactions SET localDate = :localDate, description = :description, projectId = :projectId, updatedAt = :at WHERE id = :id")
    abstract suspend fun updateMeta(id: String, localDate: String, description: String, projectId: String?, at: Long)

    @Transaction
    open suspend fun replaceLines(
        txId: String,
        lines: List<LineEntity>,
        localDate: String,
        description: String,
        projectId: String?,
        at: Long
    ) {
        deleteLines(txId)
        insertLines(lines)
        updateMeta(txId, localDate, description, projectId, at)
    }

    @Query("UPDATE transactions SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    abstract suspend fun softDelete(id: String, at: Long)

    @Query("UPDATE transactions SET deletedAt = NULL, updatedAt = :at WHERE id = :id")
    abstract suspend fun restore(id: String, at: Long)

    @Query("DELETE FROM transactions WHERE id = :id")
    abstract suspend fun hardDelete(id: String)

    @Query("DELETE FROM transactions WHERE deletedAt IS NOT NULL AND deletedAt < :before")
    abstract suspend fun purgeDeletedBefore(before: Long)

    @Transaction
    @Query(
        "SELECT * FROM transactions WHERE deletedAt IS NULL AND status != 'VOID' " +
            "ORDER BY localDate DESC, createdAt DESC LIMIT :limit"
    )
    abstract fun observeRecent(limit: Int): Flow<List<TransactionWithLines>>

    @Transaction
    @Query("SELECT * FROM transactions WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    abstract fun observeDeleted(): Flow<List<TransactionWithLines>>

    @Query(
        "SELECT a.type AS accountType, COALESCE(SUM(l.debit), 0) AS debit, COALESCE(SUM(l.credit), 0) AS credit " +
            "FROM transaction_lines l " +
            "JOIN transactions t ON t.id = l.transactionId " +
            "JOIN accounts a ON a.id = l.accountId " +
            "WHERE t.status = 'CONFIRMED' AND t.dataClass = 'ACTUAL' AND t.deletedAt IS NULL " +
            "AND t.localDate BETWEEN :fromDate AND :toDate " +
            "GROUP BY a.type"
    )
    abstract fun observeTotalsByType(fromDate: String, toDate: String): Flow<List<TypeTotals>>

    @Query(
        "SELECT l.accountId AS accountId, COALESCE(SUM(l.debit), 0) AS debit, COALESCE(SUM(l.credit), 0) AS credit " +
            "FROM transaction_lines l " +
            "JOIN transactions t ON t.id = l.transactionId " +
            "WHERE t.status = 'CONFIRMED' AND t.dataClass = 'ACTUAL' AND t.deletedAt IS NULL " +
            "GROUP BY l.accountId"
    )
    abstract fun observeAccountTotals(): Flow<List<AccountTotals>>

    @Query(
        "SELECT t.projectId AS projectId, COALESCE(SUM(l.debit), 0) AS cost " +
            "FROM transaction_lines l " +
            "JOIN transactions t ON t.id = l.transactionId " +
            "JOIN accounts a ON a.id = l.accountId " +
            "WHERE t.projectId IS NOT NULL AND t.status = 'CONFIRMED' AND t.dataClass = 'ACTUAL' " +
            "AND t.deletedAt IS NULL AND a.type = 'EXPENSE' " +
            "GROUP BY t.projectId"
    )
    abstract fun observeProjectCosts(): Flow<List<ProjectCost>>
}
