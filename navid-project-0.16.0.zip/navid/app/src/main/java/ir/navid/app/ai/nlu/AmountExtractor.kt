package ir.navid.app.ai.nlu

import java.math.BigDecimal

/** هشدارهایی که باعث می شود مبلغ استخراج شده بدون تأیید صریح کاربر استفاده نشود. */
enum class AmountFlag { RANGE, APPROX, RELATIVE, TRAILING }

data class AmountMatch(val value: Long, val flags: Set<AmountFlag>)

/**
 * استخراج مبلغ (تومان) از متن فارسی با کد، بدون مدل زبانی.
 * ریال به تومان تبدیل می شود. عدد بدون واحد و بدون «هزار/میلیون/میلیارد» فقط اگر 4 رقم یا بیشتر باشد (و شبیه سال یا شماره نباشد) پذیرفته می شود.
 */
object AmountExtractor {
    private val numWords: Map<String, Int> = mapOf(
        "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5, "شش" to 6, "هفت" to 7, "هشت" to 8, "نه" to 9,
        "ده" to 10, "یازده" to 11, "دوازده" to 12, "سیزده" to 13, "چهارده" to 14, "پانزده" to 15, "پونزده" to 15,
        "شانزده" to 16, "شونزده" to 16, "هفده" to 17, "هجده" to 18, "نوزده" to 19,
        "بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50, "شصت" to 60, "هفتاد" to 70, "هشتاد" to 80, "نود" to 90,
        "یکصد" to 100, "دویست" to 200, "سیصد" to 300, "چهارصد" to 400, "پانصد" to 500, "پونصد" to 500,
        "ششصد" to 600, "هفتصد" to 700, "هشتصد" to 800, "نهصد" to 900
    )
    private val mult: Map<String, BigDecimal> = mapOf(
        "هزار" to BigDecimal(1000),
        "میلیون" to BigDecimal(1000000), "ملیون" to BigDecimal(1000000),
        "میلیارد" to BigDecimal(1000000000), "ملیارد" to BigDecimal(1000000000)
    )
    private val tomanUnits = setOf("تومان", "تومن")
    private val rialUnits = setOf("ریال")
    private val approxWords = setOf("حدود", "تقریبا", "نزدیک", "بیش", "کمتر", "حداقل", "حداکثر")
    private val relativeWords = setOf("برابر", "درصد", "نصف")

    private val MAX_AMOUNT = BigDecimal("1000000000000000")
    private val HUNDRED = BigDecimal(100)
    private val HALF = BigDecimal("0.5")

    private data class Snap(
        val value: BigDecimal,
        val end: Int,
        val hasDigit: Boolean,
        val hasWord: Boolean,
        val hasMult: Boolean,
        val implicitOne: Boolean
    )

    private fun BigDecimal.isInteger(): Boolean = stripTrailingZeros().scale() <= 0
    private fun BigDecimal.modInt(n: Int): Int = remainder(BigDecimal(n)).toInt()

    private fun startsNumber(tok: String): Boolean =
        tok[0].isDigit() || numWords.containsKey(tok) || tok == "صد" || tok == "نیم"

    private fun parsePhrase(toks: List<Token>, i: Int): Snap? {
        var total = BigDecimal.ZERO
        var cur = BigDecimal.ZERO
        var lastMult: BigDecimal? = null
        var snap: Snap? = null
        var j = i
        var consumed = false
        var prevConn = false
        var hasDigit = false
        var hasWord = false
        var hasMult = false
        var implicitOne = false
        while (j < toks.size) {
            val t = toks[j].text
            if (t == "و") {
                if (!consumed) break
                prevConn = true
                j++
                continue
            }
            if (t[0].isDigit()) {
                if (cur.signum() != 0) break
                cur = BigDecimal(t)
                hasDigit = true
            } else if (t == "صد") {
                if (cur.signum() == 0 && total.signum() == 0 && !consumed) {
                    cur = HUNDRED
                } else if (cur.signum() == 0 && total.signum() > 0) {
                    cur = HUNDRED
                } else if (cur >= BigDecimal.ONE && cur <= BigDecimal(9) && !prevConn && cur.isInteger()) {
                    cur = cur.multiply(HUNDRED)
                } else {
                    break
                }
                hasWord = true
            } else if (numWords.containsKey(t)) {
                val v = numWords.getValue(t)
                if (cur.signum() == 0) {
                    cur = BigDecimal(v)
                } else if (!cur.isInteger()) {
                    break
                } else if (v >= 100) {
                    break
                } else if (v < 10) {
                    if (cur.modInt(10) == 0 && (cur.modInt(100) == 0 || cur.modInt(100) >= 20)) {
                        cur = cur.add(BigDecimal(v))
                    } else {
                        break
                    }
                } else {
                    if (cur.modInt(100) == 0 && cur >= HUNDRED) {
                        cur = cur.add(BigDecimal(v))
                    } else {
                        break
                    }
                }
                hasWord = true
            } else if (t == "نیم") {
                if (cur.signum() > 0 && cur.isInteger()) {
                    cur = cur.add(HALF)
                } else if (cur.signum() == 0 && total.signum() > 0 && lastMult != null) {
                    total = total.add(lastMult.divide(BigDecimal(2)))
                } else if (cur.signum() == 0 && total.signum() == 0 && !consumed) {
                    cur = HALF
                } else {
                    break
                }
                hasWord = true
            } else if (mult.containsKey(t)) {
                val m = mult.getValue(t)
                if (cur.signum() == 0) {
                    if (total.signum() == 0 && !consumed) {
                        cur = BigDecimal.ONE
                        implicitOne = true
                    } else if (total.signum() > 0 && prevConn && m.compareTo(BigDecimal(1000)) == 0 &&
                        lastMult != null && lastMult > BigDecimal(1000)
                    ) {
                        cur = BigDecimal.ONE
                    } else {
                        break
                    }
                }
                if (lastMult != null && m >= lastMult) break
                total = total.add(cur.multiply(m))
                cur = BigDecimal.ZERO
                lastMult = m
                hasMult = true
            } else {
                break
            }
            consumed = true
            prevConn = false
            j++
            if (total.signum() == 0 || cur.signum() == 0) {
                snap = Snap(total.add(cur), j, hasDigit, hasWord, hasMult, implicitOne)
            }
        }
        return snap
    }

    /** همه مبلغ های پیدا شده به ترتیب ظهور در متن نرمال شده. */
    fun extract(norm: String): List<AmountMatch> {
        val toks = TextNormalizer.tokenize(norm)
        val res = ArrayList<AmountMatch>()
        var i = 0
        while (i < toks.size) {
            val snap = parsePhrase(toks, i)
            if (snap == null) {
                i++
                continue
            }
            var end = snap.end
            val unit = if (end < toks.size) toks[end].text else null
            var accepted: BigDecimal? = null
            if (unit != null && unit in tomanUnits) {
                accepted = snap.value
                end++
            } else if (unit != null && unit in rialUnits) {
                val v = snap.value.divide(BigDecimal.TEN)
                accepted = if (v.isInteger()) v else null
                end++
            } else if (snap.hasMult && !snap.implicitOne) {
                accepted = snap.value
            } else if (snap.hasDigit && !snap.hasWord && !snap.hasMult) {
                val raw = toks[i].text
                val prev = if (i > 0) toks[i - 1].text else ""
                val v = snap.value
                if (v.isInteger() &&
                    v >= BigDecimal(1000) && v <= MAX_AMOUNT &&
                    !raw.startsWith("0") &&
                    !(raw.length == 4 && v >= BigDecimal(1300) && v <= BigDecimal(1500)) &&
                    raw.length <= 12 && prev != "ساعت"
                ) {
                    accepted = v
                }
            }
            if (accepted != null && accepted.isInteger() && accepted.signum() > 0 && accepted <= MAX_AMOUNT) {
                val flags = HashSet<AmountFlag>()
                val before = toks.subList(maxOf(0, i - 2), i).map { it.text }
                if (before.lastOrNull() == "تا") flags.add(AmountFlag.RANGE)
                if (before.any { it in approxWords }) flags.add(AmountFlag.APPROX)
                if (before.any { it in relativeWords } || (end < toks.size && toks[end].text in relativeWords)) {
                    flags.add(AmountFlag.RELATIVE)
                }
                if (end + 1 < toks.size && toks[end].text == "و" && startsNumber(toks[end + 1].text)) {
                    flags.add(AmountFlag.TRAILING)
                }
                res.add(AmountMatch(accepted.toLong(), flags))
                i = end
            } else {
                i++
            }
        }
        return res
    }

    /** قالب مقایسه برای مجموعه آزمون: مقدار[!پرچم،پرچم] با جداکننده «|». */
    fun toGoldenString(norm: String): String {
        val r = extract(norm)
        if (r.isEmpty()) return "none"
        return r.joinToString("|") { m ->
            if (m.flags.isEmpty()) m.value.toString()
            else m.value.toString() + "!" + m.flags.map { it.name }.sorted().joinToString(",")
        }
    }
}
