package ir.navid.app.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import ir.navid.app.domain.AccountType
import ir.navid.app.domain.DataClass
import ir.navid.app.domain.LedgerKind
import ir.navid.app.domain.TxKind
import ir.navid.app.domain.TxSource
import ir.navid.app.domain.TxStatus

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val ledger: LedgerKind,
    val name: String,
    val type: AccountType,
    val subtype: String,
    val currency: String = "IRT",
    val openingBalance: Long = 0,
    val archived: Boolean = false,
    val sortOrder: Int = 0,
    val deletedAt: Long? = null
)

@Entity(tableName = "transactions", indices = [Index("localDate")])
data class TransactionEntity(
    @PrimaryKey val id: String,
    val ledger: LedgerKind,
    val occurredAt: Long,
    val localDate: String,
    val kind: TxKind,
    val dataClass: DataClass,
    val status: TxStatus,
    val description: String,
    val source: TxSource,
    val createdAt: Long,
    val updatedAt: Long,
    val deletedAt: Long? = null,
    val projectId: String? = null
)

@Entity(
    tableName = "transaction_lines",
    foreignKeys = [
        ForeignKey(
            entity = TransactionEntity::class,
            parentColumns = ["id"],
            childColumns = ["transactionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("transactionId"), Index("accountId")]
)
data class LineEntity(
    @PrimaryKey val id: String,
    val transactionId: String,
    val accountId: String,
    val debit: Long,
    val credit: Long
)

data class TransactionWithLines(
    @Embedded val tx: TransactionEntity,
    @Relation(parentColumn = "id", entityColumn = "transactionId")
    val lines: List<LineEntity>
)

data class TypeTotals(
    val accountType: AccountType,
    val debit: Long,
    val credit: Long
)

data class AccountTotals(
    val accountId: String,
    val debit: Long,
    val credit: Long
)

fun TransactionWithLines.amount(): Long = lines.sumOf { it.debit }

/** هزینه: حساب پرداخت. درآمد: حساب دریافت. انتقال: حساب مبدأ. */
fun TransactionWithLines.primaryAccountId(): String? = when (tx.kind) {
    TxKind.EXPENSE, TxKind.TRANSFER -> lines.firstOrNull { it.credit > 0 }?.accountId
    TxKind.INCOME -> lines.firstOrNull { it.debit > 0 }?.accountId
}

/** هزینه: حساب دسته. درآمد: حساب درآمد. انتقال: حساب مقصد. */
fun TransactionWithLines.counterAccountId(): String? = when (tx.kind) {
    TxKind.EXPENSE, TxKind.TRANSFER -> lines.firstOrNull { it.debit > 0 }?.accountId
    TxKind.INCOME -> lines.firstOrNull { it.credit > 0 }?.accountId
}
