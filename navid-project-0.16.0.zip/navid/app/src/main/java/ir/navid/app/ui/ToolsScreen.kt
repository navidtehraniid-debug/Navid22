package ir.navid.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ToolsScreen(
    onOpenMemory: () -> Unit,
    onOpenNlu: () -> Unit,
    onOpenReminders: () -> Unit,
    onOpenLibrary: () -> Unit,
    onOpenAi: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("ابزارها", style = MaterialTheme.typography.headlineSmall)
        SectionCard("یادداشت ها و حافظه") {
            Text("یادداشت، اطلاعات شخصی، اهداف و سوابق را دسته بندی کنید، جست وجو کنید و ویرایش کنید.")
            Button(onClick = onOpenMemory) { Text("باز کردن") }
        }
        SectionCard("کتابخانه منابع") {
            Text("کتاب ها، مباحث مقررات ملی، نشریات و نقشه های خودتان را (PDF، عکس، Word، Excel) نگهداری و مشاهده کنید. برای PDF های دارای متن، استخراج متن و جست وجو با ارجاع به بند و صفحه هم هست.")
            Button(onClick = onOpenLibrary) { Text("باز کردن") }
        }
        SectionCard("مدل هوش مصنوعی") {
            Text("انتخاب مدل برای نوشتن پاسخ از روی منابع کتابخانه (سرویس بیرونی با اجازه شما، یا مدل محلی آزمایشی). همه قابلیت های اصلی بدون مدل هم کار می کنند.")
            Button(onClick = onOpenAi) { Text("باز کردن") }
        }
        SectionCard("تقویم شمسی و یادآوری ها") {
            Text("تقویم ماهانه، ثبت یادآوری با اعلان در زمان دقیق، و سه سطح اهمیت (فوری، مهم، عادی).")
            Button(onClick = onOpenReminders) { Text("باز کردن") }
        }
        SectionCard("آزمایش تحلیل جمله") {
            Text("جمله ای مثل «چهارصد هزار تومان بنزین زدم» بنویسید و ببینید نوع پیام، مبلغ و تاریخ چطور استخراج می شود. چیزی ثبت نمی شود.")
            Button(onClick = onOpenNlu) { Text("باز کردن") }
        }
        SectionCard("ابزارهای دیگر") {
            Text("ماشین حساب ها (مساحت، بتن، میلگرد، اقساط و ...) و مدیریت خرج کار Euromen هنوز پیاده سازی نشده اند (مرحله ۹).")
        }
    }
}
