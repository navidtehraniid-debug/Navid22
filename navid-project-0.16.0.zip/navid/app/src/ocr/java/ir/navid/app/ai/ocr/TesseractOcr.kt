package ir.navid.app.ai.ocr

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI

/** OCR فارسی با Tesseract4Android (Apache 2.0)؛ فقط در ساخت -Pocr=true کامپایل می شود. روی گوشی آزمایش نشده است. */
class TesseractOcr(context: Context) : OcrEngine {
    private val api = TessBaseAPI()

    init {
        if (!api.init(OcrData.dir(context).path, "fas")) {
            api.recycle()
            throw IllegalStateException("خواندن fas.traineddata ممکن نشد")
        }
    }

    override fun recognize(bitmap: Bitmap): String {
        api.setImage(bitmap)
        return api.utf8Text ?: ""
    }

    override fun close() {
        api.recycle()
    }
}
