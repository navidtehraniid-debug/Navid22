"""مرجع Python بازسازی سطرها از موقعیت نویسه ها (برای ساخت نمونه و خروجی مورد انتظار آزمون ها).
اجرا: python3 glyph_reference.py file.pdf out_dir"""
import re, sys, os, statistics, unicodedata, pdfplumber

CTRL = re.compile('[\u202a-\u202e\u200e\u200f\u2066-\u2069\u200d\ufeff]')
MARKS = re.compile('[\u064b-\u0652\u0640]')
BRACKETS = {"(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "\u00ab": "\u00bb", "\u00bb": "\u00ab", "<": ">", ">": "<"}
SEP = set("./,:\u066b\u066c")
SPACE_GAP = 0.12

def clean_line(t):
    t = unicodedata.normalize("NFKC", t)
    t = CTRL.sub("", t).replace("\u200c", " ")
    t = MARKS.sub("", t)
    t = (t.replace("\u064a", "\u06cc").replace("\u0643", "\u06a9").replace("\u06c0", "\u0647")
          .replace("\u0629", "\u0647").replace("\u0623", "\u0627").replace("\u0625", "\u0627"))
    t = "".join(chr(ord('0') + ord(c) - 0x06F0) if '\u06f0' <= c <= '\u06f9'
                else chr(ord('0') + ord(c) - 0x0660) if '\u0660' <= c <= '\u0669' else c for c in t)
    t = re.sub(r"[ \t]+", " ", t).strip()
    t = re.sub(r"^(\d+(?:-\d+)*)(?=[\u0600-\u06ff])", r"\1 ", t)
    return re.sub(r" \u060c(?=\S)", "\u060c ", t)

def ltr(c): return c.isdigit() or ("a" <= c.lower() <= "z" and c.isascii())

def to_logical(s):
    out = []; i = 0; n = len(s)
    while i < n:
        if ltr(s[i]):
            j = i
            while j < n and (ltr(s[j]) or (s[j] in SEP and j + 1 < n and j > i and ltr(s[j + 1]))): j += 1
            out.extend(reversed(s[i:j])); i = j
        else:
            out.append(s[i]); i += 1
    return "".join(out)

def glyphs_of(page):
    return [dict(text=c["text"], x=c["x0"], w=c["x1"] - c["x0"], base=page.height - c["matrix"][5], size=c["size"] or 10.0)
            for c in page.chars if c.get("upright", True) and c["text"]]

def lines_from(gs):
    if not gs: return []
    tol = 0.45 * statistics.median([g["size"] for g in gs])
    groups = []
    for g in sorted(gs, key=lambda g: g["base"]):
        if groups and abs(g["base"] - groups[-1]["cy"]) <= tol:
            L = groups[-1]; L["g"].append(g); L["cy"] = (L["cy"] * (len(L["g"]) - 1) + g["base"]) / len(L["g"])
        else: groups.append({"cy": g["base"], "g": [g]})
    res = []
    for L in groups:
        o = sorted(L["g"], key=lambda g: -(g["x"] + g["w"] / 2)); chars = []; prev = None
        for g in o:
            if prev and prev["text"].strip() and g["text"].strip() and prev["x"] - (g["x"] + g["w"]) > SPACE_GAP * max(prev["size"], g["size"]): chars.append(" ")
            chars.extend(unicodedata.normalize("NFKC", g["text"])); prev = g
        text = "".join(BRACKETS.get(c, c) for c in to_logical(chars))
        res.append((clean_line(text), min(g["base"] - g["size"] for g in o), max(g["base"] + 0.25 * g["size"] for g in o)))
    return [r for r in res if r[0]]

if __name__ == "__main__":
    pdf_path, out = sys.argv[1], sys.argv[2]
    pages = [10, 14, 15, 16, 17, 18, 19, 20, 21]; rows = []; gold = []
    with pdfplumber.open(pdf_path) as pdf:
        for pn in pages:
            p = pdf.pages[pn - 1]; rows.append(f"#PAGE\t{pn}\t{float(p.height):.2f}")
            gs = glyphs_of(p)
            for g in gs: rows.append("\t".join([g["text"], f'{g["x"]:.2f}', f'{g["w"]:.2f}', f'{g["base"]:.2f}', f'{g["size"]:.2f}']))
    open(os.path.join(out, "glyphs_mabhas4_p10_14_21.txt"), "w", encoding="utf-8").write("\n".join(rows) + "\n")
    cur = None; data = {}
    for ln in open(os.path.join(out, "glyphs_mabhas4_p10_14_21.txt"), encoding="utf-8").read().split("\n"):
        if not ln: continue
        f = ln.split("\t")
        if f[0] == "#PAGE": cur = int(f[1]); data[cur] = []
        else: data[cur].append(dict(text=f[0], x=float(f[1]), w=float(f[2]), base=float(f[3]), size=float(f[4])))
    for pn in (10, 20):
        gold.append(f"#PAGE {pn}"); gold += [l[0] for l in lines_from(data[pn])]
    open(os.path.join(out, "glyph_golden_p10_p20.txt"), "w", encoding="utf-8").write("\n".join(gold) + "\n")
    print("fixture KB", os.path.getsize(os.path.join(out, "glyphs_mabhas4_p10_14_21.txt")) // 1024, "| golden lines", len(gold))
    for ln in gold[:0]: pass
    l20 = lines_from(data[20]); print("p20 first body line:", l20[1][0][:50] if len(l20) > 1 else "")
    for t, top, bot in l20:
        if t.startswith("4-1-3-4") or t.startswith("4-1-5-1"): print(t[:24], "top %.3f bottom %.3f" % (top / 792.0, bot / 792.0))
