# Reference implementation of the NAVID NLU layer (mirrored in Kotlin).
import re, datetime
from decimal import Decimal

LETTER = '\u0621-\u063A\u0641-\u064A\u0671-\u06D3'
NOTL = '(?<![' + LETTER + 'A-Za-z])'
NOTL_AFTER = '(?![' + LETTER + 'A-Za-z])'
MAX_AMOUNT = Decimal(10) ** 15

# ---------- Jalali ----------
def g2j(gy, gm, gd):
    g = [0,31,59,90,120,151,181,212,243,273,304,334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + (365*gy) + ((gy2+3)//4) - ((gy2+99)//100) + ((gy2+399)//400) + gd + g[gm-1]
    jy = -1595 + (33*(days//12053)); days %= 12053
    jy += 4*(days//1461); days %= 1461
    if days > 365:
        jy += (days-1)//365; days = (days-1) % 365
    if days < 186: jm = 1 + days//31; jd = 1 + days % 31
    else: jm = 7 + (days-186)//30; jd = 1 + (days-186) % 30
    return jy, jm, jd

def j2g(jy, jm, jd):
    jy += 1595
    days = -355668 + (365*jy) + ((jy//33)*8) + (((jy % 33)+3)//4) + jd + ((jm-1)*31 if jm < 7 else ((jm-7)*30)+186)
    gy = 400*(days//146097); days %= 146097
    if days > 36524:
        days -= 1; gy += 100*(days//36524); days %= 36524
        if days >= 365: days += 1
    gy += 4*(days//1461); days %= 1461
    if days > 365:
        gy += (days-1)//365; days = (days-1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    s = [0,31,29 if leap else 28,31,30,31,30,31,31,30,31,30,31]
    gm = 0
    while gm < 13 and gd > s[gm]:
        gd -= s[gm]; gm += 1
    return gy, gm, gd

def is_leap(y):
    return (datetime.date(*j2g(y+1,1,1)) - datetime.date(*j2g(y,1,1))).days == 366

def dim(y, m):
    return 31 if m <= 6 else (30 if m <= 11 else (30 if is_leap(y) else 29))

def valid_jalali(y, m, d):
    return 1200 <= y <= 1600 and 1 <= m <= 12 and 1 <= d <= dim(y, m)

def jalali_plus(j, n):
    g = datetime.date(*j2g(*j)) + datetime.timedelta(days=n)
    return g2j(g.year, g.month, g.day)

def jalali_weekday(j):  # Monday=0 .. Sunday=6 (python)
    return datetime.date(*j2g(*j)).weekday()

# ---------- normalize ----------
def normalize(text):
    out = []
    for ch in text:
        if ch == '\u064A': ch = '\u06CC'
        elif ch == '\u0643': ch = '\u06A9'
        elif '\u06F0' <= ch <= '\u06F9': ch = chr(ord('0') + ord(ch) - 0x06F0)
        elif '\u0660' <= ch <= '\u0669': ch = chr(ord('0') + ord(ch) - 0x0660)
        elif ch == '\u200C': ch = ' '
        elif ch == '\u066B': ch = '.'
        elif ch == '\u066C': ch = ','
        elif '\u064B' <= ch <= '\u0652' or ch == '\u0640': continue
        out.append(ch.lower())
    s = ''.join(out)
    s = re.sub(r'(?<=\d),(?=\d{3})', '', s)
    s = re.sub(r'\s+', ' ', s).strip()
    return s

TOKEN_RE = re.compile('\\d+(?:\\.\\d+)?|[' + LETTER + 'A-Za-z]+|[^\\s\\d' + LETTER + 'A-Za-z]')
def tokenize(s):
    return [(m.group(), m.start(), m.end()) for m in TOKEN_RE.finditer(s)]

# ---------- amounts ----------
NUM_WORDS = {
 'یک':1,'دو':2,'سه':3,'چهار':4,'پنج':5,'شش':6,'هفت':7,'هشت':8,'نه':9,'ده':10,'یازده':11,'دوازده':12,'سیزده':13,
 'چهارده':14,'پانزده':15,'پونزده':15,'شانزده':16,'شونزده':16,'هفده':17,'هجده':18,'نوزده':19,
 'بیست':20,'سی':30,'چهل':40,'پنجاه':50,'شصت':60,'هفتاد':70,'هشتاد':80,'نود':90,
 'یکصد':100,'دویست':200,'سیصد':300,'چهارصد':400,'پانصد':500,'پونصد':500,'ششصد':600,'هفتصد':700,'هشتصد':800,'نهصد':900,
}
MULT = {'هزار':Decimal(1000),'میلیون':Decimal(10**6),'ملیون':Decimal(10**6),'میلیارد':Decimal(10**9),'ملیارد':Decimal(10**9)}
TOMAN_UNITS = {'تومان','تومن'}
RIAL_UNITS = {'ریال'}

def is_digit_tok(t):
    return t[0].isdigit()

def parse_phrase(toks, i):
    total = Decimal(0); cur = Decimal(0); last_mult = None
    snap = None; j = i; consumed = False; prev_conn = False
    has_digit = has_word = has_mult = False; implicit_one = False
    while j < len(toks):
        t = toks[j][0]
        if t == 'و':
            if not consumed: break
            prev_conn = True; j += 1; continue
        if is_digit_tok(t):
            if cur != 0: break
            cur = Decimal(t); has_digit = True
        elif t == 'صد':
            if cur == 0 and total == 0 and not consumed: cur = Decimal(100)
            elif cur == 0 and total > 0: cur = Decimal(100)
            elif 1 <= cur <= 9 and not prev_conn and cur == int(cur): cur = cur * 100
            else: break
            has_word = True
        elif t in NUM_WORDS:
            v = NUM_WORDS[t]
            if cur == 0: cur = Decimal(v)
            elif cur != int(cur): break
            elif v >= 100: break
            elif v < 10:
                if cur % 10 == 0 and (cur % 100 == 0 or cur % 100 >= 20): cur += v
                else: break
            else:
                if cur % 100 == 0 and cur >= 100: cur += v
                else: break
            has_word = True
        elif t == 'نیم':
            if cur > 0 and cur == int(cur): cur += Decimal('0.5')
            elif cur == 0 and total > 0 and last_mult is not None: total += last_mult / 2
            elif cur == 0 and total == 0 and not consumed: cur = Decimal('0.5')
            else: break
            has_word = True
        elif t in MULT:
            m = MULT[t]
            if cur == 0:
                if total == 0 and not consumed: cur = Decimal(1); implicit_one = True
                elif total > 0 and prev_conn and m == 1000 and last_mult is not None and last_mult > 1000: cur = Decimal(1)
                else: break
            if last_mult is not None and m >= last_mult: break
            total += cur * m; cur = Decimal(0); last_mult = m; has_mult = True
        else:
            break
        consumed = True; prev_conn = False; j += 1
        if total == 0 or cur == 0:
            snap = (total + cur, j, has_digit, has_word, has_mult, implicit_one)
    return snap

APPROX_WORDS = {'حدود','تقریبا','نزدیک','بیش','کمتر','حداقل','حداکثر'}
RELATIVE_WORDS = {'برابر','درصد','نصف'}

def starts_number(tok):
    return tok[0].isdigit() or tok in NUM_WORDS or tok in ('صد', 'نیم')

def find_amounts_ex(norm):
    """returns list of (int value, sorted list of flags)"""
    toks = tokenize(norm)
    res = []; i = 0
    while i < len(toks):
        snap = parse_phrase(toks, i)
        if snap is None:
            i += 1; continue
        value, end, has_digit, has_word, has_mult, implicit_one = snap
        unit = toks[end][0] if end < len(toks) else None
        accepted = None
        if unit in TOMAN_UNITS:
            accepted = value; end += 1
        elif unit in RIAL_UNITS:
            v = value / 10
            accepted = v if v == int(v) else None
            end += 1
        elif has_mult and not implicit_one:
            accepted = value
        elif has_digit and not has_word and not has_mult:
            raw = toks[i][0]
            prev = toks[i-1][0] if i > 0 else ''
            if (value == int(value) and 1000 <= value <= MAX_AMOUNT and not raw.startswith('0')
                    and not (len(raw) == 4 and 1300 <= value <= 1500) and len(raw) <= 12 and prev != 'ساعت'):
                accepted = value
        if accepted is not None and accepted == int(accepted) and 0 < accepted <= MAX_AMOUNT:
            flags = set()
            before = [t[0] for t in toks[max(0, i-2):i]]
            if 'تا' in before[-1:]: flags.add('RANGE')
            if any(b in APPROX_WORDS for b in before): flags.add('APPROX')
            if any(b in RELATIVE_WORDS for b in before) or (end < len(toks) and toks[end][0] in RELATIVE_WORDS):
                flags.add('RELATIVE')
            if end + 1 < len(toks) and toks[end][0] == 'و' and starts_number(toks[end+1][0]):
                flags.add('TRAILING')
            res.append((int(accepted), sorted(flags))); i = end
        else:
            i += 1
    return res

def find_amounts(norm):
    return [v for v, _ in find_amounts_ex(norm)]

def amounts_string(norm):
    r = find_amounts_ex(norm)
    if not r: return 'none'
    return '|'.join(str(v) + ('!' + ','.join(f) if f else '') for v, f in r)

# ---------- dates ----------
MONTHS = {'فروردین':1,'اردیبهشت':2,'خرداد':3,'تیر':4,'مرداد':5,'شهریور':6,'مهر':7,'آبان':8,'آذر':9,'دی':10,'بهمن':11,'اسفند':12}
WEEKDAYS = [('یکشنبه',6),('یک شنبه',6),('دوشنبه',0),('دو شنبه',0),('سه شنبه',1),('چهارشنبه',2),('چهار شنبه',2),
            ('پنجشنبه',3),('پنج شنبه',3),('جمعه',4),('شنبه',5)]
SMALL_WORDS = {'یک':1,'دو':2,'سه':3,'چهار':4,'پنج':5,'شش':6,'هفت':7,'هشت':8,'نه':9,'ده':10}

def w(alts):
    return NOTL + '(?:' + '|'.join(alts) + ')' + NOTL_AFTER

def find_date(norm, today):
    """today=(jy,jm,jd). returns (date or None, (h,m) or None)"""
    date = None
    m = re.search(NOTL + r'(\d{4})[/-](\d{1,2})[/-](\d{1,2})' + NOTL_AFTER, norm)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if valid_jalali(y, mo, d): date = (y, mo, d)
    if date is None:
        mon_alt = '|'.join(sorted(MONTHS, key=len, reverse=True))
        m = re.search(NOTL + r'(\d{1,2}) (' + mon_alt + r')(?: (\d{4}))?' + NOTL_AFTER, norm)
        if m:
            y = int(m.group(3)) if m.group(3) else today[0]
            d = int(m.group(1)); mo = MONTHS[m.group(2)]
            if valid_jalali(y, mo, d): date = (y, mo, d)
    if date is None:
        rel = [('پس ?فردا',2),('پریروز',-2),('امروز',0),('دیروز',-1),('فردا',1)]
        best = None
        for pat, off in rel:
            mm = re.search(w([pat]), norm)
            if mm and (best is None or mm.start() < best[0]): best = (mm.start(), off)
        if best: date = jalali_plus(today, best[1])
    if date is None:
        nums = '|'.join(list(SMALL_WORDS) + [r'\d{1,3}'])
        m = re.search(NOTL + '(' + nums + r') روز (دیگر|بعد|آینده|پیش|قبل)' + NOTL_AFTER, norm)
        if m:
            n = SMALL_WORDS.get(m.group(1)) or int(m.group(1))
            sign = 1 if m.group(2) in ('دیگر','بعد','آینده') else -1
            date = jalali_plus(today, sign * n)
    if date is None:
        pat = w([name for name, _ in WEEKDAYS])
        m = re.search(pat, norm)
        if m:
            target = dict(WEEKDAYS)[m.group(0)]
            cur = jalali_weekday(today)
            delta = (target - cur) % 7
            if delta == 0: delta = 7
            date = jalali_plus(today, delta)
    # time
    time = None
    hw = '|'.join(sorted(SMALL_WORDS, key=len, reverse=True) + ['یازده','دوازده'])
    m = re.search(NOTL + r'ساعت (\d{1,2})(?::(\d{2}))?(?: (و نیم|و ربع))?(?: (صبح|ظهر|عصر|شب|بعد ?از ?ظهر))?' + NOTL_AFTER, norm)
    if m:
        h = int(m.group(1)); mi = int(m.group(2)) if m.group(2) else 0
        extra = m.group(3); period = m.group(4)
    else:
        m = re.search(NOTL + r'ساعت (' + hw + r')(?: (و نیم|و ربع))?(?: (صبح|ظهر|عصر|شب|بعد ?از ?ظهر))?' + NOTL_AFTER, norm)
        if m:
            wd = m.group(1)
            h = {'یازده':11,'دوازده':12}.get(wd) or SMALL_WORDS[wd]; mi = 0
            extra = m.group(2); period = m.group(3)
        else:
            h = None
    if h is not None:
        if extra == 'و نیم': mi = 30
        elif extra == 'و ربع': mi = 15
        if period:
            p = period.replace(' ', '')
            if p in ('عصر', 'بعدازظهر') and 1 <= h <= 11: h += 12
            elif p == 'شب':
                if 6 <= h <= 11: h += 12
                elif h == 12: h = 0
            elif p == 'ظهر' and 1 <= h <= 4: h += 12
        if 0 <= h <= 23 and 0 <= mi <= 59: time = (h, mi)
    return date, time

# ---------- intents ----------
def kw(norm, alts):
    return re.search(NOTL + '(?:' + '|'.join(alts) + ')' + NOTL_AFTER, norm) is not None

NOTE_KW = ['یادداشت کن','یادداشت','نوت کن']
REMINDER_KW = ['یادم بنداز','یادم باشه','یادآوری','یاد آوری','یادم بیار','به یادم بیار','ریمایندر']
QUESTION_WORDS = ['چقدر','چند','چطور','چرا','آیا','کی','کجا','کدام','چه کسی']
TRANSFER_KW = ['انتقال','منتقل','کارت به کارت','جابجا کردم','جا به جا']
INCOME_KW = ['واریز شد','واریز شده','واریزی','حقوق','حقوقم','دریافت کردم','دریافت شد','دریافتی','درآمد','فروختم','فروش','سود','به حسابم نشست','پول اومد','پول آمد']
EXPENSE_KW = ['پرداخت کردم','پرداخت شد','پرداخت','دادم','خرج کردم','خرج','هزینه','خریدم','خرید','قسط','کرایه','بنزین','پول دادم','واریز کردم']
SITE_KW = ['ستون','ستون ها','فونداسیون','آرماتور','آرماتوربندی','بتن','بتن ریزی','قالب بندی','اسکلت','گودبرداری','دیوارچینی','سقف','نازک کاری','تاسیسات','نما','کارگاه']
GENERIC = {'حساب','دارایی','سایر','نقد','پول'}

def accounts_mentioned(norm, names):
    words = [t[0] for t in tokenize(norm)]
    found = []
    for name in names:
        n = normalize(name)
        keys = [x for x in n.split(' ') if len(x) >= 3 and x not in GENERIC]
        hit = n in norm
        if not hit:
            for key in keys:
                for wd in words:
                    if wd == key or (min(len(wd), len(key)) >= 4 and (wd.startswith(key) or key.startswith(wd))):
                        hit = True; break
                if hit: break
        if hit: found.append(name)
    return found

def classify(norm, account_names):
    """returns (intents list, candidates list)"""
    if kw(norm, NOTE_KW): return ['NOTE'], []
    if kw(norm, REMINDER_KW): return ['REMINDER'], []
    if '؟' in norm or '?' in norm or kw(norm, QUESTION_WORDS): return ['QUESTION'], []
    site = kw(norm, SITE_KW)
    transfer = kw(norm, TRANSFER_KW)
    if not transfer:
        accs = accounts_mentioned(norm, account_names)
        if len(accs) >= 2 and re.search(NOTL + 'به' + NOTL_AFTER, norm): transfer = True
    income = kw(norm, INCOME_KW)
    expense = kw(norm, EXPENSE_KW)
    deposit_only = kw(norm, ['واریز کردم']) and not kw(norm, [k for k in EXPENSE_KW if k != 'واریز کردم'])
    fin = []; cand = []
    if transfer: fin = ['TRANSFER']
    elif deposit_only and not income and accounts_mentioned(norm, account_names): cand = ['TRANSFER', 'EXPENSE']
    elif income and expense: cand = ['INCOME', 'EXPENSE']
    elif income: fin = ['INCOME']
    elif expense: fin = ['EXPENSE']
    intents = (['SITE_REPORT'] if site else []) + fin
    if not intents and not cand: return [], []
    return intents, cand

def intent_string(intents, cand):
    if cand: return 'AMBIGUOUS:' + '|'.join(cand)
    return ','.join(intents) if intents else 'UNKNOWN'

# ---------- number to Persian words ----------
_ONES = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه']
_TEENS = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده']
_TENS = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود']
_HUNDREDS = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد']

def _group_words(n):  # 1..999
    parts = []
    h, r = divmod(n, 100)
    if h: parts.append(_HUNDREDS[h])
    if r >= 20:
        t, o = divmod(r, 10)
        parts.append(_TENS[t])
        if o: parts.append(_ONES[o])
    elif r >= 10:
        parts.append(_TEENS[r - 10])
    elif r > 0:
        parts.append(_ONES[r])
    return ' و '.join(parts)

def to_words(n):
    if n == 0: return 'صفر'
    if n < 0: return 'منفی ' + to_words(-n)
    if n >= 10**9:
        b, rest = divmod(n, 10**9)
        s = to_words(b) + ' میلیارد'
        return s + (' و ' + to_words(rest) if rest else '')
    parts = []
    m, rest = divmod(n, 10**6)
    if m: parts.append(_group_words(m) + ' میلیون')
    t, u = divmod(rest, 1000)
    if t: parts.append('هزار' if t == 1 else _group_words(t) + ' هزار')
    if u: parts.append(_group_words(u))
    return ' و '.join(parts)

# ---------- accounts in order of appearance ----------
def accounts_ordered(norm, names):
    toks = tokenize(norm)
    words = [t[0] for t in toks]
    found = []
    for name in names:
        n = normalize(name)
        pos = None
        idx = norm.find(n)
        if idx >= 0:
            # token index of that character offset
            for k, (_, s, e) in enumerate(toks):
                if s >= idx: pos = k; break
        if pos is None:
            keys = [x for x in n.split(' ') if len(x) >= 3 and x not in GENERIC]
            for k, wd in enumerate(words):
                if any(wd == key or (min(len(wd), len(key)) >= 4 and (wd.startswith(key) or key.startswith(wd))) for key in keys):
                    pos = k; break
        if pos is not None: found.append((pos, name))
    found.sort(key=lambda x: x[0])
    return [n for _, n in found]
