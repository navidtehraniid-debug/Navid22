"""ارزیابی کیفیت استخراج متن فارسی از یک PDF (مرجع برای مرحله 2 کتابخانه NAVID).

اجرا:  python3 pdf_text_eval.py file.pdf
نیازمند poppler-utils (pdftotext).  خروجی: نسبت حروف فارسی، آزمون جهت شماره بندها، فاصله چاپی صفحه.
"""
import re, subprocess, sys, unicodedata, collections

CTRL = re.compile('[\u202a-\u202e\u200e\u200f\u2066-\u2069\u200d\ufeff]')

def normalize(t):
    t = unicodedata.normalize("NFKC", t)          # اشکال نمایشی عربی به حروف عادی
    t = CTRL.sub("", t).replace("\u200c", " ")    # کنترل های جهت حذف، نیم فاصله به فاصله
    t = t.replace("\u064a", "\u06cc").replace("\u0643", "\u06a9").replace("\u0640", "")
    return re.sub(r"[ \t]+", " ", t)

def pages_of(pdf):
    out = subprocess.run(["pdftotext", pdf, "-"], capture_output=True, text=True).stdout
    return [normalize(p) for p in out.split("\f")[:-1]]

CLAUSE = re.compile(r'^\s*(\d+(?:-\d+){1,4})\s*(?=[\u0600-\u06ff])')

def monotonic(seqs):
    ok = tot = 0
    for a, b in zip(seqs, seqs[1:]):
        if len(a) == len(b) and a[:-1] == b[:-1]:
            tot += 1
            ok += b[-1] >= a[-1]
    return ok, tot

def main(pdf):
    pages = pages_of(pdf)
    text = "\n".join(pages)
    chars = [c for c in text if not c.isspace()]
    fa = sum('\u0600' <= c <= '\u06ff' for c in chars)
    print(f"pages={len(pages)} persian_ratio={fa/max(1,len(chars)):.2f}")
    nums = [[int(x) for x in m.group(1).split("-")]
            for p in pages for ln in p.split("\n") if (m := CLAUSE.match(ln))]
    rev = [list(reversed(s)) for s in nums]
    print("clause lines:", len(nums))
    print("monotonic as extracted:", monotonic(nums), " reversed segments:", monotonic(rev))
    offs = collections.Counter()
    for i, p in enumerate(pages, 1):
        last = [l.strip() for l in p.split("\n") if l.strip()][-3:]
        for l in reversed(last):
            if re.fullmatch(r"\d{1,3}", l):
                offs[i - int(l)] += 1
                break
    print("page offset (pdf - printed):", offs.most_common(3))

if __name__ == "__main__":
    main(sys.argv[1])
