"""بررسی ایستای ساده پروژه Kotlin (جای کامپایلر را نمی گیرد):
import های داخلی، تعادل پرانتز و آکولاد و کروشه (با حذف رشته ها)، تکرار نام کلاس ها."""
import re, pathlib, collections, sys

def strip(s):
    out = []; i = 0; n = len(s)
    while i < n:
        if s.startswith('"""', i):
            j = s.find('"""', i + 3); out.append('""'); i = (j + 3) if j >= 0 else n; continue
        c = s[i]
        if c == '"':
            j = i + 1
            while j < n and s[j] != '"':
                if s[j] == '\\': j += 1
                j += 1
            out.append('""'); i = j + 1
        elif c == "'" and i + 2 < n and (s[i + 2] == "'" or (s[i + 1] == '\\' and i + 3 < n and s[i + 3] == "'")):
            out.append("''"); i += 3 if s[i + 1] != '\\' else 4
        elif s.startswith('//', i):
            j = s.find('\n', i); i = n if j < 0 else j
        elif s.startswith('/*', i):
            j = s.find('*/', i + 2); i = n if j < 0 else j + 2
        else:
            out.append(c); i += 1
    return ''.join(out)

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "app/src")
files = list(root.rglob("*.kt"))
decl = collections.defaultdict(set); text = {}; pkg_of = {}
DECL = re.compile(r'^\s*(?:(?:private|internal|public|data|sealed|enum|open|abstract|const|inline|operator)\s+)*(?:class|object|interface|fun|val|var|typealias)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)', re.M)
for p in files:
    s = p.read_text(encoding="utf-8"); text[p] = s
    m = re.search(r'^package\s+([\w.]+)', s, re.M); pkg = m.group(1) if m else ""
    pkg_of[p] = pkg
    for d in DECL.finditer(s): decl[pkg].add(d.group(1))
problems = []
for p, s in text.items():
    for imp in re.findall(r'^import\s+(ir\.navid\.app\.[\w.]+)', s, re.M):
        pkg, _, name = imp.rpartition('.')
        if name not in decl.get(pkg, set()): problems.append(f"UNRESOLVED IMPORT {imp} in {p}")
    t = strip(s)
    for a, b, nm in (('{', '}', 'brace'), ('(', ')', 'paren'), ('[', ']', 'bracket')):
        if t.count(a) != t.count(b): problems.append(f"UNBALANCED {nm} {t.count(a)} vs {t.count(b)} in {p}")
seen = collections.defaultdict(list)
for p, s in text.items():
    for m in re.finditer(r'^(?:(?:internal|public|data|sealed|enum|open|abstract)\s+)*(?:class|object|interface)\s+(\w+)', s, re.M):
        seen[(pkg_of[p], m.group(1))].append(p.name)
for k, v in seen.items():
    if len(v) > 1: problems.append(f"DUPLICATE {k} in {v}")
print(len(files), "kotlin files;", "PROBLEMS:" if problems else "no problems found")
print("\n".join(problems))
